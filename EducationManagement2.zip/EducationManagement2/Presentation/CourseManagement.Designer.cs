﻿namespace Presentation
{
    partial class CourseManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            groupBox1 = new GroupBox();
            btnCourseUpdated = new Button();
            btnCourseAdd = new Button();
            txtCourseCode = new TextBox();
            txtCourseName = new TextBox();
            label2 = new Label();
            label1 = new Label();
            lblCourseId = new Label();
            dgwCourses = new DataGridView();
            contextMenuStrip1 = new ContextMenuStrip(components);
            deleteToolStripMenuItem = new ToolStripMenuItem();
            updateToolStripMenuItem = new ToolStripMenuItem();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgwCourses).BeginInit();
            contextMenuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnCourseUpdated);
            groupBox1.Controls.Add(btnCourseAdd);
            groupBox1.Controls.Add(txtCourseCode);
            groupBox1.Controls.Add(txtCourseName);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(23, 26);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(711, 125);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "COURSE DETAILS";
            // 
            // btnCourseUpdated
            // 
            btnCourseUpdated.Location = new Point(590, 28);
            btnCourseUpdated.Name = "btnCourseUpdated";
            btnCourseUpdated.Size = new Size(94, 70);
            btnCourseUpdated.TabIndex = 4;
            btnCourseUpdated.Text = "UPDATE";
            btnCourseUpdated.UseVisualStyleBackColor = true;
            btnCourseUpdated.Click += btnCourseUpdated_Click;
            // 
            // btnCourseAdd
            // 
            btnCourseAdd.Location = new Point(470, 27);
            btnCourseAdd.Name = "btnCourseAdd";
            btnCourseAdd.Size = new Size(94, 70);
            btnCourseAdd.TabIndex = 3;
            btnCourseAdd.Text = "ADD";
            btnCourseAdd.UseVisualStyleBackColor = true;
            btnCourseAdd.Click += btnCourseAdd_Click;
            // 
            // txtCourseCode
            // 
            txtCourseCode.Location = new Point(119, 70);
            txtCourseCode.Name = "txtCourseCode";
            txtCourseCode.Size = new Size(312, 27);
            txtCourseCode.TabIndex = 2;
            // 
            // txtCourseName
            // 
            txtCourseName.Location = new Point(119, 28);
            txtCourseName.Name = "txtCourseName";
            txtCourseName.Size = new Size(312, 27);
            txtCourseName.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(13, 70);
            label2.Name = "label2";
            label2.Size = new Size(100, 20);
            label2.TabIndex = 1;
            label2.Text = "Course Code:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 31);
            label1.Name = "label1";
            label1.Size = new Size(107, 20);
            label1.TabIndex = 0;
            label1.Text = "Course Name:";
            // 
            // lblCourseId
            // 
            lblCourseId.AutoSize = true;
            lblCourseId.Location = new Point(24, 168);
            lblCourseId.Name = "lblCourseId";
            lblCourseId.Size = new Size(50, 20);
            lblCourseId.TabIndex = 1;
            lblCourseId.Text = "label3";
            lblCourseId.Visible = false;
            // 
            // dgwCourses
            // 
            dgwCourses.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwCourses.ContextMenuStrip = contextMenuStrip1;
            dgwCourses.Location = new Point(23, 218);
            dgwCourses.MultiSelect = false;
            dgwCourses.Name = "dgwCourses";
            dgwCourses.ReadOnly = true;
            dgwCourses.RowHeadersWidth = 51;
            dgwCourses.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwCourses.Size = new Size(711, 188);
            dgwCourses.TabIndex = 2;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { deleteToolStripMenuItem, updateToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(128, 52);
            // 
            // deleteToolStripMenuItem
            // 
            deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            deleteToolStripMenuItem.Size = new Size(127, 24);
            deleteToolStripMenuItem.Text = "Delete";
            deleteToolStripMenuItem.Click += deleteToolStripMenuItem_Click;
            // 
            // updateToolStripMenuItem
            // 
            updateToolStripMenuItem.Name = "updateToolStripMenuItem";
            updateToolStripMenuItem.Size = new Size(127, 24);
            updateToolStripMenuItem.Text = "Update";
            updateToolStripMenuItem.Click += updateToolStripMenuItem_Click;
            // 
            // CourseManagement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(763, 450);
            Controls.Add(dgwCourses);
            Controls.Add(lblCourseId);
            Controls.Add(groupBox1);
            Name = "CourseManagement";
            Text = "CourseManagement";
            Load += CourseManagement_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgwCourses).EndInit();
            contextMenuStrip1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private Button btnCourseUpdated;
        private Button btnCourseAdd;
        private TextBox txtCourseCode;
        private TextBox txtCourseName;
        private Label label2;
        private Label label1;
        private Label lblCourseId;
        private DataGridView dgwCourses;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem updateToolStripMenuItem;
    }
}