using Business.Services;
using LibraryAutomationSystem.Context;

namespace Presentation
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        AppDbContext context = new AppDbContext();

        AppUserService appUserService = new AppUserService();
        BookService bookService = new BookService();
        MemberService memberService = new MemberService();
        MemberBookService memberBookService = new MemberBookService();

        private void btnRegister_Click(object sender, EventArgs e)
        {
            RegisterForm registerForm = new RegisterForm(appUserService);
            registerForm.ShowDialog();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            LoginForm loginForm = new LoginForm(appUserService);
            loginForm.LoginStatusChanged += LoginForm_LoginStatusChanged;
            loginForm.ShowDialog();
        }

        private void LoginForm_LoginStatusChanged(object sender, bool isLoggedIn)
        {
            btnManageBooks.Enabled = isLoggedIn;
            btnManageMembers.Enabled = isLoggedIn;
            btnManageLoans.Enabled = isLoggedIn;
            btnLogin.Enabled = !isLoggedIn;
            btnRegister.Enabled = !isLoggedIn;
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            btnManageBooks.Enabled = false;
            btnManageMembers.Enabled = false;
            btnManageLoans.Enabled = false;
        }

        private void btnManageMembers_Click(object sender, EventArgs e)
        {
            MembersForm manageMembersForm = new MembersForm(memberService);
            manageMembersForm.ShowDialog();
        }

        private void btnManageBooks_Click(object sender, EventArgs e)
        {
            BooksForm manageBooksForm = new BooksForm(bookService);
            manageBooksForm.ShowDialog();
        }

        private void btnManageLoans_Click(object sender, EventArgs e)
        {
            LoanForm manageLonansForm = new LoanForm(bookService, memberBookService, memberService);
            manageLonansForm.ShowDialog();
        }
    }
}
