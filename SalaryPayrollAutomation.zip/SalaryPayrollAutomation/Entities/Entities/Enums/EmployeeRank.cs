﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Entities.Enums;

public enum EmployeeRank
{
    Junior = 1,
    Mid = 2,
    Senior = 3,
    NotApplicable
}
