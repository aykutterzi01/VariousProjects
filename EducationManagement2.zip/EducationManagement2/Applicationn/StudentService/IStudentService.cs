﻿using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applicationn.StudentService
{
    public interface IStudentService
    {
        public void Create(Student student);
        public void Delete(Student student);
        public Student Get(Guid id);
        public List<Student> GetAll();
        public void Update(Student student);
    }
}
