﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryAutomationSystem.Entities.Enum;

namespace LibraryAutomationSystem.Entities;

public class BookNovel : Book
{
    public string Thema { get; set; }

}
