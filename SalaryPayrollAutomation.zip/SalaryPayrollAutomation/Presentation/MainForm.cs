using Business.Services;

namespace Presentation
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        PersonnelService personnelService = new PersonnelService();
        PayrollService payrollService = new PayrollService();

        private void managePersonnelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PersonnelManagement personnelManagement = new PersonnelManagement(personnelService);
            personnelManagement.ShowDialog();
        }

        private void managePayrollToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PayrollMangement payrollMangement = new PayrollMangement(personnelService, payrollService);
            payrollMangement.ShowDialog();
        }

        private void payrollOverviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PayrollOverview payrollOverview = new PayrollOverview(payrollService);
            payrollOverview.ShowDialog();
        }
    }
}
