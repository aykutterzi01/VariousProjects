﻿using LibraryAutomationSystem.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryAutomationSystem.Context;

public class AppDbContext : DbContext
{
    public DbSet<Book> Books { get; set; }
    public DbSet<BookHistory> BookHistories { get; set; }
    public DbSet<BookNovel> BookNovels { get; set; }
    public DbSet<BookScience> BookSciences { get; set; }
    public DbSet<Member> Members { get; set; }
    public DbSet<MemberBook> MemberBooks { get; set; }
    public DbSet<AppUser> AppUsers { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer("Server=LAPTOP-1RUKRP01\\SQLEXPRESS;Initial Catalog=HS14LibraryAutomation;Trusted_Connection=True;TrustServerCertificate=True");
        }

        base.OnConfiguring(optionsBuilder);
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
    }
}
