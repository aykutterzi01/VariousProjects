﻿using OOP.Applicationn.AccountService;
using OOP.Applicationn.CustomerService;
using OOP.Model.Models;
using OOP.Model.Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Presentation;

public partial class CreateAccount : Form
{
    CustomerService _customerService;
    AccountService _accountService;
    public CreateAccount(CustomerService customerService, AccountService accountService)
    {
        InitializeComponent();
        _customerService = customerService;
        _accountService = accountService;
    }

    private void CreateAccount_Load(object sender, EventArgs e)
    {
        rdbtn_Standard.Checked = true;
        rdbtn_TL.Checked = true;
        rdbtn_New_Customer.Checked = true;
        GetCustomers();
    }

    private void rdbtn_New_Customer_CheckedChanged(object sender, EventArgs e)
    {
        GetCustomers();

        GetAccounts();

        if (rdbtn_New_Customer.Checked == true)
        {
            grpbx_Existing_Customers.Visible = false;
            grpbx_Existing_Accounts.Visible = false;
            grpbx_New_Customer_Details.Visible = true;
        }
        else
        {
            grpbx_Existing_Customers.Visible = true;
            grpbx_Existing_Accounts.Visible = true;
            grpbx_New_Customer_Details.Visible = false;

        }
    }


    private void GetCustomers()
    {
        if (rdbtn_Standard.Checked == true)
        {
            cmb_Existing_Customers.DataSource = _customerService.GetAll().Where(x => x.CustomerType == CustomerType.Standard).ToList();
        }
        else
        {
            cmb_Existing_Customers.DataSource = _customerService.GetAll().Where(x => x.CustomerType == CustomerType.Student).ToList();
        }
    }

    private void GetAccounts()
    {
        if (rdbtn_Standard.Checked == true)
        {

            Customer selectedCustomer = (Customer)cmb_Existing_Customers.SelectedItem;

            dgw_Existing_Accounts.DataSource = null;

            dgw_Existing_Accounts.DataSource = _accountService.GetAll().Where(x => x.Customer.Id == selectedCustomer.Id && selectedCustomer.CustomerType == CustomerType.Standard).ToList();
        }
        else
        {

            Customer selectedCustomer = (Customer)cmb_Existing_Customers.SelectedItem;

            dgw_Existing_Accounts.DataSource = null;

            dgw_Existing_Accounts.DataSource = _accountService.GetAll().Where(x => x.Customer.Id == selectedCustomer.Id && selectedCustomer.CustomerType == CustomerType.Student).ToList();
        }
        

        dgw_Existing_Accounts.Columns["Id"].Visible = false;

        dgw_Existing_Accounts.Columns["Balance"].DefaultCellStyle.Format = "N2";
    }

    private void rdbtn_Standard_CheckedChanged(object sender, EventArgs e)
    {
        GetCustomers();
        GetAccounts();

        if (rdbtn_Standard.Checked == true)
        {
            txt_University.Visible = false;
            lbl_University.Visible = false;   
        }
        else
        {
            txt_University.Visible = true;
            lbl_University.Visible = true;
        }
    }

    private void cmb_Existing_Customers_SelectedIndexChanged(object sender, EventArgs e)
    {
        GetAccounts();
    }

    private void btn_Create_Account_Click(object sender, EventArgs e)
    {

        if (rdbtn_Standard.Checked == true)
        {
            if (rdbtn_New_Customer.Checked == true)
            {
                Customer customer = new Customer()
                {
                    Name = txt_Name.Text,
                    Surname = txt_Surname.Text,
                    Email = txt_Email.Text,
                    City = txt_City.Text,
                    CustomerType = CustomerType.Standard
                };

                if (!CheckFieldsStandard()) return;

                _customerService.Create(customer);

                AddNewAccount(customer);

            }
            else
            {
                Customer customer = (Customer)cmb_Existing_Customers.SelectedItem;
                AddNewAccount(customer);
            }


        }
        else
        {
            if (rdbtn_New_Customer.Checked == true)
            {
                Customer customer = new Customer()
                {
                    Name = txt_Name.Text,
                    Surname = txt_Surname.Text,
                    Email = txt_Email.Text,
                    City = txt_City.Text,
                    CustomerType = CustomerType.Student,
                    University = txt_University.Text
                };

                if (!CheckFieldsStudent()) return;

                _customerService.Create(customer);
                AddNewAccount(customer);
            }
            else
            {
                Customer customer = (Customer)cmb_Existing_Customers.SelectedItem;
                AddNewAccount(customer);
            }
        }


        ClearTexts();

        GetAccounts();

    }

    private bool CheckFieldsStudent()
    {
        if (txt_Name.Text == "" || txt_Surname.Text == "" || txt_Email.Text == "" || txt_City.Text == "" || txt_University.Text == "")
        {
            MessageBox.Show("Please fill out all the fields.");
            return false;
        }

        return true;
    }

    private bool CheckFieldsStandard()
    {
        if (txt_Name.Text == "" || txt_Surname.Text == "" || txt_Email.Text == "" || txt_City.Text == "")
        {
            MessageBox.Show("Please fill out all the fields.");
            return false;
        }

        return true;
    }

    private void ClearTexts()
    {
        txt_Name.Text = null;
        txt_Surname.Text = null;
        txt_Email.Text = null;
        txt_City.Text = null;
        txt_University.Text = null;
    }

    private void AddNewAccount(Customer customer)
    {
        AccountType accountType = rdbtn_TL.Checked == true ? AccountType.TL : rdbtn_Dollar.Checked ? AccountType.Dollar : AccountType.Euro;

        var currentAccountCount = _accountService.GetAll().Count(x=> x.Customer.Id == customer.Id && x.AccountType == accountType);

        if (currentAccountCount >= 2)
        {
            MessageBox.Show("There can not be more than two accounts of the same type!");
            return;
        }

        Account account = new Account(customer, accountType);
        _accountService.Create(account);

        MessageBox.Show("Account has been added.");
    }
}