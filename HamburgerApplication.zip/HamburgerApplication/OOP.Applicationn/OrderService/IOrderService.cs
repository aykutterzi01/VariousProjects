﻿using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.OrderService
{
    public interface IOrderService
    {
        public void Create(Order order);
        public void Delete(Order order);
        public Order Get(Guid id);
        public List<Order> GetAll();

        public void Update(Order order);
    }
}
