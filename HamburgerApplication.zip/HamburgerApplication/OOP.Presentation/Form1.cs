using OOP.Applicationn.EkstraService;
using OOP.Applicationn.FoodService;
using OOP.Applicationn.OrderService;
using OOP.Model.Models;

namespace OOP.Presentation
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        FoodService _foodService = new FoodService();
        EkstraService _ekstraService = new EkstraService();
        OrderService _orderService = new OrderService();
        List<Order> _orderList = new List<Order>();

        private void createOrderToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateOrder createOrder = new CreateOrder(_foodService, _ekstraService, _orderService, _orderList);
            createOrder.MdiParent = Form1.ActiveForm;
            createOrder.Show();
        }

        private void orderDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrderDetails orderDetails = new OrderDetails(_orderService);
            orderDetails.MdiParent = Form1.ActiveForm;
            orderDetails.Show();
        }

        private void addFoodToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddFood addFood = new AddFood(_foodService);
            addFood.MdiParent = Form1.ActiveForm;
            addFood.Show();
        }

        private void addExtraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddEkstra addEkstra = new AddEkstra(_ekstraService);
            addEkstra.MdiParent = Form1.ActiveForm;
            addEkstra.Show();
        }

    }
}
