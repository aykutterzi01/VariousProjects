﻿using OOP.Infrastructure.DataService;
using OOP.Infrastructure.Interfaces;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.StandardCustomerService
{
    public class StandardCustomerService : IStandardCustomerService
    {
        private readonly IStandardCustomerDataService _standardCustomerDataService;
        public StandardCustomerService()
        {
            _standardCustomerDataService = new StandardCustomerDataService();
        }
        public void Create(StandardCustomer standardCustomer)
        {
            var standardCustomers = _standardCustomerDataService.GetData();
            standardCustomers.Add(standardCustomer);
            _standardCustomerDataService.Save(standardCustomers);
        }

        public void Delete(StandardCustomer standardCustomer)
        {
            var standardCustomers = _standardCustomerDataService.GetData();
            standardCustomers.Remove(standardCustomer);
            _standardCustomerDataService.Save(standardCustomers);
        }

        public StandardCustomer Get(Guid id)
        {
            var standardCustomers = _standardCustomerDataService.GetData();
            return standardCustomers.FirstOrDefault(x => x.Id == id);
        }

        public List<StandardCustomer> GetAll()
        {
            return _standardCustomerDataService.GetData();
        }

        public void Update(StandardCustomer standardCustomer)
        {
            var standardCustomers = _standardCustomerDataService.GetData();
            var updating = standardCustomers.FirstOrDefault(x => x.Id == standardCustomer.Id);
            var indexStandardCustomer = standardCustomers.IndexOf(updating);
            standardCustomers[indexStandardCustomer] = standardCustomer;
        }
    }
}
