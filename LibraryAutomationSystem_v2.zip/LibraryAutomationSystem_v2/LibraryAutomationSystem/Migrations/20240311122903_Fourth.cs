﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LibraryAutomationSystem.Migrations
{
    /// <inheritdoc />
    public partial class Fourth : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Amount",
                table: "Books",
                newName: "LonableAmount");

            migrationBuilder.AddColumn<int>(
                name: "LoanedAmount",
                table: "Books",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "LoanedAmount",
                table: "Books");

            migrationBuilder.RenameColumn(
                name: "LonableAmount",
                table: "Books",
                newName: "Amount");
        }
    }
}
