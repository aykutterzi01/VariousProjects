﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Model.Models
{
    public enum AccountType : byte
    {
        TL = 1,
        Dollar = 2,
        Euro = 3
    }
}
