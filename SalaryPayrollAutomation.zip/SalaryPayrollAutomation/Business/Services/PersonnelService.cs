﻿using DataAccess.Context;
using Entities.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services;

public class PersonnelService
{
    private readonly AppDbContext dbContext;

    public PersonnelService()
    {
        this.dbContext = new AppDbContext();
    }

    public void Create(Personnel personnel)
    {
        dbContext.Personnels.Add(personnel);
        dbContext.SaveChanges();
    }

    public void Delete(Personnel personnel)
    {
        dbContext.Personnels.Remove(personnel);
        dbContext.SaveChanges();
    }

    public void Update(Personnel personnel)
    {
        dbContext.Personnels.Update(personnel);
        dbContext.SaveChanges();
    }

    public List<Personnel> GetAll()
    {
        return dbContext.Personnels.ToList();
    }
}
