﻿namespace OOP.Presentation
{
    partial class OrderDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgw_All_Orders = new DataGridView();
            label1 = new Label();
            groupBox1 = new GroupBox();
            lbl_Turnover = new Label();
            groupBox2 = new GroupBox();
            lbl_Total_Amount_Of_Orders = new Label();
            groupBox3 = new GroupBox();
            lbl_Amount_Of_Products_Sold = new Label();
            groupBox4 = new GroupBox();
            lbl_Revenue_Of_Extras = new Label();
            label2 = new Label();
            groupBox5 = new GroupBox();
            lbl_Revenue_Cash = new Label();
            groupBox6 = new GroupBox();
            lbl_Revenue_Credit_Card = new Label();
            groupBox7 = new GroupBox();
            lbl_Products_Sold = new Label();
            label5 = new Label();
            dtp_End = new DateTimePicker();
            dtp_Start = new DateTimePicker();
            label4 = new Label();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgw_All_Orders).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            groupBox6.SuspendLayout();
            groupBox7.SuspendLayout();
            SuspendLayout();
            // 
            // dgw_All_Orders
            // 
            dgw_All_Orders.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_All_Orders.Location = new Point(19, 44);
            dgw_All_Orders.Name = "dgw_All_Orders";
            dgw_All_Orders.RowHeadersWidth = 51;
            dgw_All_Orders.Size = new Size(520, 376);
            dgw_All_Orders.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(19, 9);
            label1.Name = "label1";
            label1.Size = new Size(98, 20);
            label1.TabIndex = 1;
            label1.Text = "ALL ORDERS";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lbl_Turnover);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(573, 44);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(200, 87);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Turnover";
            // 
            // lbl_Turnover
            // 
            lbl_Turnover.AutoSize = true;
            lbl_Turnover.ForeColor = Color.Red;
            lbl_Turnover.Location = new Point(18, 36);
            lbl_Turnover.Name = "lbl_Turnover";
            lbl_Turnover.Size = new Size(0, 20);
            lbl_Turnover.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lbl_Total_Amount_Of_Orders);
            groupBox2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox2.Location = new Point(573, 137);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(200, 87);
            groupBox2.TabIndex = 3;
            groupBox2.TabStop = false;
            groupBox2.Text = "Total Amount of Orders";
            // 
            // lbl_Total_Amount_Of_Orders
            // 
            lbl_Total_Amount_Of_Orders.AutoSize = true;
            lbl_Total_Amount_Of_Orders.ForeColor = Color.Red;
            lbl_Total_Amount_Of_Orders.Location = new Point(18, 36);
            lbl_Total_Amount_Of_Orders.Name = "lbl_Total_Amount_Of_Orders";
            lbl_Total_Amount_Of_Orders.Size = new Size(0, 20);
            lbl_Total_Amount_Of_Orders.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(lbl_Amount_Of_Products_Sold);
            groupBox3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox3.Location = new Point(573, 333);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(200, 87);
            groupBox3.TabIndex = 5;
            groupBox3.TabStop = false;
            groupBox3.Text = "Amount of Products Sold";
            // 
            // lbl_Amount_Of_Products_Sold
            // 
            lbl_Amount_Of_Products_Sold.AutoSize = true;
            lbl_Amount_Of_Products_Sold.ForeColor = Color.Red;
            lbl_Amount_Of_Products_Sold.Location = new Point(18, 36);
            lbl_Amount_Of_Products_Sold.Name = "lbl_Amount_Of_Products_Sold";
            lbl_Amount_Of_Products_Sold.Size = new Size(0, 20);
            lbl_Amount_Of_Products_Sold.TabIndex = 0;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(lbl_Revenue_Of_Extras);
            groupBox4.Controls.Add(label2);
            groupBox4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox4.Location = new Point(573, 230);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(200, 87);
            groupBox4.TabIndex = 6;
            groupBox4.TabStop = false;
            groupBox4.Text = "Revenue of Extras";
            // 
            // lbl_Revenue_Of_Extras
            // 
            lbl_Revenue_Of_Extras.AutoSize = true;
            lbl_Revenue_Of_Extras.ForeColor = Color.Red;
            lbl_Revenue_Of_Extras.Location = new Point(15, 35);
            lbl_Revenue_Of_Extras.Name = "lbl_Revenue_Of_Extras";
            lbl_Revenue_Of_Extras.Size = new Size(0, 20);
            lbl_Revenue_Of_Extras.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.Red;
            label2.Location = new Point(18, 36);
            label2.Name = "label2";
            label2.Size = new Size(0, 20);
            label2.TabIndex = 0;
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(lbl_Revenue_Cash);
            groupBox5.Location = new Point(794, 44);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(230, 87);
            groupBox5.TabIndex = 7;
            groupBox5.TabStop = false;
            groupBox5.Text = "Revenue with Cash";
            // 
            // lbl_Revenue_Cash
            // 
            lbl_Revenue_Cash.AutoSize = true;
            lbl_Revenue_Cash.ForeColor = Color.Red;
            lbl_Revenue_Cash.Location = new Point(15, 38);
            lbl_Revenue_Cash.Name = "lbl_Revenue_Cash";
            lbl_Revenue_Cash.Size = new Size(0, 20);
            lbl_Revenue_Cash.TabIndex = 0;
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(lbl_Revenue_Credit_Card);
            groupBox6.Location = new Point(794, 137);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(230, 87);
            groupBox6.TabIndex = 8;
            groupBox6.TabStop = false;
            groupBox6.Text = "Revenue with Credit Card";
            // 
            // lbl_Revenue_Credit_Card
            // 
            lbl_Revenue_Credit_Card.AutoSize = true;
            lbl_Revenue_Credit_Card.ForeColor = Color.Red;
            lbl_Revenue_Credit_Card.Location = new Point(14, 40);
            lbl_Revenue_Credit_Card.Name = "lbl_Revenue_Credit_Card";
            lbl_Revenue_Credit_Card.Size = new Size(51, 20);
            lbl_Revenue_Credit_Card.TabIndex = 0;
            lbl_Revenue_Credit_Card.Text = "label3";
            // 
            // groupBox7
            // 
            groupBox7.Controls.Add(lbl_Products_Sold);
            groupBox7.Controls.Add(label5);
            groupBox7.Controls.Add(dtp_End);
            groupBox7.Controls.Add(dtp_Start);
            groupBox7.Controls.Add(label4);
            groupBox7.Controls.Add(label3);
            groupBox7.Location = new Point(796, 230);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new Size(228, 190);
            groupBox7.TabIndex = 9;
            groupBox7.TabStop = false;
            groupBox7.Text = "Products with Date";
            // 
            // lbl_Products_Sold
            // 
            lbl_Products_Sold.AutoSize = true;
            lbl_Products_Sold.ForeColor = Color.Red;
            lbl_Products_Sold.Location = new Point(13, 139);
            lbl_Products_Sold.Name = "lbl_Products_Sold";
            lbl_Products_Sold.Size = new Size(51, 20);
            lbl_Products_Sold.TabIndex = 1;
            lbl_Products_Sold.Text = "label3";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(11, 110);
            label5.Name = "label5";
            label5.Size = new Size(109, 20);
            label5.TabIndex = 11;
            label5.Text = "Products Sold:";
            // 
            // dtp_End
            // 
            dtp_End.Location = new Point(72, 62);
            dtp_End.Name = "dtp_End";
            dtp_End.Size = new Size(150, 27);
            dtp_End.TabIndex = 10;
            dtp_End.ValueChanged += dtp_End_ValueChanged;
            // 
            // dtp_Start
            // 
            dtp_Start.Location = new Point(72, 30);
            dtp_Start.Name = "dtp_Start";
            dtp_Start.Size = new Size(150, 27);
            dtp_Start.TabIndex = 3;
            dtp_Start.ValueChanged += dtp_Start_ValueChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = Color.Black;
            label4.Location = new Point(6, 67);
            label4.Name = "label4";
            label4.Size = new Size(39, 20);
            label4.TabIndex = 2;
            label4.Text = "End:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = Color.Black;
            label3.Location = new Point(6, 35);
            label3.Name = "label3";
            label3.Size = new Size(47, 20);
            label3.TabIndex = 1;
            label3.Text = "Start:";
            // 
            // OrderDetails
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1054, 451);
            Controls.Add(groupBox7);
            Controls.Add(groupBox6);
            Controls.Add(groupBox5);
            Controls.Add(groupBox4);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(label1);
            Controls.Add(dgw_All_Orders);
            Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            Name = "OrderDetails";
            Text = "OrderDetails";
            WindowState = FormWindowState.Maximized;
            Load += OrderDetails_Load;
            ((System.ComponentModel.ISupportInitialize)dgw_All_Orders).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            groupBox7.ResumeLayout(false);
            groupBox7.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgw_All_Orders;
        private Label label1;
        private GroupBox groupBox1;
        private Label lbl_Turnover;
        private GroupBox groupBox2;
        private Label lbl_Total_Amount_Of_Orders;
        private GroupBox groupBox3;
        private Label lbl_Amount_Of_Products_Sold;
        private GroupBox groupBox4;
        private Label lbl_Revenue_Of_Extras;
        private Label label2;
        private GroupBox groupBox5;
        private Label lbl_Revenue_Cash;
        private GroupBox groupBox6;
        private Label lbl_Revenue_Credit_Card;
        private GroupBox groupBox7;
        private DateTimePicker dtp_End;
        private DateTimePicker dtp_Start;
        private Label label4;
        private Label label3;
        private Label lbl_Products_Sold;
        private Label label5;
    }
}