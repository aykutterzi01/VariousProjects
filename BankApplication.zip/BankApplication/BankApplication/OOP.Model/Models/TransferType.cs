﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Model.Models
{
    public enum TransferType
    {
        Deposit = 1,
        Withdrawal = 2
    }
}
