﻿using LibraryAutomationSystem.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryAutomationSystem.Methods;

public static class Status
{
    public static void SetStatus(Book book)
    {
        if (book.LoanableAmount == 0 && book.LoanedAmount == 0)
        {
            book.Status = LibraryAutomationSystem.Entities.Enum.Status.NotPresent;
        }
        else if (book.LoanableAmount == 0 && book.LoanedAmount != 0)
        {
            book.Status = LibraryAutomationSystem.Entities.Enum.Status.AllLoaned;
        }
        else
        {
            book.Status = LibraryAutomationSystem.Entities.Enum.Status.Loanable;
        }
    }
}
