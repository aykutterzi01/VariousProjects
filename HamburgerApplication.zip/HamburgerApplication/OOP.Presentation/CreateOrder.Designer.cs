﻿namespace OOP.Presentation
{
    partial class CreateOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            dgw_Food = new DataGridView();
            label2 = new Label();
            dgw_Extra = new DataGridView();
            groupBox1 = new GroupBox();
            rdbtn_Large = new RadioButton();
            rdbtn_Medium = new RadioButton();
            rdbtn_Small = new RadioButton();
            label3 = new Label();
            nmrcud_Amount = new NumericUpDown();
            btn_Add_Order = new Button();
            dgw_Orders = new DataGridView();
            label4 = new Label();
            lbl_Total_Price = new Label();
            btn_Finish_Order = new Button();
            lbl_TotalPrice = new Label();
            groupBox2 = new GroupBox();
            rdbtn_Cash = new RadioButton();
            rdbtn_Credit_Card = new RadioButton();
            ((System.ComponentModel.ISupportInitialize)dgw_Food).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Extra).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nmrcud_Amount).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Orders).BeginInit();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(16, 16);
            label1.Name = "label1";
            label1.Size = new Size(112, 20);
            label1.TabIndex = 0;
            label1.Text = "CHOOSE FOOD";
            // 
            // dgw_Food
            // 
            dgw_Food.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Food.Location = new Point(21, 46);
            dgw_Food.MultiSelect = false;
            dgw_Food.Name = "dgw_Food";
            dgw_Food.RowHeadersWidth = 51;
            dgw_Food.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgw_Food.Size = new Size(463, 120);
            dgw_Food.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.Location = new Point(513, 16);
            label2.Name = "label2";
            label2.Size = new Size(119, 20);
            label2.TabIndex = 2;
            label2.Text = "CHOOSE EXTRA";
            // 
            // dgw_Extra
            // 
            dgw_Extra.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Extra.Location = new Point(513, 46);
            dgw_Extra.Name = "dgw_Extra";
            dgw_Extra.RowHeadersWidth = 51;
            dgw_Extra.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgw_Extra.Size = new Size(354, 120);
            dgw_Extra.TabIndex = 3;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rdbtn_Large);
            groupBox1.Controls.Add(rdbtn_Medium);
            groupBox1.Controls.Add(rdbtn_Small);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(24, 182);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(330, 67);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "CHOOSE SIZE";
            // 
            // rdbtn_Large
            // 
            rdbtn_Large.AutoSize = true;
            rdbtn_Large.Location = new Point(239, 26);
            rdbtn_Large.Name = "rdbtn_Large";
            rdbtn_Large.Size = new Size(69, 24);
            rdbtn_Large.TabIndex = 6;
            rdbtn_Large.TabStop = true;
            rdbtn_Large.Text = "Large";
            rdbtn_Large.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Medium
            // 
            rdbtn_Medium.AutoSize = true;
            rdbtn_Medium.Location = new Point(122, 26);
            rdbtn_Medium.Name = "rdbtn_Medium";
            rdbtn_Medium.Size = new Size(88, 24);
            rdbtn_Medium.TabIndex = 5;
            rdbtn_Medium.TabStop = true;
            rdbtn_Medium.Text = "Medium";
            rdbtn_Medium.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Small
            // 
            rdbtn_Small.AutoSize = true;
            rdbtn_Small.Location = new Point(15, 26);
            rdbtn_Small.Name = "rdbtn_Small";
            rdbtn_Small.Size = new Size(68, 24);
            rdbtn_Small.TabIndex = 0;
            rdbtn_Small.TabStop = true;
            rdbtn_Small.Text = "Small";
            rdbtn_Small.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label3.Location = new Point(387, 193);
            label3.Name = "label3";
            label3.Size = new Size(143, 20);
            label3.TabIndex = 5;
            label3.Text = "CHOOSE AMOUNT:";
            // 
            // nmrcud_Amount
            // 
            nmrcud_Amount.Location = new Point(387, 216);
            nmrcud_Amount.Name = "nmrcud_Amount";
            nmrcud_Amount.Size = new Size(150, 27);
            nmrcud_Amount.TabIndex = 6;
            // 
            // btn_Add_Order
            // 
            btn_Add_Order.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btn_Add_Order.Location = new Point(579, 193);
            btn_Add_Order.Name = "btn_Add_Order";
            btn_Add_Order.Size = new Size(288, 50);
            btn_Add_Order.TabIndex = 7;
            btn_Add_Order.Text = "ADD ORDER";
            btn_Add_Order.UseVisualStyleBackColor = true;
            btn_Add_Order.Click += btn_Add_Order_Click;
            // 
            // dgw_Orders
            // 
            dgw_Orders.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Orders.Location = new Point(24, 267);
            dgw_Orders.Name = "dgw_Orders";
            dgw_Orders.RowHeadersWidth = 51;
            dgw_Orders.Size = new Size(627, 176);
            dgw_Orders.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label4.Location = new Point(668, 267);
            label4.Name = "label4";
            label4.Size = new Size(103, 20);
            label4.TabIndex = 9;
            label4.Text = "TOTAL PRICE:";
            // 
            // lbl_Total_Price
            // 
            lbl_Total_Price.AutoSize = true;
            lbl_Total_Price.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            lbl_Total_Price.ForeColor = Color.Red;
            lbl_Total_Price.Location = new Point(688, 276);
            lbl_Total_Price.Name = "lbl_Total_Price";
            lbl_Total_Price.Size = new Size(0, 20);
            lbl_Total_Price.TabIndex = 10;
            // 
            // btn_Finish_Order
            // 
            btn_Finish_Order.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btn_Finish_Order.Location = new Point(668, 401);
            btn_Finish_Order.Name = "btn_Finish_Order";
            btn_Finish_Order.Size = new Size(199, 42);
            btn_Finish_Order.TabIndex = 11;
            btn_Finish_Order.Text = "FINISH ORDER";
            btn_Finish_Order.UseVisualStyleBackColor = true;
            btn_Finish_Order.Click += btn_Finish_Order_Click;
            // 
            // lbl_TotalPrice
            // 
            lbl_TotalPrice.AutoSize = true;
            lbl_TotalPrice.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            lbl_TotalPrice.ForeColor = Color.Red;
            lbl_TotalPrice.Location = new Point(791, 267);
            lbl_TotalPrice.Name = "lbl_TotalPrice";
            lbl_TotalPrice.Size = new Size(0, 20);
            lbl_TotalPrice.TabIndex = 12;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(rdbtn_Credit_Card);
            groupBox2.Controls.Add(rdbtn_Cash);
            groupBox2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox2.Location = new Point(668, 299);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(199, 96);
            groupBox2.TabIndex = 13;
            groupBox2.TabStop = false;
            groupBox2.Text = "PAYMENT TYPE:";
            // 
            // rdbtn_Cash
            // 
            rdbtn_Cash.AutoSize = true;
            rdbtn_Cash.Location = new Point(13, 26);
            rdbtn_Cash.Name = "rdbtn_Cash";
            rdbtn_Cash.Size = new Size(63, 24);
            rdbtn_Cash.TabIndex = 0;
            rdbtn_Cash.TabStop = true;
            rdbtn_Cash.Text = "Cash";
            rdbtn_Cash.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Credit_Card
            // 
            rdbtn_Credit_Card.AutoSize = true;
            rdbtn_Credit_Card.Location = new Point(13, 56);
            rdbtn_Credit_Card.Name = "rdbtn_Credit_Card";
            rdbtn_Credit_Card.Size = new Size(108, 24);
            rdbtn_Credit_Card.TabIndex = 14;
            rdbtn_Credit_Card.TabStop = true;
            rdbtn_Credit_Card.Text = "Credit Card";
            rdbtn_Credit_Card.UseVisualStyleBackColor = true;
            // 
            // CreateOrder
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(914, 483);
            Controls.Add(groupBox2);
            Controls.Add(lbl_TotalPrice);
            Controls.Add(btn_Finish_Order);
            Controls.Add(lbl_Total_Price);
            Controls.Add(label4);
            Controls.Add(dgw_Orders);
            Controls.Add(btn_Add_Order);
            Controls.Add(nmrcud_Amount);
            Controls.Add(label3);
            Controls.Add(groupBox1);
            Controls.Add(dgw_Extra);
            Controls.Add(label2);
            Controls.Add(dgw_Food);
            Controls.Add(label1);
            Name = "CreateOrder";
            Text = "CreateOrder";
            WindowState = FormWindowState.Maximized;
            Load += CreateOrder_Load;
            ((System.ComponentModel.ISupportInitialize)dgw_Food).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Extra).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nmrcud_Amount).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Orders).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private DataGridView dgw_Food;
        private Label label2;
        private DataGridView dgw_Extra;
        private GroupBox groupBox1;
        private RadioButton rdbtn_Large;
        private RadioButton rdbtn_Medium;
        private RadioButton rdbtn_Small;
        private Label label3;
        private NumericUpDown nmrcud_Amount;
        private Button btn_Add_Order;
        private DataGridView dgw_Orders;
        private Label label4;
        private Label lbl_Total_Price;
        private Button btn_Finish_Order;
        private Label lbl_TotalPrice;
        private GroupBox groupBox2;
        private RadioButton rdbtn_Credit_Card;
        private RadioButton rdbtn_Cash;
    }
}