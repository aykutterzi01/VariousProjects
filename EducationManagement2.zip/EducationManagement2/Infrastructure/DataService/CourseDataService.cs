﻿using Infrastructure.Interfaces;
using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.DataService
{
    public class CourseDataService : BaseDataService<Course>, ICourseDataService
    {
    }
}
