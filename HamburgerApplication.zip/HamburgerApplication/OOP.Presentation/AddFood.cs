﻿using OOP.Applicationn.FoodService;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Presentation
{
    public partial class AddFood : Form
    {
        FoodService _foodService;
        public AddFood(FoodService foodService)
        {
            InitializeComponent();
            _foodService = foodService;
        }

        private void btn_Save_Food_Click(object sender, EventArgs e)
        {
            if (nmrcud_Food_Price.Value != 0)
            {
                Food food = new Food();
                food.Name = txt_Food_Name.Text;
                food.Price = nmrcud_Food_Price.Value;
                _foodService.Create(food);

                MessageBox.Show("Food has been added.");
            }
            else
            {
                MessageBox.Show("The price can not be zero!");
            }
        }
    }
}
