﻿using Models.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.Models;

public class TeacherCourse : BaseModel
{
    public Guid TeacherId { get; set; }
    public Guid CourseId { get; set; }
}
