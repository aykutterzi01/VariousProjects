﻿namespace Presentation
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            label2 = new Label();
            btnRegister = new Button();
            btnLogin = new Button();
            btnManageMembers = new Button();
            btnManageBooks = new Button();
            btnManageLoans = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(800, 450);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(192, 64, 0);
            label1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.ForeColor = Color.Transparent;
            label1.Location = new Point(296, 28);
            label1.Name = "label1";
            label1.Size = new Size(197, 38);
            label1.TabIndex = 1;
            label1.Text = "WELCOME TO";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(192, 64, 0);
            label2.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.ForeColor = Color.Transparent;
            label2.Location = new Point(178, 117);
            label2.Name = "label2";
            label2.Size = new Size(443, 38);
            label2.TabIndex = 2;
            label2.Text = "LIBRARY AUTOMATION SYSTEM";
            // 
            // btnRegister
            // 
            btnRegister.BackColor = Color.FromArgb(192, 64, 0);
            btnRegister.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnRegister.ForeColor = Color.White;
            btnRegister.Location = new Point(278, 209);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(111, 86);
            btnRegister.TabIndex = 3;
            btnRegister.Text = "REGISTER";
            btnRegister.UseVisualStyleBackColor = false;
            btnRegister.Click += btnRegister_Click;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.FromArgb(192, 64, 0);
            btnLogin.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnLogin.ForeColor = Color.White;
            btnLogin.Location = new Point(405, 209);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(112, 86);
            btnLogin.TabIndex = 4;
            btnLogin.Text = "LOGIN";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnManageMembers
            // 
            btnManageMembers.BackColor = Color.FromArgb(192, 64, 0);
            btnManageMembers.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnManageMembers.ForeColor = Color.White;
            btnManageMembers.Location = new Point(194, 323);
            btnManageMembers.Name = "btnManageMembers";
            btnManageMembers.Size = new Size(131, 86);
            btnManageMembers.TabIndex = 5;
            btnManageMembers.Text = "MANAGE MEMBERS";
            btnManageMembers.UseVisualStyleBackColor = false;
            btnManageMembers.Click += btnManageMembers_Click;
            // 
            // btnManageBooks
            // 
            btnManageBooks.BackColor = Color.FromArgb(192, 64, 0);
            btnManageBooks.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnManageBooks.ForeColor = Color.White;
            btnManageBooks.Location = new Point(331, 323);
            btnManageBooks.Name = "btnManageBooks";
            btnManageBooks.Size = new Size(128, 86);
            btnManageBooks.TabIndex = 6;
            btnManageBooks.Text = "MANAGE BOOKS";
            btnManageBooks.UseVisualStyleBackColor = false;
            btnManageBooks.Click += btnManageBooks_Click;
            // 
            // btnManageLoans
            // 
            btnManageLoans.BackColor = Color.FromArgb(192, 64, 0);
            btnManageLoans.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnManageLoans.ForeColor = Color.White;
            btnManageLoans.Location = new Point(465, 323);
            btnManageLoans.Name = "btnManageLoans";
            btnManageLoans.Size = new Size(127, 86);
            btnManageLoans.TabIndex = 7;
            btnManageLoans.Text = "MANAGE LOANS";
            btnManageLoans.UseVisualStyleBackColor = false;
            btnManageLoans.Click += btnManageLoans_Click;
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnManageLoans);
            Controls.Add(btnManageBooks);
            Controls.Add(btnManageMembers);
            Controls.Add(btnLogin);
            Controls.Add(btnRegister);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "MainForm";
            Text = "Form1";
            Load += MainForm_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private Label label2;
        private Button btnRegister;
        private Button btnLogin;
        private Button btnManageMembers;
        private Button btnManageBooks;
        private Button btnManageLoans;
    }
}
