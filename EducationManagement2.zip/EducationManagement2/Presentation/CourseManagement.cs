﻿using Applicationn.CourseService;
using Models.Models;
using Presentation.VMs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class CourseManagement : Form
    {
        CourseService _courseService;
        public CourseManagement(CourseService courseService)
        {
            InitializeComponent();
            _courseService = courseService;
        }

        private void btnCourseAdd_Click(object sender, EventArgs e)
        {
            Course course = new Course()
            {
                Name = txtCourseName.Text,
                Code = txtCourseCode.Text,
            };

            _courseService.Create(course);
            ResetTable();
        }

        private void ResetTable()
        {
            dgwCourses.DataSource = null;

            var courses = _courseService.GetAll();

            List<CourseListVM> courseList = new List<CourseListVM>();

            foreach (var course in courses)
            {
                CourseListVM courseListVM = new CourseListVM()
                {
                    Id = course.Id,
                    Name = course.Name,
                    Code = course.Code,
                };

                courseList.Add(courseListVM);
            }

            dgwCourses.DataSource = courseList;
            dgwCourses.Columns["Id"].Visible = false;
            Clean();
        }

        private void Clean()
        {
            txtCourseName.Text = string.Empty;
            txtCourseCode.Text = string.Empty;
        }

        private Guid SelectId()
        {
            var id = ((CourseListVM)dgwCourses.SelectedRows[0].DataBoundItem).Id;
            lblCourseId.Text = id.ToString();
            return id;
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var deletedCourse = _courseService.Get(SelectId());
            _courseService.Delete(deletedCourse);
            ResetTable();
        }

        private void CourseManagement_Load(object sender, EventArgs e)
        {
            btnCourseUpdated.Enabled = false;
            ResetTable();
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var updatedCourse = _courseService.Get(SelectId());
            txtCourseName.Text = updatedCourse.Name;
            txtCourseCode.Text = updatedCourse.Code;
            btnCourseUpdated.Enabled = true;
        }

        private void btnCourseUpdated_Click(object sender, EventArgs e)
        {
            Course course = new Course()
            {
                Id = Guid.Parse(lblCourseId.Text),
                Name = txtCourseName.Text,
                Code = txtCourseCode.Text,
            };

            _courseService.Update(course);
            ResetTable();
        }
    }
}
