﻿namespace Presentation
{
    partial class PayrollMangement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            cmbMonth = new ComboBox();
            label2 = new Label();
            cmbPersonnel = new ComboBox();
            label1 = new Label();
            nudWorkingHour = new NumericUpDown();
            lblSalary = new Label();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            dgwPayrolls = new DataGridView();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudWorkingHour).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgwPayrolls).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ActiveCaption;
            groupBox1.Controls.Add(cmbMonth);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(cmbPersonnel);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(nudWorkingHour);
            groupBox1.Controls.Add(lblSalary);
            groupBox1.Controls.Add(btnDelete);
            groupBox1.Controls.Add(btnUpdate);
            groupBox1.Controls.Add(btnAdd);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(761, 202);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "PAYROLL DETAILS";
            // 
            // cmbMonth
            // 
            cmbMonth.FormattingEnabled = true;
            cmbMonth.Location = new Point(165, 90);
            cmbMonth.Name = "cmbMonth";
            cmbMonth.Size = new Size(214, 36);
            cmbMonth.TabIndex = 0;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(84, 93);
            label2.Name = "label2";
            label2.Size = new Size(75, 28);
            label2.TabIndex = 16;
            label2.Text = "Month:";
            // 
            // cmbPersonnel
            // 
            cmbPersonnel.FormattingEnabled = true;
            cmbPersonnel.Location = new Point(165, 40);
            cmbPersonnel.Name = "cmbPersonnel";
            cmbPersonnel.Size = new Size(214, 36);
            cmbPersonnel.TabIndex = 15;
            cmbPersonnel.SelectedIndexChanged += cmbPersonnel_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(59, 43);
            label1.Name = "label1";
            label1.Size = new Size(100, 28);
            label1.TabIndex = 14;
            label1.Text = "Personnel:";
            // 
            // nudWorkingHour
            // 
            nudWorkingHour.Location = new Point(165, 142);
            nudWorkingHour.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            nudWorkingHour.Name = "nudWorkingHour";
            nudWorkingHour.Size = new Size(214, 34);
            nudWorkingHour.TabIndex = 13;
            // 
            // lblSalary
            // 
            lblSalary.AutoSize = true;
            lblSalary.Location = new Point(14, 144);
            lblSalary.Name = "lblSalary";
            lblSalary.Size = new Size(145, 28);
            lblSalary.TabIndex = 12;
            lblSalary.Text = "Working Hour :";
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(640, 70);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 74);
            btnDelete.TabIndex = 11;
            btnDelete.Text = "DELETE";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(524, 70);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 74);
            btnUpdate.TabIndex = 10;
            btnUpdate.Text = "UPDATE";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(411, 70);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 74);
            btnAdd.TabIndex = 9;
            btnAdd.Text = "ADD";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // dgwPayrolls
            // 
            dgwPayrolls.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwPayrolls.Location = new Point(13, 227);
            dgwPayrolls.MultiSelect = false;
            dgwPayrolls.Name = "dgwPayrolls";
            dgwPayrolls.ReadOnly = true;
            dgwPayrolls.RowHeadersWidth = 51;
            dgwPayrolls.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwPayrolls.Size = new Size(760, 188);
            dgwPayrolls.TabIndex = 6;
            dgwPayrolls.RowHeaderMouseClick += dgwPayrolls_RowHeaderMouseClick;
            // 
            // PayrollMangement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(800, 450);
            Controls.Add(dgwPayrolls);
            Controls.Add(groupBox1);
            ForeColor = SystemColors.ControlText;
            Name = "PayrollMangement";
            Text = "PayrollMangement";
            Load += PayrollMangement_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudWorkingHour).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgwPayrolls).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label1;
        private NumericUpDown nudWorkingHour;
        private Label lblSalary;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private ComboBox cmbPersonnel;
        private ComboBox cmbMonth;
        private Label label2;
        private DataGridView dgwPayrolls;
    }
}