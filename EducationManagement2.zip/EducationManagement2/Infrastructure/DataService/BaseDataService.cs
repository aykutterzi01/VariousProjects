﻿using Infrastructure.Interfaces;
using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Infrastructure.DataService
{
    public class BaseDataService<T> : IBaseDataService<T> where T : BaseModel
    {
        private readonly string _file;

        public BaseDataService()
        {
            _file = $@"C:\Users\Lenovo\Desktop\HS14\EducationManagement2\EducationManagement2\{typeof(T).Name}.json";
        }

        public List<T> GetData()
        {
            var dataJ = File.ReadAllText(_file);

            if (!string.IsNullOrWhiteSpace(dataJ))
            {
                return JsonSerializer.Deserialize<List<T>>(dataJ) ?? new List<T>();
            }
            else
            {
                return new List<T>();
            }
        }

        public void Save(List<T> data)
        {
            var dataJ = JsonSerializer.Serialize(data);
            File.WriteAllText(_file, dataJ);
        }
    }
}
