﻿using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.EkstraService
{
    public interface IEkstraService
    {
        public void Create(Ekstra ekstra);
        public void Delete(Ekstra ekstra);
        public Ekstra Get(Guid id);
        public List<Ekstra> GetAll();

        public void Update(Ekstra ekstra);
    }
}
