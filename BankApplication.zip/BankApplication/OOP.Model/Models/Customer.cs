﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOP.Model.Models.Enums;

namespace OOP.Model.Models
{
    public class Customer : BaseModel
    {
        public required string Name { get; set; }
        public required string Surname { get; set; }
        public required string Email { get; set; }
        public required string City { get; set; }
        public required CustomerType CustomerType { get; set; }

        private decimal _commissionRatio;

        public decimal CommissionRatio
        {
            get { return _commissionRatio; }
            set 
            { 
                if (CustomerType == CustomerType.Standard)
                {
                    _commissionRatio = 0.02m;
                }
                else
                {
                    _commissionRatio = 0;
                }
                 
            }
        }


        private string _university;

        public string University
        {
            get { return _university; }
            set 
            { 
                if (CustomerType == CustomerType.Student)
                {
                    _university = value;
                }
                else
                {
                    _university = "(Not applicable)";
                }
            }
        }

        public override string ToString()
        {
            if (CustomerType == CustomerType.Standard)
            {
                return $"{Name} {Surname} | {Email} | {City}";
            }
            else
            {
                return $"{Name} {Surname} | {Email} | {City} | {University}";
            }         
        }
    }
}
