﻿using Applicationn.CourseService;
using Applicationn.TeacherCourseService;
using Applicationn.TeacherService;
using Models.Models;
using Presentation.VMs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class TeacherManagement : Form
    {
        CourseService _courseService;
        TeacherService _teacherService;
        TeacherCourseService _teacherCourseService;

        public TeacherManagement(CourseService courseService, TeacherService teacherService, TeacherCourseService teacherCourseService)
        {
            InitializeComponent();
            _courseService = courseService;
            _teacherService = teacherService;
            _teacherCourseService = teacherCourseService;
        }

        private void TeacherManagement_Load(object sender, EventArgs e)
        {
            btnTeacherUpdate.Enabled = false;
            ResetTable();
        }

        private void ResetTable()
        {
            dgwAssignments.DataSource = null;

            var teachers = _teacherService.GetAll();
            List<TeacherListVM> teacherList = new List<TeacherListVM>();

            foreach (var teacher in teachers)
            {
                var teacherCourses = _teacherCourseService.GetAll().Where(x => x.TeacherId == teacher.Id);

                TeacherListVM teacherListVM = new TeacherListVM();

                teacherListVM.Id = teacher.Id;
                teacherListVM.FullName = teacher.Name + " " + teacher.Surname;
                teacherListVM.Email = teacher.Email;

                foreach (var teacherCourse in teacherCourses)
                {
                    teacherListVM.Courses = teacherListVM.Courses + " - " + _courseService.Get(teacherCourse.CourseId).Name + " | " + _courseService.Get(teacherCourse.CourseId).Code;
                }

                teacherList.Add(teacherListVM);
            }

            dgwAssignments.DataSource = teacherList;
            dgwAssignments.Columns["Id"].Visible = false;

            lbCourses.DataSource = null;
            lbCourses.DataSource = _courseService.GetAll();
            lbCourses.DisplayMember = "FullName";
            lbCourses.ValueMember = "Id";

            lbCourses.SelectedIndex = -1;

            Clean();
        }

        private void Clean()
        {
            txtTeacherName.Text = string.Empty;
            txtTeacherSurnam.Text = string.Empty;
            txtTeacherEmail.Text = string.Empty;
        }

        private void btnTeacherAdd_Click(object sender, EventArgs e)
        {
            Teacher teacher = new Teacher()
            {
                Name = txtTeacherName.Text,
                Surname = txtTeacherSurnam.Text,
                Email = txtTeacherEmail.Text,
            };

            _teacherService.Create(teacher);

            var addedTeacher = _teacherService.GetAll().LastOrDefault();

            var selectedCourses = lbCourses.SelectedItems;

            foreach (Course selectedCourse in selectedCourses)
            {
                TeacherCourse teacherCourse = new TeacherCourse();
                teacherCourse.TeacherId = addedTeacher.Id;
                teacherCourse.CourseId = selectedCourse.Id;
                _teacherCourseService.Create(teacherCourse);
            }

            ResetTable();
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var deletedTeacher = _teacherService.Get(SelectedId());
            _teacherService.Delete(deletedTeacher);

            var deletedTeacherCourses = _teacherCourseService.GetAll().Where(x => x.TeacherId == deletedTeacher.Id);
            foreach (var deletedTeacherCourse in deletedTeacherCourses)
            {
                _teacherCourseService.Delete(deletedTeacherCourse);
            }

            ResetTable();
        }

        private Guid SelectedId()
        {
            var id = ((TeacherListVM)(dgwAssignments.SelectedRows[0].DataBoundItem)).Id;
            lblAssigmentId.Text = id.ToString();
            return id;
        }

        private void updateToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var selectedId = SelectedId();
            var updatedTeacher = _teacherService.Get(selectedId);

            txtTeacherName.Text = updatedTeacher.Name;
            txtTeacherSurnam.Text = updatedTeacher.Surname;
            txtTeacherEmail.Text = updatedTeacher.Email;

            btnTeacherUpdate.Enabled = true;

            var selectedTeacherCourses = _teacherCourseService.GetAll().Where(x => x.TeacherId == selectedId);

            List<Course> selectedCourses = new List<Course>();

            foreach (TeacherCourse selectedTeacherCourse in selectedTeacherCourses)
            {
                var selectedCourse = _courseService.GetAll().FirstOrDefault(x => x.Id == selectedTeacherCourse.CourseId);
                selectedCourses.Add(selectedCourse);
            }

            List<Course> courses = lbCourses.DataSource as List<Course>;

            foreach (Course course in courses)
            {
                foreach (var selectedCourse in selectedCourses)
                {
                    if (course.Id == selectedCourse.Id)
                    {
                        lbCourses.SelectedItems.Add(course);
                    }
                }
            }


        }

        private void btnTeacherUpdate_Click(object sender, EventArgs e)
        {
            Teacher teacher = new Teacher()
            {
                Id = Guid.Parse(lblAssigmentId.Text),
                Name = txtTeacherName.Text,
                Surname = txtTeacherSurnam.Text,
                Email = txtTeacherEmail.Text,
            };

            _teacherService.Update(teacher);
            btnTeacherUpdate.Enabled = false;

            var newSelectedCourses = lbCourses.SelectedItems.Cast<Course>().ToList();
            var oldTeacherCourses = _teacherCourseService.GetAll().Where(x => x.TeacherId == teacher.Id);

            List<Course> oldSelectedCourses = new List<Course>();

            foreach (var oldTeacherCourse in oldTeacherCourses)
            {
                oldSelectedCourses.Add(_courseService.Get(oldTeacherCourse.CourseId));
            }

            var deletedCourses = oldSelectedCourses.Except(newSelectedCourses);
            var addedCourses = newSelectedCourses.Except(oldSelectedCourses);

            foreach (var deletedCourse in deletedCourses)
            {
                var deletedTeacherCourse = _teacherCourseService.GetAll().FirstOrDefault(x => x.CourseId == deletedCourse.Id && x.TeacherId == teacher.Id);
                _teacherCourseService.Delete(deletedTeacherCourse);
            }

            foreach (var addedCourse in addedCourses)
            {
                TeacherCourse teacherCourse = new TeacherCourse()
                {
                    TeacherId = teacher.Id,
                    CourseId = addedCourse.Id
                };

                _teacherCourseService.Create(teacherCourse);
            }

            ResetTable();
        }
    }
}
