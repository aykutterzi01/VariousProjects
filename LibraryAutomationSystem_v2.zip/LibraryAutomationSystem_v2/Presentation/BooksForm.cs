﻿using Business.Services;
using LibraryAutomationSystem.Context;
using LibraryAutomationSystem.Entities;
using LibraryAutomationSystem.Methods;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class BooksForm : Form
    {
        BookService _bookService;

        public BooksForm(BookService bookService)
        {
            InitializeComponent();
            _bookService = bookService;
        }

        private void rdbtnHistory_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnHistory.Checked == true)
            {
                lblPeriod.Visible = true;
                txtPeriod.Visible = true;

                lblThema.Visible = false;
                txtThema.Visible = false;

                txtDomain.Visible = false;
                lblDomain.Visible = false;
            }
        }

        private void rdbtnNovel_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnNovel.Checked == true)
            {
                lblPeriod.Visible = false;
                txtPeriod.Visible = false;

                lblThema.Visible = true;
                txtThema.Visible = true;

                txtDomain.Visible = false;
                lblDomain.Visible = false;
            }
        }

        private void rdbtnScience_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnScience.Checked == true)
            {
                lblPeriod.Visible = false;
                txtPeriod.Visible = false;

                lblThema.Visible = false;
                txtThema.Visible = false;

                txtDomain.Visible = true;
                lblDomain.Visible = true;
            }
        }

        private void ManageBooksForm_Load(object sender, EventArgs e)
        {
            rdbtnHistory.Checked = true;
            ResetTable();
        }

        private void btnAddMember_Click(object sender, EventArgs e)
        {
            if (rdbtnHistory.Checked == true)
            {
                Book book = new BookHistory()
                {
                    ISBN = txtISBN.Text,
                    Title = txtTitle.Text,
                    Author = txtAuthor.Text,
                    PublishYear = Convert.ToInt32(mtbPublishYear.Text),
                    LoanableAmount = Convert.ToInt32(nudAmount.Value),
                    Period = txtPeriod.Text,
                };

                Status.SetStatus(book);

                _bookService.Create(book);
            }
            else if (rdbtnNovel.Checked == true)
            {
                Book book = new BookNovel()
                {
                    ISBN = txtISBN.Text,
                    Title = txtTitle.Text,
                    Author = txtAuthor.Text,
                    PublishYear = Convert.ToInt32(mtbPublishYear.Text),
                    LoanableAmount = Convert.ToInt32(nudAmount.Value),
                    Thema = txtThema.Text
                };

                Status.SetStatus(book);

                _bookService.Create(book);
            }
            else
            {
                Book book = new BookScience()
                {
                    ISBN = txtISBN.Text,
                    Title = txtTitle.Text,
                    Author = txtAuthor.Text,
                    PublishYear = Convert.ToInt32(mtbPublishYear.Text),
                    LoanableAmount = Convert.ToInt32(nudAmount.Value),
                    Domain = txtDomain.Text
                };

                Status.SetStatus(book);

                _bookService.Create(book);
            }

 

            MessageBox.Show("The book has been added.");

            ResetTable();
            CleanTexts();
        }

        private void CleanTexts()
        {
            txtISBN.Text = string.Empty;
            txtTitle.Text = string.Empty;
            txtAuthor.Text = string.Empty;
            mtbPublishYear.Text = string.Empty;
            nudAmount.Value = 0;
            txtPeriod.Text = string.Empty;
            txtThema.Text = string.Empty;
            txtDomain.Text = string.Empty;
        }

        private void ResetTable()
        {
            dgwBooks.DataSource = null;

            var books = _bookService.GetAll().Select(x => new
            {
                x.Id,
                x.ISBN,
                x.Title,
                x.Author,
                x.PublishYear,
                x.Discriminator,
                Period = (x.Discriminator == "BookHistory") ? ((BookHistory)x).Period : null,
                Thema = (x.Discriminator == "BookNovel") ? ((BookNovel)x).Thema : null,
                Domain = (x.Discriminator == "BookScience") ? ((BookScience)x).Domain : null,
                x.Status,
                x.LoanableAmount,
                x.LoanedAmount
            }).ToList();

            dgwBooks.DataSource = books;
            dgwBooks.Columns["Id"].Visible = false;
        }

        private void btnDeleteMember_Click(object sender, EventArgs e)
        {
            var bookId = (Guid)(dgwBooks.SelectedRows[0].Cells[0]).Value;
            var book = _bookService.GetAll().FirstOrDefault(x => x.Id == bookId);

            if (book.LoanedAmount > 0)
            {
                MessageBox.Show("There are loaned books. The book can not be deleted!");
                return;
            }
            else
            {
                _bookService.Delete(book);

                MessageBox.Show("The book has been deleted.");
            }

            ResetTable();
            CleanTexts();
        }

        private void dgwBooks_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var bookId = (Guid)(dgwBooks.SelectedRows[0].Cells[0]).Value;
            var book = _bookService.GetAll().FirstOrDefault(x => x.Id == bookId);

            txtISBN.Text = book.ISBN;
            txtTitle.Text = book.Title;
            txtAuthor.Text = book.Author;
            mtbPublishYear.Text = book.PublishYear.ToString();
            nudAmount.Value = book.LoanableAmount;
            if (book is BookNovel bookNovel)
            {
                rdbtnNovel.Checked = true;
                txtThema.Text = bookNovel.Thema;
            }
            if (book is BookHistory bookHistory)
            {
                rdbtnHistory.Checked = true;
                txtPeriod.Text = bookHistory.Period;
            }
            if (book is BookScience bookScience)
            {
                rdbtnScience.Checked = true;
                txtDomain.Text = bookScience.Domain;
            }

        }

        private void btnUpdateMember_Click(object sender, EventArgs e)
        {
            var bookId = (Guid)(dgwBooks.SelectedRows[0].Cells[0]).Value;
            var book = _bookService.GetAll().FirstOrDefault(x => x.Id == bookId);

            book.ISBN = txtISBN.Text;
            book.Title = txtTitle.Text;
            book.Author = txtAuthor.Text;
            book.PublishYear = Convert.ToInt32(mtbPublishYear.Text);
            book.LoanableAmount = Convert.ToInt32(nudAmount.Value);

            if (book is BookNovel bookNovel)
            {
                rdbtnNovel.Checked = true;
                bookNovel.Thema = txtThema.Text;
            }
            if (book is BookHistory bookHistory)
            {
                rdbtnHistory.Checked = true;
                bookHistory.Period = txtPeriod.Text;
            }
            if (book is BookScience bookScience)
            {
                rdbtnScience.Checked = true;
                bookScience.Domain = txtDomain.Text;
            }

            Status.SetStatus(book);

            _bookService.Update(book);

            MessageBox.Show("The book has been updated.");

            ResetTable();
            CleanTexts();
        }
    }
}
