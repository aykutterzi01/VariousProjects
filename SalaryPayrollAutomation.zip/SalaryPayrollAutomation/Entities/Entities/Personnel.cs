﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Entities;

public abstract class Personnel : BaseEntity
{
    public string Name { get; set; }
    public string Surname { get; set; }
    public string Discriminator { get; set; }
	public abstract decimal HourlyFee { get; set; }


	public List<Payroll> Payrolls { get; set; }

    public override string ToString()
    {
        return Name + " " + Surname + " | " + Discriminator;
    }
}
