﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LibraryAutomationSystem.Migrations
{
    /// <inheritdoc />
    public partial class Fifth : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "LonableAmount",
                table: "Books",
                newName: "LoanableAmount");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "LoanableAmount",
                table: "Books",
                newName: "LonableAmount");
        }
    }
}
