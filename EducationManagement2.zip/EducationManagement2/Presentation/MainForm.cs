using Applicationn.CourseService;
using Applicationn.StudentService;
using Applicationn.StudentTeacherCourseService;
using Applicationn.TeacherCourseService;
using Applicationn.TeacherService;

namespace Presentation
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        CourseService _courseService = new CourseService();
        TeacherService _teacherService = new TeacherService();
        TeacherCourseService _teacherCourseService = new TeacherCourseService();
        StudentTeacherCourseService _studentTeacherCourseService = new StudentTeacherCourseService();
        StudentService _studentService = new StudentService();

        private void courseMangementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CourseManagement courseManagement = new CourseManagement(_courseService);
            courseManagement.ShowDialog();
        }

        private void teacherManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TeacherManagement teacherManagement = new TeacherManagement(_courseService, _teacherService, _teacherCourseService);

            teacherManagement.ShowDialog();

        }

        private void studentManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StudentManagement studentManagement = new StudentManagement(_courseService, _teacherService, _teacherCourseService, _studentTeacherCourseService, _studentService);
            studentManagement.ShowDialog();
        }
    }
}
