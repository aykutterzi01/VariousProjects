using OOP.Applicationn.AccountService;
using OOP.Applicationn.CustomerService;
using OOP.Applicationn.TransferService;

namespace OOP.Presentation
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        CustomerService _customerService = new CustomerService();
        AccountService _accountService = new AccountService();
        TransferService _transferService = new TransferService();

        private void createAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateAccount createAccount = new CreateAccount(_customerService, _accountService);
            createAccount.MdiParent = MainForm.ActiveForm;
            createAccount.Show();
        }

        private void makeTransferToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MakeTransfer makeTransfer = new MakeTransfer(_customerService, _accountService, _transferService);
            makeTransfer.MdiParent = MainForm.ActiveForm;
            makeTransfer.Show();
        }

        private void customerManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CustomerManagement customerMangagement = new CustomerManagement(_customerService, _accountService);
            customerMangagement.MdiParent = MainForm.ActiveForm;
            customerMangagement.Show();
        }

        private void accountManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AccountManagement accountManagement = new AccountManagement(_customerService, _accountService);
            accountManagement.MdiParent = MainForm.ActiveForm;
            accountManagement.Show();
        }

        private void transferDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TransferDetails transferDetails = new TransferDetails(_customerService, _accountService, _transferService);
            transferDetails.MdiParent = MainForm.ActiveForm;
            transferDetails.Show();
        }
    }
}
