﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OOP.Model.Models.Enums;

namespace OOP.Model.Models
{
    public class Transfer : BaseModel
    {
        public Transfer()
        {
            DateTime = DateTime.Now;
        }
        public Transfer(Account account, decimal amount, TransferType transactionType, TransferChannel transferChannel)
        {
            DateTime = DateTime.Now;
            Account = account;
            Amount = amount;
            TransactionType = transactionType;
            TransferChannel = transferChannel;
        }

       public Transfer(Account account, decimal amount, TransferType transactionType, TransferChannel transferChannel, Account relatedAccount)
        {
            DateTime = DateTime.Now;
            Account = account;
            Amount = amount;
            TransactionType = transactionType;
            TransferChannel = transferChannel;
            RelatedAccount = relatedAccount;
        }

        public DateTime DateTime { get; set; }
        public Account Account { get; set; }
        public decimal Amount { get; set; }
        public TransferType TransactionType { get; set; }
        public TransferChannel TransferChannel { get; set; }

        public Account RelatedAccount { get; set; }

    }
}
