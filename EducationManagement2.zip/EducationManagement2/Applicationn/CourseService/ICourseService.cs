﻿using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applicationn.CourseService
{
    public interface ICourseService
    {
        public void Create(Course course);
        public void Delete(Course course);
        public Course Get(Guid id);
        public List<Course> GetAll();
        public void Update(Course course);
    }
}
