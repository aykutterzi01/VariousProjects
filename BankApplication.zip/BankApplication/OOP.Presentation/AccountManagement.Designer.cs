﻿namespace OOP.Presentation
{
    partial class AccountManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgw_Account_List = new DataGridView();
            label2 = new Label();
            dgw_Customer_List = new DataGridView();
            label1 = new Label();
            btn_Delete_Account = new Button();
            ((System.ComponentModel.ISupportInitialize)dgw_Account_List).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Customer_List).BeginInit();
            SuspendLayout();
            // 
            // dgw_Account_List
            // 
            dgw_Account_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Account_List.Location = new Point(11, 212);
            dgw_Account_List.MultiSelect = false;
            dgw_Account_List.Name = "dgw_Account_List";
            dgw_Account_List.RowHeadersWidth = 51;
            dgw_Account_List.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgw_Account_List.Size = new Size(772, 135);
            dgw_Account_List.TabIndex = 7;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.Location = new Point(8, 189);
            label2.Name = "label2";
            label2.Size = new Size(115, 20);
            label2.TabIndex = 6;
            label2.Text = "ACCOUNT LIST";
            // 
            // dgw_Customer_List
            // 
            dgw_Customer_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Customer_List.Location = new Point(12, 29);
            dgw_Customer_List.Name = "dgw_Customer_List";
            dgw_Customer_List.RowHeadersWidth = 51;
            dgw_Customer_List.Size = new Size(772, 157);
            dgw_Customer_List.TabIndex = 5;
            dgw_Customer_List.RowHeaderMouseClick += dgw_Customer_List_RowHeaderMouseClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(8, 6);
            label1.Name = "label1";
            label1.Size = new Size(122, 20);
            label1.TabIndex = 4;
            label1.Text = "CUSTOMER LIST";
            // 
            // btn_Delete_Account
            // 
            btn_Delete_Account.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btn_Delete_Account.Location = new Point(11, 365);
            btn_Delete_Account.Name = "btn_Delete_Account";
            btn_Delete_Account.Size = new Size(772, 59);
            btn_Delete_Account.TabIndex = 8;
            btn_Delete_Account.Text = "DELETE ACCOUNT";
            btn_Delete_Account.UseVisualStyleBackColor = true;
            btn_Delete_Account.Click += btn_Delete_Account_Click;
            // 
            // AccountManagement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(808, 459);
            Controls.Add(btn_Delete_Account);
            Controls.Add(dgw_Account_List);
            Controls.Add(label2);
            Controls.Add(dgw_Customer_List);
            Controls.Add(label1);
            Name = "AccountManagement";
            Text = "AccountManagement";
            WindowState = FormWindowState.Maximized;
            Load += AccountManagement_Load;
            ((System.ComponentModel.ISupportInitialize)dgw_Account_List).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Customer_List).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgw_Account_List;
        private Label label2;
        private DataGridView dgw_Customer_List;
        private Label label1;
        private Button btn_Delete_Account;
    }
}