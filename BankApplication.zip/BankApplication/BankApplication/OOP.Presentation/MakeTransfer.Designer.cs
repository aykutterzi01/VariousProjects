﻿namespace OOP.Presentation
{
    partial class MakeTransfer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            dgw_Customer_List = new DataGridView();
            label2 = new Label();
            dgw_Account_List = new DataGridView();
            groupBox1 = new GroupBox();
            rdbtn_Deposit = new RadioButton();
            btn_Withdrawal = new RadioButton();
            label3 = new Label();
            nmrcud_Amount = new NumericUpDown();
            btn_Transfer = new Button();
            label4 = new Label();
            dgw_Transfer_List = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgw_Customer_List).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Account_List).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nmrcud_Amount).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Transfer_List).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(12, 13);
            label1.Name = "label1";
            label1.Size = new Size(122, 20);
            label1.TabIndex = 0;
            label1.Text = "CUSTOMER LIST";
            // 
            // dgw_Customer_List
            // 
            dgw_Customer_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Customer_List.Location = new Point(16, 45);
            dgw_Customer_List.Name = "dgw_Customer_List";
            dgw_Customer_List.RowHeadersWidth = 51;
            dgw_Customer_List.Size = new Size(536, 100);
            dgw_Customer_List.TabIndex = 1;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.Location = new Point(19, 157);
            label2.Name = "label2";
            label2.Size = new Size(115, 20);
            label2.TabIndex = 2;
            label2.Text = "ACCOUNT LIST";
            // 
            // dgw_Account_List
            // 
            dgw_Account_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Account_List.Location = new Point(16, 180);
            dgw_Account_List.Name = "dgw_Account_List";
            dgw_Account_List.RowHeadersWidth = 51;
            dgw_Account_List.Size = new Size(536, 100);
            dgw_Account_List.TabIndex = 3;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btn_Transfer);
            groupBox1.Controls.Add(nmrcud_Amount);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(btn_Withdrawal);
            groupBox1.Controls.Add(rdbtn_Deposit);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(18, 297);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(534, 91);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "MAKE A TRANSFER";
            // 
            // rdbtn_Deposit
            // 
            rdbtn_Deposit.AutoSize = true;
            rdbtn_Deposit.Location = new Point(12, 26);
            rdbtn_Deposit.Name = "rdbtn_Deposit";
            rdbtn_Deposit.Size = new Size(84, 24);
            rdbtn_Deposit.TabIndex = 0;
            rdbtn_Deposit.TabStop = true;
            rdbtn_Deposit.Text = "Deposit";
            rdbtn_Deposit.UseVisualStyleBackColor = true;
            // 
            // btn_Withdrawal
            // 
            btn_Withdrawal.AutoSize = true;
            btn_Withdrawal.Location = new Point(12, 56);
            btn_Withdrawal.Name = "btn_Withdrawal";
            btn_Withdrawal.Size = new Size(111, 24);
            btn_Withdrawal.TabIndex = 5;
            btn_Withdrawal.TabStop = true;
            btn_Withdrawal.Text = "Withdrawal";
            btn_Withdrawal.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(151, 28);
            label3.Name = "label3";
            label3.Size = new Size(71, 20);
            label3.TabIndex = 6;
            label3.Text = "Amount:";
            // 
            // nmrcud_Amount
            // 
            nmrcud_Amount.Location = new Point(151, 53);
            nmrcud_Amount.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            nmrcud_Amount.Name = "nmrcud_Amount";
            nmrcud_Amount.Size = new Size(194, 27);
            nmrcud_Amount.TabIndex = 7;
            // 
            // btn_Transfer
            // 
            btn_Transfer.Location = new Point(365, 24);
            btn_Transfer.Name = "btn_Transfer";
            btn_Transfer.Size = new Size(163, 56);
            btn_Transfer.TabIndex = 8;
            btn_Transfer.Text = "TRANSFER";
            btn_Transfer.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label4.Location = new Point(16, 400);
            label4.Name = "label4";
            label4.Size = new Size(119, 20);
            label4.TabIndex = 5;
            label4.Text = "TRANSFER LIST";
            // 
            // dgw_Transfer_List
            // 
            dgw_Transfer_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Transfer_List.Location = new Point(16, 423);
            dgw_Transfer_List.Name = "dgw_Transfer_List";
            dgw_Transfer_List.RowHeadersWidth = 51;
            dgw_Transfer_List.Size = new Size(536, 100);
            dgw_Transfer_List.TabIndex = 6;
            // 
            // MakeTransfer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(582, 544);
            Controls.Add(dgw_Transfer_List);
            Controls.Add(label4);
            Controls.Add(groupBox1);
            Controls.Add(dgw_Account_List);
            Controls.Add(label2);
            Controls.Add(dgw_Customer_List);
            Controls.Add(label1);
            Name = "MakeTransfer";
            Text = "MakeTransfer";
            WindowState = FormWindowState.Maximized;
            ((System.ComponentModel.ISupportInitialize)dgw_Customer_List).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Account_List).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nmrcud_Amount).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Transfer_List).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private DataGridView dgw_Customer_List;
        private Label label2;
        private DataGridView dgw_Account_List;
        private GroupBox groupBox1;
        private Button btn_Transfer;
        private NumericUpDown nmrcud_Amount;
        private Label label3;
        private RadioButton btn_Withdrawal;
        private RadioButton rdbtn_Deposit;
        private Label label4;
        private DataGridView dgw_Transfer_List;
    }
}