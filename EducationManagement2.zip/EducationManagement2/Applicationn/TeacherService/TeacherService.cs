﻿using Infrastructure.DataService;
using Infrastructure.Interfaces;
using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applicationn.TeacherService
{
    public class TeacherService : ITeacherService
    {
        private readonly ITeacherDataService _teacherDataService;

        public TeacherService()
        {
            _teacherDataService = new TeacherDataService();
        }

        public void Create(Teacher teacher)
        {
            var teachers = _teacherDataService.GetData();
            teachers.Add(teacher);
            _teacherDataService.Save(teachers);
        }

        public void Delete(Teacher teacher)
        {
            var teachers = _teacherDataService.GetData();
            teachers.Remove(teachers.FirstOrDefault(x => x.Id == teacher.Id));
            _teacherDataService.Save(teachers);
        }

        public Teacher Get(Guid id)
        {
            var teachers = _teacherDataService.GetData();
            return teachers.FirstOrDefault(x => x.Id == id);
        }

        public List<Teacher> GetAll()
        {
            return _teacherDataService.GetData();
        }

        public void Update(Teacher teacher)
        {
            var teachers = _teacherDataService.GetData();
            var updatedTeacher = teachers.FirstOrDefault(x => x.Id == teacher.Id);
            var indexTeacher = teachers.IndexOf(updatedTeacher);
            teachers[indexTeacher] = teacher;
            _teacherDataService.Save(teachers);
        }
    }
}
