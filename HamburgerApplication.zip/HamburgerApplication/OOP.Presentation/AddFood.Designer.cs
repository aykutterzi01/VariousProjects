﻿namespace OOP.Presentation
{
    partial class AddFood
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            btn_Save_Food = new Button();
            nmrcud_Food_Price = new NumericUpDown();
            label2 = new Label();
            txt_Food_Name = new TextBox();
            label1 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nmrcud_Food_Price).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btn_Save_Food);
            groupBox1.Controls.Add(nmrcud_Food_Price);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txt_Food_Name);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(19, 29);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(372, 193);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "FOOD INFORMATION";
            // 
            // btn_Save_Food
            // 
            btn_Save_Food.Location = new Point(12, 118);
            btn_Save_Food.Name = "btn_Save_Food";
            btn_Save_Food.Size = new Size(341, 58);
            btn_Save_Food.TabIndex = 4;
            btn_Save_Food.Text = "SAVE FOOD";
            btn_Save_Food.UseVisualStyleBackColor = true;
            btn_Save_Food.Click += btn_Save_Food_Click;
            // 
            // nmrcud_Food_Price
            // 
            nmrcud_Food_Price.Location = new Point(119, 79);
            nmrcud_Food_Price.Name = "nmrcud_Food_Price";
            nmrcud_Food_Price.Size = new Size(234, 27);
            nmrcud_Food_Price.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(56, 80);
            label2.Name = "label2";
            label2.Size = new Size(47, 20);
            label2.TabIndex = 2;
            label2.Text = "Price:";
            // 
            // txt_Food_Name
            // 
            txt_Food_Name.Location = new Point(118, 37);
            txt_Food_Name.Name = "txt_Food_Name";
            txt_Food_Name.Size = new Size(235, 27);
            txt_Food_Name.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(9, 38);
            label1.Name = "label1";
            label1.Size = new Size(94, 20);
            label1.TabIndex = 0;
            label1.Text = "Food Name:";
            // 
            // AddFood
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(697, 419);
            Controls.Add(groupBox1);
            Name = "AddFood";
            Text = "AddFood";
            WindowState = FormWindowState.Maximized;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nmrcud_Food_Price).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button btn_Save_Food;
        private NumericUpDown nmrcud_Food_Price;
        private Label label2;
        private TextBox txt_Food_Name;
        private Label label1;
    }
}