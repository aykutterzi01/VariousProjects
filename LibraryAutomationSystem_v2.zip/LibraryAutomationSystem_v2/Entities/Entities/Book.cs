﻿using LibraryAutomationSystem.Entities.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryAutomationSystem.Entities;

public abstract class Book : BaseModel
{
    public string ISBN { get; set; }
    public string Title { get; set; }
    public string Author { get; set; }
    public int PublishYear { get; set; }
    public string Discriminator { get; set; }
    public Status Status { get; set; }
    public int LoanableAmount { get; set; }
    public int LoanedAmount { get; set; }

    public List<MemberBook> MemberBooks { get; set; }

    public override string ToString()
    {
        return Title;
    }

}
