﻿using OOP.Infrastructure.DataService;
using OOP.Infrastructure.Interfaces;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.AccountService
{
    public class AccountService : IAccountService
    {
        private readonly IAccountDataService _accountDataService;

        public AccountService()
        {
            _accountDataService = new AccountDataService();
        }
        public void Create(Account account)
        {
            var accounts = _accountDataService.GetData();
            accounts.Add(account);
            _accountDataService.Save(accounts);
        }

        public void Delete(Account account)
        {
            var accounts = _accountDataService.GetData();
            accounts.Remove(account);
            _accountDataService.Save(accounts);
        }

        public Account Get(Guid id)
        {
            var accounts = _accountDataService.GetData();
            return accounts.FirstOrDefault(x => x.Id == id);
        }

        public List<Account> GetAll()
        {
            return _accountDataService.GetData();
        }

        public void Update(Account account)
        {
            var accounts = _accountDataService.GetData();
            var updating = accounts.FirstOrDefault(x => x.Id == account.Id);
            var indexAccount = accounts.IndexOf(updating);
            accounts[indexAccount] = account;
        }
    }
}
