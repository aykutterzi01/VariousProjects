﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibraryAutomationSystem.Entities;

public class Member : BaseModel, IMember
{
    public string Name { get; set; }
    public string Surname { get; set; }
    public string Email { get; set; }
    public string MemberNumber { get; set; }

    public List<MemberBook> MemberBooks { get; set; }

    public override string ToString()
    {
        return $"{Name} {Surname} | {Email} | {MemberNumber}";
    }
}
