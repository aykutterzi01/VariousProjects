﻿using OOP.Infrastructure.DataService;
using OOP.Infrastructure.Interfaces;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.EkstraService
{
    public class EkstraService : IEkstraService
    {
        private readonly IEkstraDataService _ekstraDataService;

        public EkstraService()
        {
            _ekstraDataService = new EkstraDataService();
        }

        public void Create(Ekstra ekstra)
        {
            var ekstras = _ekstraDataService.GetData();
            ekstras.Add(ekstra);
            _ekstraDataService.Save(ekstras);
        }

        public void Delete(Ekstra ekstra)
        {
            var ekstras = _ekstraDataService.GetData();
            ekstras.Remove(ekstra);
            _ekstraDataService.Save(ekstras);
        }

        public Ekstra Get(Guid id)
        {
            var ekstras = _ekstraDataService.GetData();
            return ekstras.FirstOrDefault(x => x.Id == id);
        }

        public List<Ekstra> GetAll()
        {
            return _ekstraDataService.GetData();
        }

        public void Update(Ekstra ekstra)
        {
            var ekstras = _ekstraDataService.GetData();
            var updating = ekstras.FirstOrDefault(x => x.Id == ekstra.Id);
            var indexEkstra = ekstras.IndexOf(updating);
            ekstras[indexEkstra] = ekstra;
        }
    }
}
