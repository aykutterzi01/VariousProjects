﻿namespace OOP.Presentation
{
    partial class MakeTransfer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            dgw_Customer_List = new DataGridView();
            label2 = new Label();
            dgw_Account_List = new DataGridView();
            groupBox1 = new GroupBox();
            rdbtn_Exchange = new RadioButton();
            rdbtn_Remission = new RadioButton();
            btn_Transfer = new Button();
            nmrcud_Amount = new NumericUpDown();
            label3 = new Label();
            rdbtn_Withdrawal = new RadioButton();
            rdbtn_Deposit = new RadioButton();
            label4 = new Label();
            dgw_Transfer_List = new DataGridView();
            label5 = new Label();
            dgw_Receiving_Customer = new DataGridView();
            label6 = new Label();
            dgw_Receiving_Account = new DataGridView();
            label7 = new Label();
            dgw_Receiving_Transfer = new DataGridView();
            label8 = new Label();
            lbl_USD = new Label();
            label9 = new Label();
            lbl_EURO = new Label();
            label10 = new Label();
            label11 = new Label();
            groupBox2 = new GroupBox();
            groupBox3 = new GroupBox();
            lbl_Total_Asset = new Label();
            label12 = new Label();
            groupBox4 = new GroupBox();
            rdbtn_Branch = new RadioButton();
            rdbtn_Internet = new RadioButton();
            rdbtn_ATM = new RadioButton();
            ((System.ComponentModel.ISupportInitialize)dgw_Customer_List).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Account_List).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nmrcud_Amount).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Transfer_List).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Receiving_Customer).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Receiving_Account).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Receiving_Transfer).BeginInit();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(12, 13);
            label1.Name = "label1";
            label1.Size = new Size(122, 20);
            label1.TabIndex = 0;
            label1.Text = "CUSTOMER LIST";
            // 
            // dgw_Customer_List
            // 
            dgw_Customer_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Customer_List.Location = new Point(16, 36);
            dgw_Customer_List.Name = "dgw_Customer_List";
            dgw_Customer_List.RowHeadersWidth = 51;
            dgw_Customer_List.Size = new Size(772, 157);
            dgw_Customer_List.TabIndex = 1;
            dgw_Customer_List.RowHeaderMouseClick += dgw_Customer_List_RowHeaderMouseClick;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.Location = new Point(12, 196);
            label2.Name = "label2";
            label2.Size = new Size(115, 20);
            label2.TabIndex = 2;
            label2.Text = "ACCOUNT LIST";
            // 
            // dgw_Account_List
            // 
            dgw_Account_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Account_List.Location = new Point(15, 219);
            dgw_Account_List.MultiSelect = false;
            dgw_Account_List.Name = "dgw_Account_List";
            dgw_Account_List.RowHeadersWidth = 51;
            dgw_Account_List.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgw_Account_List.Size = new Size(772, 135);
            dgw_Account_List.TabIndex = 3;
            dgw_Account_List.RowHeaderMouseClick += dgw_Account_List_RowHeaderMouseClick;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(groupBox4);
            groupBox1.Controls.Add(rdbtn_Exchange);
            groupBox1.Controls.Add(rdbtn_Remission);
            groupBox1.Controls.Add(btn_Transfer);
            groupBox1.Controls.Add(nmrcud_Amount);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(rdbtn_Withdrawal);
            groupBox1.Controls.Add(rdbtn_Deposit);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(16, 360);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(979, 91);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "MAKE A TRANSFER";
            // 
            // rdbtn_Exchange
            // 
            rdbtn_Exchange.AutoSize = true;
            rdbtn_Exchange.Location = new Point(117, 52);
            rdbtn_Exchange.Name = "rdbtn_Exchange";
            rdbtn_Exchange.Size = new Size(96, 24);
            rdbtn_Exchange.TabIndex = 10;
            rdbtn_Exchange.TabStop = true;
            rdbtn_Exchange.Text = "Exchange";
            rdbtn_Exchange.UseVisualStyleBackColor = true;
            rdbtn_Exchange.CheckedChanged += rdbtn_Exchange_CheckedChanged;
            // 
            // rdbtn_Remission
            // 
            rdbtn_Remission.AutoSize = true;
            rdbtn_Remission.Location = new Point(6, 54);
            rdbtn_Remission.Name = "rdbtn_Remission";
            rdbtn_Remission.Size = new Size(102, 24);
            rdbtn_Remission.TabIndex = 9;
            rdbtn_Remission.TabStop = true;
            rdbtn_Remission.Text = "Remission";
            rdbtn_Remission.UseVisualStyleBackColor = true;
            rdbtn_Remission.CheckedChanged += rdbtn_Remission_CheckedChanged;
            // 
            // btn_Transfer
            // 
            btn_Transfer.Location = new Point(731, 22);
            btn_Transfer.Name = "btn_Transfer";
            btn_Transfer.Size = new Size(230, 56);
            btn_Transfer.TabIndex = 8;
            btn_Transfer.Text = "TRANSFER";
            btn_Transfer.UseVisualStyleBackColor = true;
            btn_Transfer.Click += btn_Transfer_Click;
            // 
            // nmrcud_Amount
            // 
            nmrcud_Amount.Location = new Point(255, 42);
            nmrcud_Amount.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            nmrcud_Amount.Name = "nmrcud_Amount";
            nmrcud_Amount.Size = new Size(140, 27);
            nmrcud_Amount.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(255, 21);
            label3.Name = "label3";
            label3.Size = new Size(71, 20);
            label3.TabIndex = 6;
            label3.Text = "Amount:";
            // 
            // rdbtn_Withdrawal
            // 
            rdbtn_Withdrawal.AutoSize = true;
            rdbtn_Withdrawal.Location = new Point(117, 26);
            rdbtn_Withdrawal.Name = "rdbtn_Withdrawal";
            rdbtn_Withdrawal.Size = new Size(111, 24);
            rdbtn_Withdrawal.TabIndex = 5;
            rdbtn_Withdrawal.TabStop = true;
            rdbtn_Withdrawal.Text = "Withdrawal";
            rdbtn_Withdrawal.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Deposit
            // 
            rdbtn_Deposit.AutoSize = true;
            rdbtn_Deposit.Location = new Point(6, 26);
            rdbtn_Deposit.Name = "rdbtn_Deposit";
            rdbtn_Deposit.Size = new Size(84, 24);
            rdbtn_Deposit.TabIndex = 0;
            rdbtn_Deposit.TabStop = true;
            rdbtn_Deposit.Text = "Deposit";
            rdbtn_Deposit.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label4.Location = new Point(15, 454);
            label4.Name = "label4";
            label4.Size = new Size(119, 20);
            label4.TabIndex = 5;
            label4.Text = "TRANSFER LIST";
            // 
            // dgw_Transfer_List
            // 
            dgw_Transfer_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Transfer_List.Location = new Point(16, 477);
            dgw_Transfer_List.Name = "dgw_Transfer_List";
            dgw_Transfer_List.RowHeadersWidth = 51;
            dgw_Transfer_List.Size = new Size(772, 116);
            dgw_Transfer_List.TabIndex = 6;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label5.Location = new Point(794, 9);
            label5.Name = "label5";
            label5.Size = new Size(227, 20);
            label5.TabIndex = 7;
            label5.Text = "CHOOSE RECEVING CUSTOMER";
            // 
            // dgw_Receiving_Customer
            // 
            dgw_Receiving_Customer.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Receiving_Customer.Location = new Point(794, 36);
            dgw_Receiving_Customer.Name = "dgw_Receiving_Customer";
            dgw_Receiving_Customer.RowHeadersWidth = 51;
            dgw_Receiving_Customer.Size = new Size(772, 157);
            dgw_Receiving_Customer.TabIndex = 8;
            dgw_Receiving_Customer.RowHeaderMouseClick += dgw_Receving_Customer_RowHeaderMouseClick;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label6.Location = new Point(794, 196);
            label6.Name = "label6";
            label6.Size = new Size(225, 20);
            label6.TabIndex = 9;
            label6.Text = "CHOOSE RECEIVING ACCOUNT";
            // 
            // dgw_Receiving_Account
            // 
            dgw_Receiving_Account.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Receiving_Account.Location = new Point(794, 219);
            dgw_Receiving_Account.MultiSelect = false;
            dgw_Receiving_Account.Name = "dgw_Receiving_Account";
            dgw_Receiving_Account.RowHeadersWidth = 51;
            dgw_Receiving_Account.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgw_Receiving_Account.Size = new Size(772, 135);
            dgw_Receiving_Account.TabIndex = 10;
            dgw_Receiving_Account.RowHeaderMouseClick += dgw_Receiving_Account_RowHeaderMouseClick;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label7.Location = new Point(794, 454);
            label7.Name = "label7";
            label7.Size = new Size(201, 20);
            label7.TabIndex = 11;
            label7.Text = "RECEIVING TRANSFER LIST";
            // 
            // dgw_Receiving_Transfer
            // 
            dgw_Receiving_Transfer.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Receiving_Transfer.Location = new Point(794, 477);
            dgw_Receiving_Transfer.Name = "dgw_Receiving_Transfer";
            dgw_Receiving_Transfer.RowHeadersWidth = 51;
            dgw_Receiving_Transfer.Size = new Size(772, 116);
            dgw_Receiving_Transfer.TabIndex = 12;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label8.Location = new Point(12, 33);
            label8.Name = "label8";
            label8.Size = new Size(43, 20);
            label8.TabIndex = 13;
            label8.Text = "USD:";
            // 
            // lbl_USD
            // 
            lbl_USD.AutoSize = true;
            lbl_USD.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lbl_USD.Location = new Point(61, 33);
            lbl_USD.Name = "lbl_USD";
            lbl_USD.Size = new Size(44, 20);
            lbl_USD.TabIndex = 14;
            lbl_USD.Text = "31,13";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label9.Location = new Point(183, 33);
            label9.Name = "label9";
            label9.Size = new Size(53, 20);
            label9.TabIndex = 15;
            label9.Text = "EURO:";
            // 
            // lbl_EURO
            // 
            lbl_EURO.AutoSize = true;
            lbl_EURO.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lbl_EURO.Location = new Point(242, 33);
            lbl_EURO.Name = "lbl_EURO";
            lbl_EURO.Size = new Size(44, 20);
            lbl_EURO.TabIndex = 16;
            lbl_EURO.Text = "33,78";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label10.Location = new Point(111, 33);
            label10.Name = "label10";
            label10.Size = new Size(24, 20);
            label10.TabIndex = 17;
            label10.Text = "TL";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label11.Location = new Point(292, 33);
            label11.Name = "label11";
            label11.Size = new Size(24, 20);
            label11.TabIndex = 18;
            label11.Text = "TL";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lbl_USD);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(lbl_EURO);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(label10);
            groupBox2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox2.Location = new Point(1221, 381);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(345, 64);
            groupBox2.TabIndex = 19;
            groupBox2.TabStop = false;
            groupBox2.Text = "EXCHANGE RATES";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(lbl_Total_Asset);
            groupBox3.Controls.Add(label12);
            groupBox3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox3.Location = new Point(1005, 381);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(210, 65);
            groupBox3.TabIndex = 20;
            groupBox3.TabStop = false;
            groupBox3.Text = "TOTAL CUSTOMER ASSET";
            // 
            // lbl_Total_Asset
            // 
            lbl_Total_Asset.AutoSize = true;
            lbl_Total_Asset.Location = new Point(69, 28);
            lbl_Total_Asset.Name = "lbl_Total_Asset";
            lbl_Total_Asset.Size = new Size(18, 20);
            lbl_Total_Asset.TabIndex = 21;
            lbl_Total_Asset.Text = "0";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(12, 28);
            label12.Name = "label12";
            label12.Size = new Size(51, 20);
            label12.TabIndex = 0;
            label12.Text = "Value:";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(rdbtn_ATM);
            groupBox4.Controls.Add(rdbtn_Internet);
            groupBox4.Controls.Add(rdbtn_Branch);
            groupBox4.Location = new Point(411, 17);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(298, 68);
            groupBox4.TabIndex = 11;
            groupBox4.TabStop = false;
            groupBox4.Text = "TRANSFER CHANNEL";
            // 
            // rdbtn_Branch
            // 
            rdbtn_Branch.AutoSize = true;
            rdbtn_Branch.Location = new Point(12, 27);
            rdbtn_Branch.Name = "rdbtn_Branch";
            rdbtn_Branch.Size = new Size(79, 24);
            rdbtn_Branch.TabIndex = 0;
            rdbtn_Branch.TabStop = true;
            rdbtn_Branch.Text = "Branch";
            rdbtn_Branch.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Internet
            // 
            rdbtn_Internet.AutoSize = true;
            rdbtn_Internet.Location = new Point(117, 27);
            rdbtn_Internet.Name = "rdbtn_Internet";
            rdbtn_Internet.Size = new Size(87, 24);
            rdbtn_Internet.TabIndex = 1;
            rdbtn_Internet.TabStop = true;
            rdbtn_Internet.Text = "Internet";
            rdbtn_Internet.UseVisualStyleBackColor = true;
            // 
            // rdbtn_ATM
            // 
            rdbtn_ATM.AutoSize = true;
            rdbtn_ATM.Location = new Point(219, 25);
            rdbtn_ATM.Name = "rdbtn_ATM";
            rdbtn_ATM.Size = new Size(63, 24);
            rdbtn_ATM.TabIndex = 2;
            rdbtn_ATM.TabStop = true;
            rdbtn_ATM.Text = "ATM";
            rdbtn_ATM.UseVisualStyleBackColor = true;
            // 
            // MakeTransfer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1594, 605);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(dgw_Receiving_Transfer);
            Controls.Add(label7);
            Controls.Add(dgw_Receiving_Account);
            Controls.Add(label6);
            Controls.Add(dgw_Receiving_Customer);
            Controls.Add(label5);
            Controls.Add(dgw_Transfer_List);
            Controls.Add(label4);
            Controls.Add(groupBox1);
            Controls.Add(dgw_Account_List);
            Controls.Add(label2);
            Controls.Add(dgw_Customer_List);
            Controls.Add(label1);
            Name = "MakeTransfer";
            Text = "MakeTransfer";
            WindowState = FormWindowState.Maximized;
            Load += MakeTransfer_Load;
            ((System.ComponentModel.ISupportInitialize)dgw_Customer_List).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Account_List).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nmrcud_Amount).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Transfer_List).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Receiving_Customer).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Receiving_Account).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Receiving_Transfer).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private DataGridView dgw_Customer_List;
        private Label label2;
        private DataGridView dgw_Account_List;
        private GroupBox groupBox1;
        private Button btn_Transfer;
        private NumericUpDown nmrcud_Amount;
        private Label label3;
        private RadioButton rdbtn_Withdrawal;
        private RadioButton rdbtn_Deposit;
        private Label label4;
        private DataGridView dgw_Transfer_List;
        private RadioButton rdbtn_Remission;
        private Label label5;
        private DataGridView dgw_Receiving_Customer;
        private Label label6;
        private DataGridView dgw_Receiving_Account;
        private Label label7;
        private DataGridView dgw_Receiving_Transfer;
        private Label label8;
        private Label lbl_USD;
        private Label label9;
        private Label lbl_EURO;
        private Label label10;
        private Label label11;
        private GroupBox groupBox2;
        private RadioButton rdbtn_Exchange;
        private GroupBox groupBox3;
        private Label label12;
        private Label lbl_Total_Asset;
        private GroupBox groupBox4;
        private RadioButton rdbtn_ATM;
        private RadioButton rdbtn_Internet;
        private RadioButton rdbtn_Branch;
    }
}