﻿namespace Presentation
{
    partial class RegisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            btnRegister = new Button();
            txtRegisterPassword = new TextBox();
            txtRegisterUserName = new TextBox();
            txtRegisterSurname = new TextBox();
            txtRegisterName = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnRegister);
            groupBox1.Controls.Add(txtRegisterPassword);
            groupBox1.Controls.Add(txtRegisterUserName);
            groupBox1.Controls.Add(txtRegisterSurname);
            groupBox1.Controls.Add(txtRegisterName);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.ForeColor = Color.White;
            groupBox1.Location = new Point(165, 26);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(455, 365);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "REGISTRATION DETAILS";
            // 
            // btnRegister
            // 
            btnRegister.ForeColor = Color.FromArgb(192, 64, 0);
            btnRegister.Location = new Point(128, 287);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(301, 63);
            btnRegister.TabIndex = 8;
            btnRegister.Text = "REGISTER";
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += btnRegister_Click;
            // 
            // txtRegisterPassword
            // 
            txtRegisterPassword.Location = new Point(127, 227);
            txtRegisterPassword.Name = "txtRegisterPassword";
            txtRegisterPassword.PasswordChar = '*';
            txtRegisterPassword.Size = new Size(302, 34);
            txtRegisterPassword.TabIndex = 7;
            // 
            // txtRegisterUserName
            // 
            txtRegisterUserName.Location = new Point(127, 166);
            txtRegisterUserName.Name = "txtRegisterUserName";
            txtRegisterUserName.Size = new Size(302, 34);
            txtRegisterUserName.TabIndex = 6;
            // 
            // txtRegisterSurname
            // 
            txtRegisterSurname.Location = new Point(127, 109);
            txtRegisterSurname.Name = "txtRegisterSurname";
            txtRegisterSurname.Size = new Size(302, 34);
            txtRegisterSurname.TabIndex = 5;
            // 
            // txtRegisterName
            // 
            txtRegisterName.Location = new Point(127, 52);
            txtRegisterName.Name = "txtRegisterName";
            txtRegisterName.Size = new Size(302, 34);
            txtRegisterName.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(15, 230);
            label4.Name = "label4";
            label4.Size = new Size(106, 28);
            label4.TabIndex = 3;
            label4.Text = "Password:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(10, 169);
            label3.Name = "label3";
            label3.Size = new Size(111, 28);
            label3.TabIndex = 2;
            label3.Text = "Username:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(21, 112);
            label2.Name = "label2";
            label2.Size = new Size(100, 28);
            label2.TabIndex = 1;
            label2.Text = "Surname:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(48, 52);
            label1.Name = "label1";
            label1.Size = new Size(73, 28);
            label1.TabIndex = 0;
            label1.Text = "Name:";
            // 
            // RegisterForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 64, 0);
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Name = "RegisterForm";
            Text = "RegisterForm";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button btnRegister;
        private TextBox txtRegisterPassword;
        private TextBox txtRegisterUserName;
        private TextBox txtRegisterSurname;
        private TextBox txtRegisterName;
        private Label label4;
    }
}