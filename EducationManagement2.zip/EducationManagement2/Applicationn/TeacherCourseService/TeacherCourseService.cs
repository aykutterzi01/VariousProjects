﻿using Infrastructure.DataService;
using Infrastructure.Interfaces;
using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applicationn.TeacherCourseService
{
    public class TeacherCourseService : ITeacherCourseService
    {
        private readonly ITeacherCourseDataService _teacherCourseDataService;
        public TeacherCourseService()
        {
            _teacherCourseDataService = new TeacherCourseDataService();
        }

        public void Create(TeacherCourse teacherCourse)
        {
            var teacherCourses = _teacherCourseDataService.GetData();
            teacherCourses.Add(teacherCourse);
            _teacherCourseDataService.Save(teacherCourses);

        }

        public void Delete(TeacherCourse teacherCourse)
        {
            var teacherCourses = _teacherCourseDataService.GetData();
            teacherCourses.Remove(teacherCourses.FirstOrDefault(x => x.Id == teacherCourse.Id));
            _teacherCourseDataService.Save(teacherCourses);
        }

        public TeacherCourse Get(Guid id)
        {
            var teacherCourses = _teacherCourseDataService.GetData();
            return teacherCourses.FirstOrDefault(x => x.Id == id);
        }

        public List<TeacherCourse> GetAll()
        {
            return _teacherCourseDataService.GetData();
        }

        public void Update(TeacherCourse teacherCourse)
        {
            var teacherCourses = _teacherCourseDataService.GetData();
            var updatedTeacherCourse = teacherCourses.FirstOrDefault(x => x.Id == teacherCourse.Id);
            var indexTeacherCourse = teacherCourses.IndexOf(updatedTeacherCourse);
            teacherCourses[indexTeacherCourse] = teacherCourse;
            _teacherCourseDataService.Save(teacherCourses);
        }
    }
}
