﻿using Business.Services;
using LibraryAutomationSystem.Context;
using Presentation.Methods;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class LoginForm : Form
    {
        AppUserService _appUserService;
        public LoginForm(AppUserService appUserService)
        {
            InitializeComponent();
            _appUserService = appUserService;
        }

        public event EventHandler<bool> LoginStatusChanged;

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var username = txtLoginUserName.Text;
            var password = txtLoginPassword.Text;

            bool loginStatus = CheckUser(username, password);

            if(loginStatus)
            {
                MessageBox.Show("Login successful.");

                LoginStatusChanged?.Invoke(this, true);

                SharedData.AppUser = _appUserService.GetAll().FirstOrDefault(x => x.UserName == username);
            }
            else
            {
                MessageBox.Show("Login failed.\nWrong username or password.");
            }
        }

        private bool CheckUser(string username, string password)
        {
            return _appUserService.GetAll().Any(x => x.UserName == username && x.Password == Hash.HashPass(password));
        }
    }
}
