﻿using LibraryAutomationSystem.Context;
using LibraryAutomationSystem.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services;

public class AppUserService
{
    private readonly AppDbContext dbContext;
    public AppUserService()
    {
        this.dbContext = new AppDbContext();
    }

    public void Create(AppUser appUser)
    {
        dbContext.AppUsers.Add(appUser);
        dbContext.SaveChanges();
    }

    public void Delete(AppUser appUser)
    {
        dbContext.AppUsers.Remove(appUser);
        dbContext.SaveChanges();
    }

    public void Update(AppUser appUser)
    {
        dbContext.AppUsers.Update(appUser);
        dbContext.SaveChanges();
    }

    public List<AppUser> GetAll()
    {
        return dbContext.AppUsers.ToList();
    }
}
