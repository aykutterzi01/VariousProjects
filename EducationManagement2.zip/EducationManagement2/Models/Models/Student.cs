﻿using Models.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.Models;

public class Student : BaseModel
{
    public string Name { get; set; }
    public string Surname { get; set; }
    public DateTime BirthDate { get; set; }
    public Gender Gender { get; set; }

    public string FullName => $"{Name} {Surname} | {BirthDate.ToString("d")} | {Gender}";
}
