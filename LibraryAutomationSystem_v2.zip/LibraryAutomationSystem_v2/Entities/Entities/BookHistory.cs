﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryAutomationSystem.Entities.Enum;

namespace LibraryAutomationSystem.Entities;

public class BookHistory : Book
{
    public string Period { get; set; }

}
