﻿using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Infrastructure.Interfaces
{
    public interface IBaseDataService<T> where T : BaseModel
    {
        void Save(List<T> data);
        List<T> GetData();
    }
}
