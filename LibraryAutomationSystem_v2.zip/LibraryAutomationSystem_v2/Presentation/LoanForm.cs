﻿using Business.Services;
using LibraryAutomationSystem.Context;
using LibraryAutomationSystem.Entities;
using LibraryAutomationSystem.Methods;
using Microsoft.EntityFrameworkCore;
using Presentation.Methods;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class LoanForm : Form
    {
        BookService _bookService;
        MemberBookService _memberBookService;
        MemberService _memberService;

        public LoanForm(BookService bookService, MemberBookService memberBookService, MemberService memberService)
        {
            InitializeComponent();
            _bookService = bookService;
            _memberBookService = memberBookService;
            _memberService = memberService;
        }

        private void LoanForm_Load(object sender, EventArgs e)
        {
            ResetTables();
            rdbtnAllBooks.Checked = true;
            rdbtnAllLoans.Checked = true;
        }

        private void ResetTables()
        {
            dgwBooks.DataSource = null;
            dgwLoans.DataSource = null;

            var selectedMember = cmbMembers.SelectedItem as Member;

            if (selectedMember == null)
            {
                cmbMembers.DataSource = _memberService.GetAll();
                return;
            }

            var books = _bookService.GetAll().Select(x => new
            {
                x.Id,
                x.ISBN,
                x.Title,
                x.Author,
                x.PublishYear,
                x.Discriminator,
                Period = (x.Discriminator == "BookHistory") ? ((BookHistory)x).Period : null,
                Thema = (x.Discriminator == "BookNovel") ? ((BookNovel)x).Thema : null,
                Domain = (x.Discriminator == "BookScience") ? ((BookScience)x).Domain : null,
                x.Status,
                x.LoanableAmount,
                x.LoanedAmount
            }).ToList();

            if (rdbtnAllBooks.Checked == true)
            {
                dgwBooks.DataSource = books;
                dgwBooks.Columns["Id"].Visible = false;
            }
            if (rdbtnHistory.Checked == true)
            {
                dgwBooks.DataSource = books.Where(x => x.Discriminator == "BookHistory").ToList();
                dgwBooks.Columns["Id"].Visible = false;
            }
            if (rdbtnNovel.Checked == true)
            {
                dgwBooks.DataSource = books.Where(x => x.Discriminator == "BookNovel").ToList();
                dgwBooks.Columns["Id"].Visible = false;
            }
            if (rdbtnScience.Checked == true)
            {
                dgwBooks.DataSource = books.Where(x => x.Discriminator == "BookScience").ToList();
                dgwBooks.Columns["Id"].Visible = false;
            }

            var memberBooks = _memberBookService.GetAll().Include(mb => mb.Member).Include(mb => mb.Book).Include(mb => mb.AppUser).Where(mb => mb.MemberId == selectedMember.Id).ToList();

            if (rdbtnAllLoans.Checked == true)
            {
                dgwLoans.DataSource = memberBooks;

                dgwLoans.Columns["MemberId"].Visible = false;
                dgwLoans.Columns["BookId"].Visible = false;
                dgwLoans.Columns["AppUserId"].Visible = false;
                dgwLoans.Columns["Id"].Visible = false;
            }
            if (rdbtnNotReturned.Checked == true)
            {
                dgwLoans.DataSource = memberBooks.Where(x => x.ReturnDate == null).ToList();

                dgwLoans.Columns["MemberId"].Visible = false;
                dgwLoans.Columns["BookId"].Visible = false;
                dgwLoans.Columns["AppUserId"].Visible = false;
                dgwLoans.Columns["Id"].Visible = false;
            }

        }

        private void btnLoan_Click(object sender, EventArgs e)
        {
            var bookId = (Guid)(dgwBooks.SelectedRows[0].Cells[0]).Value;
            var book = _bookService.GetAll().FirstOrDefault(x => x.Id == bookId);

            var member = cmbMembers.SelectedItem as Member;

            if (book.LoanableAmount > 0)
            {
                book.LoanableAmount -= 1;
                book.LoanedAmount += 1;

                Status.SetStatus(book);

                MemberBook memberBook = new MemberBook()
                {
                    MemberId = member.Id,
                    BookId = book.Id,
                    AppUserId = SharedData.AppUser.Id,
                    BorrowDate = DateTime.Today,
                };

                _memberBookService.Create(memberBook);

                MessageBox.Show("The book has been loaned.");

                ResetTables();
            }
            else
            {
                MessageBox.Show("There are no loanable books.");
                return;
            }

        }

        private void cmbMembers_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetTables();
        }

        private void rdbtnAllBooks_CheckedChanged(object sender, EventArgs e)
        {
            ResetTables();
        }

        private void rdbtnHistory_CheckedChanged(object sender, EventArgs e)
        {
            ResetTables();
        }

        private void rdbtnNovel_CheckedChanged(object sender, EventArgs e)
        {
            ResetTables();
        }

        private void rdbtnScience_CheckedChanged(object sender, EventArgs e)
        {
            ResetTables();
        }

        private void rdbtnAllLoans_CheckedChanged(object sender, EventArgs e)
        {
            ResetTables();
        }

        private void rdbtnNotReturned_CheckedChanged(object sender, EventArgs e)
        {
            ResetTables();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            var memberBookId = (Guid)((dgwLoans.SelectedRows[0].Cells["Id"]).Value);
            var memberBook = _memberBookService.GetAll().FirstOrDefault(x => x.Id == memberBookId);

            if (memberBook.ReturnDate == null)
            {
                var book = _bookService.GetAll().FirstOrDefault(x => x.Id == memberBook.BookId);

                book.LoanableAmount += 1;
                book.LoanedAmount -= 1;

                Status.SetStatus(book);

                _bookService.Update(book);

                memberBook.ReturnDate = DateTime.Now;

                _memberBookService.Update(memberBook);

                MessageBox.Show("The book has been returned.");
            }
            else
            {
                MessageBox.Show("The book was already returned.");
                return;
            }

            ResetTables();
        }
    }
}
