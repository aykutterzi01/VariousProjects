﻿using Infrastructure.DataService;
using Infrastructure.Interfaces;
using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applicationn.StudentService
{
    public class StudentService : IStudentService
    {
        private readonly IStudentDataService _studentDataService;

        public StudentService()
        {
            _studentDataService = new StudentDataService();
        }

        public void Create(Student student)
        {
            var students = _studentDataService.GetData();
            students.Add(student);
            _studentDataService.Save(students);
        }

        public void Delete(Student student)
        {
            var students = _studentDataService.GetData();
            students.Remove(students.FirstOrDefault(x => x.Id == student.Id));
            _studentDataService.Save(students);
        }

        public Student Get(Guid id)
        {
            var students = _studentDataService.GetData();
            return students.FirstOrDefault(x => x.Id == id);
        }

        public List<Student> GetAll()
        {
            return _studentDataService.GetData();
        }

        public void Update(Student student)
        {
            var students = _studentDataService.GetData();
            var updatedStudent = students.FirstOrDefault(x => x.Id == student.Id);
            var indexStudent = students.IndexOf(updatedStudent);
            students[indexStudent] = student;
            _studentDataService.Save(students);
        }
    }
}
