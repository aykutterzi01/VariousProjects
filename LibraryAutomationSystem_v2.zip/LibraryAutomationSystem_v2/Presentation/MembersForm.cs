﻿using Business.Services;
using LibraryAutomationSystem.Context;
using LibraryAutomationSystem.Entities;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class MembersForm : Form
    {
        MemberService _memberService;
        public MembersForm(MemberService memberService)
        {
            InitializeComponent();
            _memberService = memberService;
        }

        private void btnAddMember_Click(object sender, EventArgs e)
        {
            Member member = new Member()
            {
                Name = txtMemberName.Text,
                Surname = txtMemberSurname.Text,
                Email = txtMemberEmail.Text,
                MemberNumber = txtMemberNumber.Text
            };

            _memberService.Create(member);

            MessageBox.Show("The member has been added.");

            ResetTable();

            CleanTexts();
        }

        private void ResetTable()
        {
            dgwMembers.DataSource = null;
            dgwMembers.DataSource = _memberService.GetAll();
            dgwMembers.Columns["Id"].Visible = false;

        }

        private void CleanTexts()
        {
            txtMemberName.Text = string.Empty;
            txtMemberSurname.Text = string.Empty;
            txtMemberEmail.Text = string.Empty;
            txtMemberNumber.Text = string.Empty;
        }

        private void btnUpdateMember_Click(object sender, EventArgs e)
        {
            var member = ((Member)dgwMembers.SelectedRows[0].DataBoundItem);

            member.Name = txtMemberName.Text;
            member.Surname = txtMemberSurname.Text;
            member.Email = txtMemberEmail.Text;
            member.MemberNumber = txtMemberNumber.Text;

            _memberService.Update(member);

            MessageBox.Show("The member has been updated.");

            ResetTable();
            CleanTexts();
        }

        private void ManageMembersForm_Load(object sender, EventArgs e)
        {
            ResetTable();
        }

        private void dgwMembers_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var member = ((Member)dgwMembers.SelectedRows[0].DataBoundItem);

            txtMemberName.Text = member.Name;
            txtMemberSurname.Text = member.Surname;
            txtMemberEmail.Text = member.Email;
            txtMemberNumber.Text = member.MemberNumber;
        }

        private void btnDeleteMember_Click(object sender, EventArgs e)
        {
            var member = ((Member)dgwMembers.SelectedRows[0].DataBoundItem);

            _memberService.Delete(member);

            MessageBox.Show("Member has been deleted.");

            ResetTable();
            CleanTexts();
        }
    }
}
