﻿using OOP.Infrastructure.Interfaces;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Infrastructure.DataService
{
    public class AccountDataService : BaseDataService<Account>, IAccountDataService
    {
    }
}
