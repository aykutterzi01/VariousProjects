﻿namespace OOP.Presentation
{
    partial class TransferDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgw_Transfer_List = new DataGridView();
            label4 = new Label();
            dgw_Account_List = new DataGridView();
            label2 = new Label();
            dgw_Customer_List = new DataGridView();
            label1 = new Label();
            groupBox1 = new GroupBox();
            rdbtn_ATM = new RadioButton();
            rdbtn_Internet = new RadioButton();
            rdbtn_Branch = new RadioButton();
            rdbtn_All_Channels = new RadioButton();
            groupBox2 = new GroupBox();
            dtp_End = new DateTimePicker();
            dtp_Start = new DateTimePicker();
            label5 = new Label();
            label3 = new Label();
            btn_Filter = new Button();
            groupBox3 = new GroupBox();
            rdbtn_All_Types = new RadioButton();
            rdbtn_Receival = new RadioButton();
            rdbtn_Remission = new RadioButton();
            rdbtn_Withdrawal = new RadioButton();
            rdbtn_Deposit = new RadioButton();
            ((System.ComponentModel.ISupportInitialize)dgw_Transfer_List).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Account_List).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Customer_List).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // dgw_Transfer_List
            // 
            dgw_Transfer_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Transfer_List.Location = new Point(812, 39);
            dgw_Transfer_List.Name = "dgw_Transfer_List";
            dgw_Transfer_List.RowHeadersWidth = 51;
            dgw_Transfer_List.Size = new Size(731, 523);
            dgw_Transfer_List.TabIndex = 12;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label4.Location = new Point(812, 16);
            label4.Name = "label4";
            label4.Size = new Size(119, 20);
            label4.TabIndex = 11;
            label4.Text = "TRANSFER LIST";
            // 
            // dgw_Account_List
            // 
            dgw_Account_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Account_List.Location = new Point(15, 222);
            dgw_Account_List.MultiSelect = false;
            dgw_Account_List.Name = "dgw_Account_List";
            dgw_Account_List.RowHeadersWidth = 51;
            dgw_Account_List.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgw_Account_List.Size = new Size(772, 135);
            dgw_Account_List.TabIndex = 10;
            dgw_Account_List.RowHeaderMouseClick += dgw_Account_List_RowHeaderMouseClick;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.Location = new Point(12, 199);
            label2.Name = "label2";
            label2.Size = new Size(115, 20);
            label2.TabIndex = 9;
            label2.Text = "ACCOUNT LIST";
            // 
            // dgw_Customer_List
            // 
            dgw_Customer_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Customer_List.Location = new Point(16, 39);
            dgw_Customer_List.Name = "dgw_Customer_List";
            dgw_Customer_List.RowHeadersWidth = 51;
            dgw_Customer_List.Size = new Size(772, 157);
            dgw_Customer_List.TabIndex = 8;
            dgw_Customer_List.RowHeaderMouseClick += dgw_Customer_List_RowHeaderMouseClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(12, 16);
            label1.Name = "label1";
            label1.Size = new Size(122, 20);
            label1.TabIndex = 7;
            label1.Text = "CUSTOMER LIST";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rdbtn_ATM);
            groupBox1.Controls.Add(rdbtn_Internet);
            groupBox1.Controls.Add(rdbtn_Branch);
            groupBox1.Controls.Add(rdbtn_All_Channels);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(17, 377);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(175, 185);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "TRANSFER CHANNEL";
            // 
            // rdbtn_ATM
            // 
            rdbtn_ATM.AutoSize = true;
            rdbtn_ATM.Location = new Point(10, 121);
            rdbtn_ATM.Name = "rdbtn_ATM";
            rdbtn_ATM.Size = new Size(63, 24);
            rdbtn_ATM.TabIndex = 16;
            rdbtn_ATM.TabStop = true;
            rdbtn_ATM.Text = "ATM";
            rdbtn_ATM.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Internet
            // 
            rdbtn_Internet.AutoSize = true;
            rdbtn_Internet.Location = new Point(10, 89);
            rdbtn_Internet.Name = "rdbtn_Internet";
            rdbtn_Internet.Size = new Size(87, 24);
            rdbtn_Internet.TabIndex = 15;
            rdbtn_Internet.TabStop = true;
            rdbtn_Internet.Text = "Internet";
            rdbtn_Internet.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Branch
            // 
            rdbtn_Branch.AutoSize = true;
            rdbtn_Branch.Location = new Point(10, 59);
            rdbtn_Branch.Name = "rdbtn_Branch";
            rdbtn_Branch.Size = new Size(79, 24);
            rdbtn_Branch.TabIndex = 14;
            rdbtn_Branch.TabStop = true;
            rdbtn_Branch.Text = "Branch";
            rdbtn_Branch.UseVisualStyleBackColor = true;
            // 
            // rdbtn_All_Channels
            // 
            rdbtn_All_Channels.AutoSize = true;
            rdbtn_All_Channels.Location = new Point(10, 29);
            rdbtn_All_Channels.Name = "rdbtn_All_Channels";
            rdbtn_All_Channels.Size = new Size(116, 24);
            rdbtn_All_Channels.TabIndex = 0;
            rdbtn_All_Channels.TabStop = true;
            rdbtn_All_Channels.Text = "All Channels";
            rdbtn_All_Channels.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(dtp_End);
            groupBox2.Controls.Add(dtp_Start);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(label3);
            groupBox2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox2.Location = new Point(380, 377);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(272, 185);
            groupBox2.TabIndex = 14;
            groupBox2.TabStop = false;
            groupBox2.Text = "CHOOSE TIME INTERVAL";
            // 
            // dtp_End
            // 
            dtp_End.Location = new Point(105, 116);
            dtp_End.Name = "dtp_End";
            dtp_End.Size = new Size(151, 27);
            dtp_End.TabIndex = 3;
            dtp_End.ValueChanged += dtp_End_ValueChanged;
            // 
            // dtp_Start
            // 
            dtp_Start.Location = new Point(105, 56);
            dtp_Start.Name = "dtp_Start";
            dtp_Start.Size = new Size(151, 27);
            dtp_Start.TabIndex = 2;
            dtp_Start.ValueChanged += dtp_Start_ValueChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 121);
            label5.Name = "label5";
            label5.Size = new Size(76, 20);
            label5.TabIndex = 1;
            label5.Text = "End Date:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 57);
            label3.Name = "label3";
            label3.Size = new Size(84, 20);
            label3.TabIndex = 0;
            label3.Text = "Start Date:";
            // 
            // btn_Filter
            // 
            btn_Filter.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btn_Filter.Location = new Point(670, 377);
            btn_Filter.Name = "btn_Filter";
            btn_Filter.Size = new Size(118, 185);
            btn_Filter.TabIndex = 15;
            btn_Filter.Text = "FILTER";
            btn_Filter.UseVisualStyleBackColor = true;
            btn_Filter.Click += btn_Filter_Click;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(rdbtn_All_Types);
            groupBox3.Controls.Add(rdbtn_Receival);
            groupBox3.Controls.Add(rdbtn_Remission);
            groupBox3.Controls.Add(rdbtn_Withdrawal);
            groupBox3.Controls.Add(rdbtn_Deposit);
            groupBox3.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox3.Location = new Point(213, 377);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(151, 185);
            groupBox3.TabIndex = 16;
            groupBox3.TabStop = false;
            groupBox3.Text = "TRANSFER TYPE";
            // 
            // rdbtn_All_Types
            // 
            rdbtn_All_Types.AutoSize = true;
            rdbtn_All_Types.Location = new Point(6, 29);
            rdbtn_All_Types.Name = "rdbtn_All_Types";
            rdbtn_All_Types.Size = new Size(93, 24);
            rdbtn_All_Types.TabIndex = 17;
            rdbtn_All_Types.TabStop = true;
            rdbtn_All_Types.Text = "All Types";
            rdbtn_All_Types.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Receival
            // 
            rdbtn_Receival.AutoSize = true;
            rdbtn_Receival.Location = new Point(6, 150);
            rdbtn_Receival.Name = "rdbtn_Receival";
            rdbtn_Receival.Size = new Size(87, 24);
            rdbtn_Receival.TabIndex = 17;
            rdbtn_Receival.TabStop = true;
            rdbtn_Receival.Text = "Receival";
            rdbtn_Receival.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Remission
            // 
            rdbtn_Remission.AutoSize = true;
            rdbtn_Remission.Location = new Point(6, 120);
            rdbtn_Remission.Name = "rdbtn_Remission";
            rdbtn_Remission.Size = new Size(102, 24);
            rdbtn_Remission.TabIndex = 2;
            rdbtn_Remission.TabStop = true;
            rdbtn_Remission.Text = "Remission";
            rdbtn_Remission.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Withdrawal
            // 
            rdbtn_Withdrawal.AutoSize = true;
            rdbtn_Withdrawal.Location = new Point(6, 89);
            rdbtn_Withdrawal.Name = "rdbtn_Withdrawal";
            rdbtn_Withdrawal.Size = new Size(111, 24);
            rdbtn_Withdrawal.TabIndex = 1;
            rdbtn_Withdrawal.TabStop = true;
            rdbtn_Withdrawal.Text = "Withdrawal";
            rdbtn_Withdrawal.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Deposit
            // 
            rdbtn_Deposit.AutoSize = true;
            rdbtn_Deposit.Location = new Point(6, 59);
            rdbtn_Deposit.Name = "rdbtn_Deposit";
            rdbtn_Deposit.Size = new Size(84, 24);
            rdbtn_Deposit.TabIndex = 0;
            rdbtn_Deposit.TabStop = true;
            rdbtn_Deposit.Text = "Deposit";
            rdbtn_Deposit.UseVisualStyleBackColor = true;
            // 
            // TransferDetails
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1549, 612);
            Controls.Add(groupBox3);
            Controls.Add(btn_Filter);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(dgw_Transfer_List);
            Controls.Add(label4);
            Controls.Add(dgw_Account_List);
            Controls.Add(label2);
            Controls.Add(dgw_Customer_List);
            Controls.Add(label1);
            Name = "TransferDetails";
            Text = "TransferDetails";
            WindowState = FormWindowState.Maximized;
            Load += TransferDetails_Load;
            ((System.ComponentModel.ISupportInitialize)dgw_Transfer_List).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Account_List).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgw_Customer_List).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgw_Transfer_List;
        private Label label4;
        private DataGridView dgw_Account_List;
        private Label label2;
        private DataGridView dgw_Customer_List;
        private Label label1;
        private GroupBox groupBox1;
        private RadioButton rdbtn_ATM;
        private RadioButton rdbtn_Internet;
        private RadioButton rdbtn_Branch;
        private RadioButton rdbtn_All_Channels;
        private GroupBox groupBox2;
        private DateTimePicker dtp_End;
        private DateTimePicker dtp_Start;
        private Label label5;
        private Label label3;
        private Button btn_Filter;
        private GroupBox groupBox3;
        private RadioButton rdbtn_All_Types;
        private RadioButton rdbtn_Receival;
        private RadioButton rdbtn_Remission;
        private RadioButton rdbtn_Withdrawal;
        private RadioButton rdbtn_Deposit;
    }
}