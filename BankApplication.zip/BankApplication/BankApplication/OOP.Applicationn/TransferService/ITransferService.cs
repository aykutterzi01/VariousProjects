﻿using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.TransferService
{
    public interface ITransferService
    {
        public void Create(Transfer transfer);
        public void Delete(Transfer transfer);
        public Transfer Get(Guid id);
        public List<Transfer> GetAll();
        public void Update(Transfer transfer);
    }
}
