﻿using OOP.Applicationn.AccountService;
using OOP.Applicationn.CustomerService;
using OOP.Applicationn.TransferService;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Presentation
{
    public partial class TransferDetails : Form
    {
        CustomerService _customerService;
        AccountService _accountService;
        TransferService _transferService;

        public TransferDetails(CustomerService customerService, AccountService accountService, TransferService transferService)
        {
            InitializeComponent();
            _customerService = customerService;
            _accountService = accountService;
            _transferService = transferService;
        }

        private void dtp_End_ValueChanged(object sender, EventArgs e)
        {
            DateIntervalCheck();
        }

        private void DateIntervalCheck()
        {
            if (dtp_End.Value.Date < dtp_Start.Value.Date)
            {
                MessageBox.Show("The end date can not be earlier than start date.");
            }
        }

        private void dtp_Start_ValueChanged(object sender, EventArgs e)
        {
            DateIntervalCheck();
        }

        private void TransferDetails_Load(object sender, EventArgs e)
        {
            dgw_Customer_List.DataSource = _customerService.GetAll();
            dgw_Customer_List.Columns["CommissionRatio"].Visible = false;
            dgw_Customer_List.Columns["Id"].Visible = false;

            rdbtn_All_Channels.Checked = true;
            rdbtn_All_Types.Checked = true;
        }

        private void dgw_Customer_List_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Customer selectedCustomer = (Customer)dgw_Customer_List.SelectedRows[0].DataBoundItem;

            dgw_Account_List.DataSource = _accountService.GetAll().Where(x => x.Customer.Id == selectedCustomer.Id).ToList();

            dgw_Account_List.Columns["Id"].Visible = false;

            dgw_Account_List.Columns["Balance"].DefaultCellStyle.Format = "N2";

            dgw_Transfer_List.DataSource = null;
        }

        private void dgw_Account_List_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Account selectedAccount = (Account)dgw_Account_List.SelectedRows[0].DataBoundItem;

            dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id).ToList();

            HideSelectedColumns();
        }

        private void HideSelectedColumns()
        {
            dgw_Transfer_List.Columns["Id"].Visible = false;
            dgw_Transfer_List.Columns["Account"].Visible = false;
            dgw_Transfer_List.DefaultCellStyle.NullValue = "(Not Applicable)";
        }

        private void btn_Filter_Click(object sender, EventArgs e)
        {
            Account selectedAccount = (Account)dgw_Account_List.SelectedRows[0].DataBoundItem;

            if(rdbtn_All_Types.Checked)
            {
                if (rdbtn_All_Channels.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else if (rdbtn_Branch.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransferChannel == Model.Models.Enums.TransferChannel.Branch && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else if (rdbtn_Internet.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransferChannel == Model.Models.Enums.TransferChannel.Internet && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransferChannel == Model.Models.Enums.TransferChannel.ATM && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
            }
            else if(rdbtn_Deposit.Checked)
            {
                if (rdbtn_All_Channels.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Deposit && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else if (rdbtn_Branch.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Deposit && x.TransferChannel == Model.Models.Enums.TransferChannel.Branch && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else if (rdbtn_Internet.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Deposit && x.TransferChannel == Model.Models.Enums.TransferChannel.Internet && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Deposit && x.TransferChannel == Model.Models.Enums.TransferChannel.ATM && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
            }
            else if(rdbtn_Withdrawal.Checked)
            {
                if (rdbtn_All_Channels.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Withdrawal && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else if (rdbtn_Branch.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Withdrawal && x.TransferChannel == Model.Models.Enums.TransferChannel.Branch && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else if (rdbtn_Internet.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Withdrawal && x.TransferChannel == Model.Models.Enums.TransferChannel.Internet && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Withdrawal && x.TransferChannel == Model.Models.Enums.TransferChannel.ATM && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
            }
            else if(rdbtn_Remission.Checked)
            {
                if (rdbtn_All_Channels.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Remission && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else if (rdbtn_Branch.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Remission && x.TransferChannel == Model.Models.Enums.TransferChannel.Branch && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else if (rdbtn_Internet.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Remission && x.TransferChannel == Model.Models.Enums.TransferChannel.Internet && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Remission && x.TransferChannel == Model.Models.Enums.TransferChannel.ATM && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
            }
            else
            {
                if (rdbtn_All_Channels.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Receival && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else if (rdbtn_Branch.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Receival && x.TransferChannel == Model.Models.Enums.TransferChannel.Branch && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else if (rdbtn_Internet.Checked)
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Receival && x.TransferChannel == Model.Models.Enums.TransferChannel.Internet && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
                else
                {
                    dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id && x.TransactionType == Model.Models.Enums.TransferType.Receival && x.TransferChannel == Model.Models.Enums.TransferChannel.ATM && x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).ToList();
                }
            }



            HideSelectedColumns();
        }
    }
}
