﻿using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.StandardCustomerService
{
    public interface IStandardCustomerService
    {
        public void Create(StandardCustomer standardCustomer);
        public void Delete(StandardCustomer standardCustomer);
        public StandardCustomer Get(Guid id);
        public List<StandardCustomer> GetAll();
        public void Update(StandardCustomer standardCustomer);
    }
}
