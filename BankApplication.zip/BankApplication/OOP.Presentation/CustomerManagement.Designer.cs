﻿namespace OOP.Presentation
{
    partial class CustomerManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgw_Customer_List = new DataGridView();
            label1 = new Label();
            grpbx_New_Customer_Details = new GroupBox();
            rdbtn_Student = new RadioButton();
            rdbtn_Standard = new RadioButton();
            label6 = new Label();
            txt_University = new TextBox();
            lbl_University = new Label();
            txt_City = new TextBox();
            txt_Email = new TextBox();
            txt_Surname = new TextBox();
            txt_Name = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label5 = new Label();
            btn_Update_Customer = new Button();
            btn_Delete_Customer = new Button();
            ((System.ComponentModel.ISupportInitialize)dgw_Customer_List).BeginInit();
            grpbx_New_Customer_Details.SuspendLayout();
            SuspendLayout();
            // 
            // dgw_Customer_List
            // 
            dgw_Customer_List.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Customer_List.Location = new Point(16, 32);
            dgw_Customer_List.Name = "dgw_Customer_List";
            dgw_Customer_List.RowHeadersWidth = 51;
            dgw_Customer_List.Size = new Size(772, 175);
            dgw_Customer_List.TabIndex = 5;
            dgw_Customer_List.RowHeaderMouseClick += dgw_Customer_List_RowHeaderMouseClick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(122, 20);
            label1.TabIndex = 4;
            label1.Text = "CUSTOMER LIST";
            // 
            // grpbx_New_Customer_Details
            // 
            grpbx_New_Customer_Details.Controls.Add(rdbtn_Student);
            grpbx_New_Customer_Details.Controls.Add(rdbtn_Standard);
            grpbx_New_Customer_Details.Controls.Add(label6);
            grpbx_New_Customer_Details.Controls.Add(txt_University);
            grpbx_New_Customer_Details.Controls.Add(lbl_University);
            grpbx_New_Customer_Details.Controls.Add(txt_City);
            grpbx_New_Customer_Details.Controls.Add(txt_Email);
            grpbx_New_Customer_Details.Controls.Add(txt_Surname);
            grpbx_New_Customer_Details.Controls.Add(txt_Name);
            grpbx_New_Customer_Details.Controls.Add(label4);
            grpbx_New_Customer_Details.Controls.Add(label3);
            grpbx_New_Customer_Details.Controls.Add(label2);
            grpbx_New_Customer_Details.Controls.Add(label5);
            grpbx_New_Customer_Details.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            grpbx_New_Customer_Details.Location = new Point(16, 223);
            grpbx_New_Customer_Details.Name = "grpbx_New_Customer_Details";
            grpbx_New_Customer_Details.Size = new Size(591, 182);
            grpbx_New_Customer_Details.TabIndex = 7;
            grpbx_New_Customer_Details.TabStop = false;
            grpbx_New_Customer_Details.Text = "Customer Details";
            // 
            // rdbtn_Student
            // 
            rdbtn_Student.AutoSize = true;
            rdbtn_Student.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 162);
            rdbtn_Student.Location = new Point(192, 33);
            rdbtn_Student.Name = "rdbtn_Student";
            rdbtn_Student.Size = new Size(81, 24);
            rdbtn_Student.TabIndex = 11;
            rdbtn_Student.TabStop = true;
            rdbtn_Student.Text = "Student";
            rdbtn_Student.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Standard
            // 
            rdbtn_Standard.AutoSize = true;
            rdbtn_Standard.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 162);
            rdbtn_Standard.Location = new Point(96, 32);
            rdbtn_Standard.Name = "rdbtn_Standard";
            rdbtn_Standard.Size = new Size(90, 24);
            rdbtn_Standard.TabIndex = 10;
            rdbtn_Standard.TabStop = true;
            rdbtn_Standard.Text = "Standard";
            rdbtn_Standard.UseVisualStyleBackColor = true;
            rdbtn_Standard.CheckedChanged += rdtbn_Standard_CheckedChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(43, 32);
            label6.Name = "label6";
            label6.Size = new Size(46, 20);
            label6.TabIndex = 8;
            label6.Text = "Type:";
            // 
            // txt_University
            // 
            txt_University.Location = new Point(97, 142);
            txt_University.Name = "txt_University";
            txt_University.Size = new Size(487, 27);
            txt_University.TabIndex = 9;
            // 
            // lbl_University
            // 
            lbl_University.AutoSize = true;
            lbl_University.Location = new Point(5, 145);
            lbl_University.Name = "lbl_University";
            lbl_University.Size = new Size(84, 20);
            lbl_University.TabIndex = 8;
            lbl_University.Text = "University:";
            // 
            // txt_City
            // 
            txt_City.Location = new Point(361, 96);
            txt_City.Name = "txt_City";
            txt_City.Size = new Size(223, 27);
            txt_City.TabIndex = 7;
            // 
            // txt_Email
            // 
            txt_Email.Location = new Point(361, 61);
            txt_Email.Name = "txt_Email";
            txt_Email.Size = new Size(223, 27);
            txt_Email.TabIndex = 6;
            // 
            // txt_Surname
            // 
            txt_Surname.Location = new Point(97, 96);
            txt_Surname.Name = "txt_Surname";
            txt_Surname.Size = new Size(201, 27);
            txt_Surname.TabIndex = 5;
            // 
            // txt_Name
            // 
            txt_Name.Location = new Point(97, 63);
            txt_Name.Name = "txt_Name";
            txt_Name.Size = new Size(201, 27);
            txt_Name.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(315, 98);
            label4.Name = "label4";
            label4.Size = new Size(40, 20);
            label4.TabIndex = 3;
            label4.Text = "City:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(304, 66);
            label3.Name = "label3";
            label3.Size = new Size(51, 20);
            label3.TabIndex = 2;
            label3.Text = "Email:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(14, 98);
            label2.Name = "label2";
            label2.Size = new Size(75, 20);
            label2.TabIndex = 1;
            label2.Text = "Surname:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(34, 64);
            label5.Name = "label5";
            label5.Size = new Size(55, 20);
            label5.TabIndex = 0;
            label5.Text = "Name:";
            // 
            // btn_Update_Customer
            // 
            btn_Update_Customer.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btn_Update_Customer.Location = new Point(620, 235);
            btn_Update_Customer.Name = "btn_Update_Customer";
            btn_Update_Customer.Size = new Size(168, 74);
            btn_Update_Customer.TabIndex = 8;
            btn_Update_Customer.Text = "UPDATE CUSTOMER";
            btn_Update_Customer.UseVisualStyleBackColor = true;
            btn_Update_Customer.Click += btn_Update_Customer_Click;
            // 
            // btn_Delete_Customer
            // 
            btn_Delete_Customer.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btn_Delete_Customer.Location = new Point(620, 321);
            btn_Delete_Customer.Name = "btn_Delete_Customer";
            btn_Delete_Customer.Size = new Size(168, 74);
            btn_Delete_Customer.TabIndex = 9;
            btn_Delete_Customer.Text = "DELETE CUSTOMER";
            btn_Delete_Customer.UseVisualStyleBackColor = true;
            btn_Delete_Customer.Click += btn_Delete_Customer_Click;
            // 
            // CustomerManagement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(817, 431);
            Controls.Add(btn_Delete_Customer);
            Controls.Add(btn_Update_Customer);
            Controls.Add(grpbx_New_Customer_Details);
            Controls.Add(dgw_Customer_List);
            Controls.Add(label1);
            Name = "CustomerManagement";
            Text = "CustomerManagement";
            WindowState = FormWindowState.Maximized;
            Load += CustomerManagement_Load;
            ((System.ComponentModel.ISupportInitialize)dgw_Customer_List).EndInit();
            grpbx_New_Customer_Details.ResumeLayout(false);
            grpbx_New_Customer_Details.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DataGridView dgw_Customer_List;
        private Label label1;
        private GroupBox grpbx_New_Customer_Details;
        private TextBox txt_University;
        private Label lbl_University;
        private TextBox txt_City;
        private TextBox txt_Email;
        private TextBox txt_Surname;
        private TextBox txt_Name;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label5;
        private RadioButton rdbtn_Student;
        private RadioButton rdbtn_Standard;
        private Label label6;
        private Button btn_Update_Customer;
        private Button btn_Delete_Customer;
    }
}