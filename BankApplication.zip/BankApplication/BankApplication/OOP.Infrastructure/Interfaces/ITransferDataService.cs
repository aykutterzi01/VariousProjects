﻿using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace OOP.Infrastructure.Interfaces
{
    public interface ITransferDataService : IBaseDataService<Transfer>
    {
    }
}
