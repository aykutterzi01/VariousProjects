﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Model.Models.Enums
{
    public enum TransferChannel
    {
        Unknown = 0,
        Branch = 1,
        Internet = 2,
        ATM
    }
}
