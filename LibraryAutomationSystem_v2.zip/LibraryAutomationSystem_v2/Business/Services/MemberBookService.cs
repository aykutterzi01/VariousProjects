﻿using LibraryAutomationSystem.Context;
using LibraryAutomationSystem.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services;

public class MemberBookService
{
    private readonly AppDbContext dbContext;
    public MemberBookService()
    {
        this.dbContext = new AppDbContext();
    }

    public void Create(MemberBook memberBook)
    {
        dbContext.MemberBooks.Add(memberBook);
        dbContext.SaveChanges();
    }

    public void Delete(MemberBook memberBook)
    {
        dbContext.MemberBooks.Remove(memberBook);
        dbContext.SaveChanges();
    }

    public void Update(MemberBook memberBook)
    {
        dbContext.MemberBooks.Update(memberBook);
        dbContext.SaveChanges();
    }

    public IQueryable<MemberBook> GetAll()
    {
        return dbContext.MemberBooks;

    }
}
