﻿using Business.Services;
using Entities.Entities;
using Entities.Entities.Enums;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class PayrollMangement : Form
    {
        PayrollService _payrollService;
        PersonnelService _personnelService;

        public PayrollMangement(PersonnelService personnelService, PayrollService payrollService)
        {
            InitializeComponent();
            _payrollService = payrollService;
            _personnelService = personnelService;
        }

        private void PayrollMangement_Load(object sender, EventArgs e)
        {
            cmbPersonnel.DataSource = _personnelService.GetAll();
            cmbMonth.DataSource = Enum.GetValues(typeof(Month));
            ResetTable();
        }

        private void ResetTable()
        {
            dgwPayrolls.DataSource = null;

            var personnel = cmbPersonnel.SelectedItem as Personnel;

            dgwPayrolls.DataSource = _payrollService.GetAll().Include(x => x.Personnel).Where(p => p.PersonnelId == personnel.Id).ToList();
            dgwPayrolls.Columns["Id"].Visible = false;
            dgwPayrolls.Columns["PersonnelId"].Visible = false;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var personnel = cmbPersonnel.SelectedItem as Personnel;
            Payroll payroll = new Payroll();

            payroll.Month = (Month)cmbMonth.SelectedItem;
            //payroll.Personnel = _personnelService.GetAll().FirstOrDefault(x => x.Id == personnel.Id);
            payroll.PersonnelId = personnel.Id;
            payroll.WorkingHour = Convert.ToInt32(nudWorkingHour.Value);

            _payrollService.Create(payroll);

            MessageBox.Show("The payroll has been added.");

            ResetTable();
            CleanTexts();
        }

        private void CleanTexts()
        {
            cmbPersonnel.SelectedIndex = 0;
            cmbMonth.SelectedIndex = 0;
            nudWorkingHour.Value = 0;
        }

        private void cmbPersonnel_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetTable();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            var payrollId = (Guid)(dgwPayrolls.SelectedRows[0].Cells["Id"]).Value;
            var payroll = _payrollService.GetAll().FirstOrDefault(x => x.Id == payrollId);

            payroll.PersonnelId = ((Personnel)cmbPersonnel.SelectedItem).Id;
            payroll.Month = (Month)cmbMonth.SelectedItem;
            payroll.WorkingHour = Convert.ToInt32(nudWorkingHour.Value);

            _payrollService.Update(payroll);

            MessageBox.Show("The payroll has been updated.");

            ResetTable();
            CleanTexts();
        }

        private void dgwPayrolls_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var payrollId = (Guid)(dgwPayrolls.SelectedRows[0].Cells["Id"]).Value;
            var payroll = _payrollService.GetAll().FirstOrDefault(x => x.Id == payrollId);

            cmbPersonnel.SelectedItem = payroll.Personnel;
            cmbMonth.SelectedItem = payroll.Month;
            nudWorkingHour.Value = payroll.WorkingHour;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var payrollId = (Guid)(dgwPayrolls.SelectedRows[0].Cells["Id"]).Value;
            var payroll = _payrollService.GetAll().FirstOrDefault(x => x.Id == payrollId);

            _payrollService.Delete(payroll);

            MessageBox.Show("The payroll has been deleted.");

            ResetTable();
            CleanTexts();
        }
    }
}
