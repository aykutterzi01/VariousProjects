﻿namespace Presentation
{
    partial class StudentManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            groupBox1 = new GroupBox();
            lblRegistrationId = new Label();
            btnStudentUpdate = new Button();
            btnStudentAdd = new Button();
            lbTeacherCourses = new ListBox();
            rdbtnFemale = new RadioButton();
            rdbtnMale = new RadioButton();
            dtpStudentBirthDate = new DateTimePicker();
            txtStudentSurname = new TextBox();
            txtStudentName = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            dgwRegistrations = new DataGridView();
            contextMenuStrip1 = new ContextMenuStrip(components);
            deleteToolStripMenuItem = new ToolStripMenuItem();
            updateToolStripMenuItem = new ToolStripMenuItem();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgwRegistrations).BeginInit();
            contextMenuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblRegistrationId);
            groupBox1.Controls.Add(btnStudentUpdate);
            groupBox1.Controls.Add(btnStudentAdd);
            groupBox1.Controls.Add(lbTeacherCourses);
            groupBox1.Controls.Add(rdbtnFemale);
            groupBox1.Controls.Add(rdbtnMale);
            groupBox1.Controls.Add(dtpStudentBirthDate);
            groupBox1.Controls.Add(txtStudentSurname);
            groupBox1.Controls.Add(txtStudentName);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(18, 15);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(770, 225);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "STUDENT DETAILS";
            // 
            // lblRegistrationId
            // 
            lblRegistrationId.AutoSize = true;
            lblRegistrationId.Location = new Point(6, 190);
            lblRegistrationId.Name = "lblRegistrationId";
            lblRegistrationId.Size = new Size(51, 20);
            lblRegistrationId.TabIndex = 12;
            lblRegistrationId.Text = "label5";
            lblRegistrationId.Visible = false;
            // 
            // btnStudentUpdate
            // 
            btnStudentUpdate.Location = new Point(259, 184);
            btnStudentUpdate.Name = "btnStudentUpdate";
            btnStudentUpdate.Size = new Size(136, 29);
            btnStudentUpdate.TabIndex = 11;
            btnStudentUpdate.Text = "UPDATE";
            btnStudentUpdate.UseVisualStyleBackColor = true;
            btnStudentUpdate.Click += btnStudentUpdate_Click;
            // 
            // btnStudentAdd
            // 
            btnStudentAdd.Location = new Point(95, 184);
            btnStudentAdd.Name = "btnStudentAdd";
            btnStudentAdd.Size = new Size(134, 29);
            btnStudentAdd.TabIndex = 10;
            btnStudentAdd.Text = "ADD";
            btnStudentAdd.UseVisualStyleBackColor = true;
            btnStudentAdd.Click += btnStudentAdd_Click;
            // 
            // lbTeacherCourses
            // 
            lbTeacherCourses.FormattingEnabled = true;
            lbTeacherCourses.Location = new Point(425, 23);
            lbTeacherCourses.Name = "lbTeacherCourses";
            lbTeacherCourses.SelectionMode = SelectionMode.MultiSimple;
            lbTeacherCourses.Size = new Size(328, 184);
            lbTeacherCourses.TabIndex = 9;
            // 
            // rdbtnFemale
            // 
            rdbtnFemale.AutoSize = true;
            rdbtnFemale.Location = new Point(234, 146);
            rdbtnFemale.Name = "rdbtnFemale";
            rdbtnFemale.Size = new Size(80, 24);
            rdbtnFemale.TabIndex = 8;
            rdbtnFemale.TabStop = true;
            rdbtnFemale.Text = "Female";
            rdbtnFemale.UseVisualStyleBackColor = true;
            // 
            // rdbtnMale
            // 
            rdbtnMale.AutoSize = true;
            rdbtnMale.Location = new Point(97, 148);
            rdbtnMale.Name = "rdbtnMale";
            rdbtnMale.Size = new Size(64, 24);
            rdbtnMale.TabIndex = 7;
            rdbtnMale.TabStop = true;
            rdbtnMale.Text = "Male";
            rdbtnMale.UseVisualStyleBackColor = true;
            // 
            // dtpStudentBirthDate
            // 
            dtpStudentBirthDate.Location = new Point(95, 106);
            dtpStudentBirthDate.Name = "dtpStudentBirthDate";
            dtpStudentBirthDate.Size = new Size(300, 27);
            dtpStudentBirthDate.TabIndex = 6;
            // 
            // txtStudentSurname
            // 
            txtStudentSurname.Location = new Point(95, 67);
            txtStudentSurname.Name = "txtStudentSurname";
            txtStudentSurname.Size = new Size(300, 27);
            txtStudentSurname.TabIndex = 5;
            // 
            // txtStudentName
            // 
            txtStudentName.Location = new Point(95, 32);
            txtStudentName.Name = "txtStudentName";
            txtStudentName.Size = new Size(300, 27);
            txtStudentName.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(21, 146);
            label4.Name = "label4";
            label4.Size = new Size(68, 20);
            label4.TabIndex = 3;
            label4.Text = "Gender :";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(4, 104);
            label3.Name = "label3";
            label3.Size = new Size(85, 20);
            label3.TabIndex = 2;
            label3.Text = "BirthDate :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(10, 70);
            label2.Name = "label2";
            label2.Size = new Size(79, 20);
            label2.TabIndex = 1;
            label2.Text = "Surname :";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(30, 35);
            label1.Name = "label1";
            label1.Size = new Size(59, 20);
            label1.TabIndex = 0;
            label1.Text = "Name :";
            // 
            // dgwRegistrations
            // 
            dgwRegistrations.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwRegistrations.ContextMenuStrip = contextMenuStrip1;
            dgwRegistrations.Location = new Point(20, 252);
            dgwRegistrations.MultiSelect = false;
            dgwRegistrations.Name = "dgwRegistrations";
            dgwRegistrations.ReadOnly = true;
            dgwRegistrations.RowHeadersWidth = 51;
            dgwRegistrations.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwRegistrations.Size = new Size(768, 188);
            dgwRegistrations.TabIndex = 1;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { deleteToolStripMenuItem, updateToolStripMenuItem });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(128, 52);
            // 
            // deleteToolStripMenuItem
            // 
            deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            deleteToolStripMenuItem.Size = new Size(127, 24);
            deleteToolStripMenuItem.Text = "Delete";
            deleteToolStripMenuItem.Click += deleteToolStripMenuItem_Click;
            // 
            // updateToolStripMenuItem
            // 
            updateToolStripMenuItem.Name = "updateToolStripMenuItem";
            updateToolStripMenuItem.Size = new Size(127, 24);
            updateToolStripMenuItem.Text = "Update";
            updateToolStripMenuItem.Click += updateToolStripMenuItem_Click;
            // 
            // StudentManagement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgwRegistrations);
            Controls.Add(groupBox1);
            Name = "StudentManagement";
            Text = "StudentManagement";
            Load += StudentManagement_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgwRegistrations).EndInit();
            contextMenuStrip1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton rdbtnFemale;
        private RadioButton rdbtnMale;
        private DateTimePicker dtpStudentBirthDate;
        private TextBox txtStudentSurname;
        private TextBox txtStudentName;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private Button btnStudentUpdate;
        private Button btnStudentAdd;
        private ListBox lbTeacherCourses;
        private Label lblRegistrationId;
        private DataGridView dgwRegistrations;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem deleteToolStripMenuItem;
        private ToolStripMenuItem updateToolStripMenuItem;
    }
}