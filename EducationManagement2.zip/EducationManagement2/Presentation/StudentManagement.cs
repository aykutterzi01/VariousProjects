﻿using Applicationn.CourseService;
using Applicationn.StudentService;
using Applicationn.StudentTeacherCourseService;
using Applicationn.TeacherCourseService;
using Applicationn.TeacherService;
using Models.Models;
using Presentation.VMs;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class StudentManagement : Form
    {
        CourseService _courseService;
        TeacherService _teacherService;
        TeacherCourseService _teacherCourseService;
        StudentTeacherCourseService _studentTeacherCourseService;
        StudentService _studentService;

        public StudentManagement(CourseService courseService, TeacherService teacherService, TeacherCourseService teacherCourseService, StudentTeacherCourseService studentTeacherCourseService, StudentService studentService)
        {
            InitializeComponent();
            _courseService = courseService;
            _teacherService = teacherService;
            _teacherCourseService = teacherCourseService;
            _studentTeacherCourseService = studentTeacherCourseService;
            _studentService = studentService;
        }

        private void StudentManagement_Load(object sender, EventArgs e)
        {
            btnStudentUpdate.Enabled = false;
            ResetTable();
        }

        private void ResetTable()
        {
            dgwRegistrations.DataSource = null;

            var students = _studentService.GetAll();
            List<StudentListVM> list = new List<StudentListVM>();

            foreach (var student in students)
            {
                var studentTeacherCourses = _studentTeacherCourseService.GetAll().Where(x => x.StudentId == student.Id);

                StudentListVM studentListVM = new StudentListVM();

                studentListVM.Id = student.Id;
                studentListVM.FullName = student.Name + " " + student.Surname;
                studentListVM.BirthDate = student.BirthDate;
                studentListVM.Gender = student.Gender;

                foreach (var studentTeacherCourse in studentTeacherCourses)
                {
                    var teacherCourses = _teacherCourseService.GetAll().Where(x => x.Id == studentTeacherCourse.TeacherCourseId);

                    foreach (var teacherCourse in teacherCourses)
                    {
                        var course = _courseService.GetAll().FirstOrDefault(x => x.Id == teacherCourse.CourseId);

                        var teacher = _teacherService.GetAll().FirstOrDefault(x => x.Id == teacherCourse.TeacherId);

                        studentListVM.CoursesWithTeachers = studentListVM.CoursesWithTeachers + " - " + course.Name + " | " + course.Code + " | " + teacher.Name + " " + teacher.Surname;

                    }
                }

                list.Add(studentListVM);
            }

            List<TeacherCourseListVM> teacherCourseList = new List<TeacherCourseListVM>();

            var _teacherCourses = _teacherCourseService.GetAll();

            foreach (var teacherCourse in _teacherCourses)
            {
                var course = _courseService.Get(teacherCourse.CourseId);
                var teacher = _teacherService.Get(teacherCourse.TeacherId);

                TeacherCourseListVM teacherCourseListVM = new TeacherCourseListVM();

                teacherCourseListVM.Id = teacherCourse.Id;
                teacherCourseListVM.CourseWithTeacher = course.Name + " | " + course.Code + " | " + teacher.Name + " " + teacher.Surname;

                teacherCourseList.Add(teacherCourseListVM);
            }

            dgwRegistrations.DataSource = list;
            dgwRegistrations.Columns["Id"].Visible = false;

            lbTeacherCourses.DataSource = null;
            lbTeacherCourses.DataSource = teacherCourseList;
            lbTeacherCourses.DisplayMember = "CourseWithTeacher";
            lbTeacherCourses.ValueMember = "Id";
            lbTeacherCourses.SelectedIndex = -1;

            Clean();
        }

        private void Clean()
        {
            txtStudentName.Text = string.Empty;
            txtStudentSurname.Text = string.Empty;
            dtpStudentBirthDate.Value = DateTime.Now;
            rdbtnMale.Checked = false;
            rdbtnFemale.Checked = false;
        }

        private void btnStudentAdd_Click(object sender, EventArgs e)
        {
            Student student = new Student()
            {
                Name = txtStudentName.Text,
                Surname = txtStudentSurname.Text,
                BirthDate = dtpStudentBirthDate.Value,
                Gender = rdbtnMale.Checked ? Models.Models.Enums.Gender.Male : Models.Models.Enums.Gender.Female
            };

            _studentService.Create(student);

            var addedStudent = _studentService.GetAll().LastOrDefault();

            var selectedTeacherCourseIds = lbTeacherCourses.SelectedItems.Cast<TeacherCourseListVM>().Select(x => x.Id);

            foreach (var selectedTeacherCourseId in selectedTeacherCourseIds)
            {
                StudentTeacherCourse studentTeacherCourse = new StudentTeacherCourse();
                studentTeacherCourse.TeacherCourseId = selectedTeacherCourseId;
                studentTeacherCourse.StudentId = addedStudent.Id;
                _studentTeacherCourseService.Create(studentTeacherCourse);
            }

            ResetTable();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var deletedStudent = _studentService.Get(SelectedId());
            _studentService.Delete(deletedStudent);

            var deletedStudentTeacherCourses = _studentTeacherCourseService.GetAll().Where(x => x.StudentId == deletedStudent.Id);

            foreach (var deletedStudentTeacherCourse in deletedStudentTeacherCourses)
            {
                _studentTeacherCourseService.Delete(deletedStudentTeacherCourse);
            }

            ResetTable();
        }

        private Guid SelectedId()
        {
            var id = ((StudentListVM)(dgwRegistrations.SelectedRows[0].DataBoundItem)).Id;
            lblRegistrationId.Text = id.ToString();
            return id;
        }

        private void updateToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lbTeacherCourses.SelectedItems.Clear();

            var selectedId = SelectedId();
            var updatedStudentTeacherCourse = _studentTeacherCourseService.GetAll().FirstOrDefault(x => x.StudentId == selectedId);

            txtStudentName.Text = _studentService.Get(updatedStudentTeacherCourse.StudentId).Name;

            txtStudentSurname.Text = _studentService.Get(updatedStudentTeacherCourse.StudentId).Surname;

            dtpStudentBirthDate.Value = _studentService.Get(updatedStudentTeacherCourse.StudentId).BirthDate;

            var studentGender = _studentService.Get(updatedStudentTeacherCourse.StudentId).Gender;

            if (studentGender == Models.Models.Enums.Gender.Male)
            {
                rdbtnMale.Checked = true;
            }
            else
            {
                rdbtnFemale.Checked = true;
            }

            List<TeacherCourse> selectedTeacherCourses = new List<TeacherCourse>();

            var studentTeacherCourses = _studentTeacherCourseService.GetAll().Where(x => x.StudentId == selectedId);

            var teacherCourseIds = studentTeacherCourses.Select(x => x.TeacherCourseId);

            foreach (var teacherCourseId in teacherCourseIds)
            {
                var teacherCourse = _teacherCourseService.Get(teacherCourseId);

                selectedTeacherCourses.Add(teacherCourse);
            }

            List<TeacherCourseListVM> teacherCourses = lbTeacherCourses.DataSource as List<TeacherCourseListVM>;

            foreach (var teacherCourse in teacherCourses)
            {
                foreach (var selectedTeacherCourse in selectedTeacherCourses)
                {
                    if (teacherCourse.Id == selectedTeacherCourse.Id)
                    {
                        lbTeacherCourses.SelectedItems.Add(teacherCourse);
                    }
                }
            }

            btnStudentUpdate.Enabled = true;
        }

        private void btnStudentUpdate_Click(object sender, EventArgs e)
        {
            Student student = new Student()
            {
                Name = txtStudentName.Text,
                Surname = txtStudentSurname.Text,
                BirthDate = dtpStudentBirthDate.Value,
                Gender = rdbtnMale.Checked ? Models.Models.Enums.Gender.Male : Models.Models.Enums.Gender.Female,
                Id = Guid.Parse(lblRegistrationId.Text)
            };

            _studentService.Update(student);
            btnStudentUpdate.Enabled = false;

            var selectedStudentTeacherCourses = _studentTeacherCourseService.GetAll().Where(x => x.StudentId == student.Id);

            // Öncelikle, güncellenen öğrencinin seçili derslerini alalım
            var selectedTeacherCourseIds = lbTeacherCourses.SelectedItems.Cast<TeacherCourseListVM>().Select(x => x.Id).ToList();

            // Veritabanındaki derslerle karşılaştırma yaparak güncellemeleri tespit edelim
            foreach (var selectedStudentTeacherCourse in selectedStudentTeacherCourses)
            {
                if (!selectedTeacherCourseIds.Contains(selectedStudentTeacherCourse.TeacherCourseId))
                {
                    // Eğer seçili dersler arasında güncellenmemiş bir ders varsa, bu dersi veritabanından kaldıralım
                    _studentTeacherCourseService.Delete(selectedStudentTeacherCourse);
                }
                else
                {
                    // Dersler arasında bir değişiklik yoksa, listeden kaldıralım
                    selectedTeacherCourseIds.Remove(selectedStudentTeacherCourse.TeacherCourseId);
                }
            }

            // Güncellenen öğrenciye yeni eklenen dersleri veritabanına ekleyelim
            foreach (var teacherCourseId in selectedTeacherCourseIds)
            {
                StudentTeacherCourse studentTeacherCourse = new StudentTeacherCourse();
                studentTeacherCourse.TeacherCourseId = teacherCourseId;
                studentTeacherCourse.StudentId = student.Id;
                _studentTeacherCourseService.Create(studentTeacherCourse);
            }

            // Tabloyu yeniden başlat
            ResetTable();
        }
    }
}
