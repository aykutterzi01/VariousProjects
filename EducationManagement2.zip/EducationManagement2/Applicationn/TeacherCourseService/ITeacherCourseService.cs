﻿using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applicationn.TeacherCourseService
{
    public interface ITeacherCourseService
    {
        public void Create(TeacherCourse teacherCourse);
        public void Delete(TeacherCourse teacherCourse);
        public TeacherCourse Get(Guid id);
        public List<TeacherCourse> GetAll();
        public void Update(TeacherCourse teacherCourse);
    }
}
