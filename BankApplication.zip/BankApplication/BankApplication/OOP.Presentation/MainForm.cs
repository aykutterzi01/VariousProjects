namespace OOP.Presentation
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void createAccountToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateAccount createAccount = new CreateAccount();
            createAccount.MdiParent = MainForm.ActiveForm;
            createAccount.Show();
        }

        private void makeTransferToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MakeTransfer makeTransfer = new MakeTransfer();
            makeTransfer.MdiParent = MainForm.ActiveForm;
            makeTransfer.Show();
        }
    }
}
