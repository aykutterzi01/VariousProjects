﻿using OOP.Infrastructure.DataService;
using OOP.Infrastructure.Interfaces;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.StudentCustomerService
{
    public class StudentCustomerService : IStudentCustomerService
    {
        private readonly IStudentCustomerDataService _studentCustomerDataService;

        public StudentCustomerService()
        {
            _studentCustomerDataService = new StudentCustomerDataService();
        }
        public void Create(StudentCustomer studentCustomer)
        {
            var studentCustomers = _studentCustomerDataService.GetData();
            studentCustomers.Add(studentCustomer);
            _studentCustomerDataService.Save(studentCustomers);
        }

        public void Delete(StudentCustomer studentCustomer)
        {
            var studentCustomers = _studentCustomerDataService.GetData();
            studentCustomers.Remove(studentCustomer);
            _studentCustomerDataService.Save(studentCustomers);
        }

        public StudentCustomer Get(Guid id)
        {
            var studentCustomers = _studentCustomerDataService.GetData();
            return studentCustomers.FirstOrDefault(x => x.Id == id);
        }

        public List<StudentCustomer> GetAll()
        {
            return _studentCustomerDataService.GetData();
        }

        public void Update(StudentCustomer studentCustomer)
        {
            var studentCustomers = _studentCustomerDataService.GetData();
            var updating = studentCustomers.FirstOrDefault(x => x.Id == studentCustomer.Id);
            var indexStudentCustomer = studentCustomers.IndexOf(studentCustomer);
            studentCustomers[indexStudentCustomer] = studentCustomer;

        }
    }
}
