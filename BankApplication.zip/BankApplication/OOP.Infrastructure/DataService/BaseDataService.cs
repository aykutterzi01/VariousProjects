﻿using OOP.Infrastructure.Interfaces;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace OOP.Infrastructure.DataService
{
    public class BaseDataService<T> : IBaseDataService<T> where T : BaseModel
    {
        private readonly string _file;

        public BaseDataService()
        {
            _file = $@"C:\Users\Lenovo\Desktop\HS14\BankApplication2\BankApplication\{typeof(T).Name}.json";
        }

        public List<T> GetData()
        {
            var dataJ = File.ReadAllText(_file);

            if (!string.IsNullOrWhiteSpace(dataJ))
            {
                return JsonSerializer.Deserialize<List<T>>(dataJ) ?? new List<T>();
            }
            else
            {
                return new List<T>();
            }
        }

        public void Save(List<T> data)
        {
            var dataJ = JsonSerializer.Serialize(data);
            File.WriteAllText(_file, dataJ);
        }
    }
}
