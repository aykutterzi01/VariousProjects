﻿using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.CustomerService
{
    public interface ICustomerService
    {
        public void Create(Customer customer);
        public void Delete(Customer customer);
        public Customer Get(Guid id);
        public List<Customer> GetAll();
        public void Update(Customer customer);
    }
}
