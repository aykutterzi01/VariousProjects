﻿using OOP.Infrastructure.DataService;
using OOP.Infrastructure.Interfaces;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.FoodService
{
    public class FoodService : IFoodService
    {
        private readonly IFoodDataService _foodDataService;

        public FoodService()
        {
            _foodDataService = new FoodDataService();
        }

        public void Create(Food food)
        {
            var foods = _foodDataService.GetData();
            foods.Add(food);
            _foodDataService.Save(foods);
        }

        public void Delete(Food food)
        {
            var foods = _foodDataService.GetData();
            foods.Remove(food);
            _foodDataService.Save(foods);
        }

        public Food Get(Guid id)
        {
            var foods = _foodDataService.GetData();
            return foods.FirstOrDefault(x => x.Id == id);
        }

        public List<Food> GetAll()
        {
            return _foodDataService.GetData();
        }

        public void Update(Food food)
        {
            var foods = _foodDataService.GetData();
            var updating = foods.FirstOrDefault(x => x.Id == food.Id);
            var indexFood = foods.IndexOf(updating);
            foods[indexFood] = food;
        }
    }
}
