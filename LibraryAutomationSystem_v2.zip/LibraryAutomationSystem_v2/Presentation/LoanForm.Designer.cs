﻿namespace Presentation
{
    partial class LoanForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnLoan = new Button();
            btnReturn = new Button();
            dgwBooks = new DataGridView();
            label1 = new Label();
            dgwLoans = new DataGridView();
            label2 = new Label();
            label3 = new Label();
            cmbMembers = new ComboBox();
            groupBox1 = new GroupBox();
            rdbtnScience = new RadioButton();
            rdbtnNovel = new RadioButton();
            rdbtnHistory = new RadioButton();
            rdbtnAllBooks = new RadioButton();
            groupBox2 = new GroupBox();
            rdbtnNotReturned = new RadioButton();
            rdbtnAllLoans = new RadioButton();
            ((System.ComponentModel.ISupportInitialize)dgwBooks).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgwLoans).BeginInit();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // btnLoan
            // 
            btnLoan.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnLoan.ForeColor = Color.FromArgb(192, 64, 0);
            btnLoan.Location = new Point(833, 235);
            btnLoan.Name = "btnLoan";
            btnLoan.Size = new Size(184, 64);
            btnLoan.TabIndex = 2;
            btnLoan.Text = "LOAN";
            btnLoan.UseVisualStyleBackColor = true;
            btnLoan.Click += btnLoan_Click;
            // 
            // btnReturn
            // 
            btnReturn.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            btnReturn.ForeColor = Color.FromArgb(192, 64, 0);
            btnReturn.Location = new Point(833, 457);
            btnReturn.Name = "btnReturn";
            btnReturn.Size = new Size(184, 64);
            btnReturn.TabIndex = 4;
            btnReturn.Text = "RETURN";
            btnReturn.UseVisualStyleBackColor = true;
            btnReturn.Click += btnReturn_Click;
            // 
            // dgwBooks
            // 
            dgwBooks.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwBooks.Location = new Point(26, 111);
            dgwBooks.MultiSelect = false;
            dgwBooks.Name = "dgwBooks";
            dgwBooks.ReadOnly = true;
            dgwBooks.RowHeadersWidth = 51;
            dgwBooks.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwBooks.Size = new Size(768, 188);
            dgwBooks.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.ForeColor = Color.White;
            label1.Location = new Point(26, 85);
            label1.Name = "label1";
            label1.Size = new Size(295, 23);
            label1.TabIndex = 6;
            label1.Text = "CHOOSE THE BOOK TO BE LOANED";
            // 
            // dgwLoans
            // 
            dgwLoans.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwLoans.Location = new Point(26, 333);
            dgwLoans.MultiSelect = false;
            dgwLoans.Name = "dgwLoans";
            dgwLoans.ReadOnly = true;
            dgwLoans.RowHeadersWidth = 51;
            dgwLoans.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwLoans.Size = new Size(768, 188);
            dgwLoans.TabIndex = 7;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.ForeColor = Color.White;
            label2.Location = new Point(26, 307);
            label2.Name = "label2";
            label2.Size = new Size(451, 23);
            label2.TabIndex = 8;
            label2.Text = "LOAN HISTORY / CHOOSE THE LOAN TO BE FINALIZED";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label3.ForeColor = Color.White;
            label3.Location = new Point(26, 23);
            label3.Name = "label3";
            label3.Size = new Size(193, 23);
            label3.TabIndex = 9;
            label3.Text = "CHOOSE THE MEMBER";
            // 
            // cmbMembers
            // 
            cmbMembers.FormattingEnabled = true;
            cmbMembers.Location = new Point(239, 18);
            cmbMembers.Name = "cmbMembers";
            cmbMembers.Size = new Size(555, 28);
            cmbMembers.TabIndex = 10;
            cmbMembers.SelectedIndexChanged += cmbMembers_SelectedIndexChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rdbtnScience);
            groupBox1.Controls.Add(rdbtnNovel);
            groupBox1.Controls.Add(rdbtnHistory);
            groupBox1.Controls.Add(rdbtnAllBooks);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.ForeColor = Color.White;
            groupBox1.Location = new Point(815, 58);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(213, 152);
            groupBox1.TabIndex = 11;
            groupBox1.TabStop = false;
            groupBox1.Text = "FILTER BOOKS";
            // 
            // rdbtnScience
            // 
            rdbtnScience.AutoSize = true;
            rdbtnScience.Location = new Point(12, 119);
            rdbtnScience.Name = "rdbtnScience";
            rdbtnScience.Size = new Size(81, 24);
            rdbtnScience.TabIndex = 3;
            rdbtnScience.TabStop = true;
            rdbtnScience.Text = "Science";
            rdbtnScience.UseVisualStyleBackColor = true;
            rdbtnScience.CheckedChanged += rdbtnScience_CheckedChanged;
            // 
            // rdbtnNovel
            // 
            rdbtnNovel.AutoSize = true;
            rdbtnNovel.Location = new Point(12, 89);
            rdbtnNovel.Name = "rdbtnNovel";
            rdbtnNovel.Size = new Size(71, 24);
            rdbtnNovel.TabIndex = 2;
            rdbtnNovel.TabStop = true;
            rdbtnNovel.Text = "Novel";
            rdbtnNovel.UseVisualStyleBackColor = true;
            rdbtnNovel.CheckedChanged += rdbtnNovel_CheckedChanged;
            // 
            // rdbtnHistory
            // 
            rdbtnHistory.AutoSize = true;
            rdbtnHistory.Location = new Point(12, 59);
            rdbtnHistory.Name = "rdbtnHistory";
            rdbtnHistory.Size = new Size(82, 24);
            rdbtnHistory.TabIndex = 1;
            rdbtnHistory.TabStop = true;
            rdbtnHistory.Text = "History";
            rdbtnHistory.UseVisualStyleBackColor = true;
            rdbtnHistory.CheckedChanged += rdbtnHistory_CheckedChanged;
            // 
            // rdbtnAllBooks
            // 
            rdbtnAllBooks.AutoSize = true;
            rdbtnAllBooks.Location = new Point(12, 29);
            rdbtnAllBooks.Name = "rdbtnAllBooks";
            rdbtnAllBooks.Size = new Size(96, 24);
            rdbtnAllBooks.TabIndex = 0;
            rdbtnAllBooks.TabStop = true;
            rdbtnAllBooks.Text = "All Books";
            rdbtnAllBooks.UseVisualStyleBackColor = true;
            rdbtnAllBooks.CheckedChanged += rdbtnAllBooks_CheckedChanged;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(rdbtnNotReturned);
            groupBox2.Controls.Add(rdbtnAllLoans);
            groupBox2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox2.ForeColor = Color.White;
            groupBox2.Location = new Point(815, 343);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(213, 99);
            groupBox2.TabIndex = 12;
            groupBox2.TabStop = false;
            groupBox2.Text = "FILTER LOANS";
            // 
            // rdbtnNotReturned
            // 
            rdbtnNotReturned.AutoSize = true;
            rdbtnNotReturned.Location = new Point(12, 59);
            rdbtnNotReturned.Name = "rdbtnNotReturned";
            rdbtnNotReturned.Size = new Size(126, 24);
            rdbtnNotReturned.TabIndex = 1;
            rdbtnNotReturned.TabStop = true;
            rdbtnNotReturned.Text = "Not Returned";
            rdbtnNotReturned.UseVisualStyleBackColor = true;
            rdbtnNotReturned.CheckedChanged += rdbtnNotReturned_CheckedChanged;
            // 
            // rdbtnAllLoans
            // 
            rdbtnAllLoans.AutoSize = true;
            rdbtnAllLoans.Location = new Point(12, 29);
            rdbtnAllLoans.Name = "rdbtnAllLoans";
            rdbtnAllLoans.Size = new Size(94, 24);
            rdbtnAllLoans.TabIndex = 0;
            rdbtnAllLoans.TabStop = true;
            rdbtnAllLoans.Text = "All Loans";
            rdbtnAllLoans.UseVisualStyleBackColor = true;
            rdbtnAllLoans.CheckedChanged += rdbtnAllLoans_CheckedChanged;
            // 
            // LoanForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 64, 0);
            ClientSize = new Size(1058, 533);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(cmbMembers);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(dgwLoans);
            Controls.Add(label1);
            Controls.Add(dgwBooks);
            Controls.Add(btnReturn);
            Controls.Add(btnLoan);
            Name = "LoanForm";
            Text = "LoanForm";
            Load += LoanForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgwBooks).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgwLoans).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnLoan;
        private Button btnReturn;
        private DataGridView dgwBooks;
        private Label label1;
        private DataGridView dgwLoans;
        private Label label2;
        private Label label3;
        private ComboBox cmbMembers;
        private GroupBox groupBox1;
        private RadioButton rdbtnScience;
        private RadioButton rdbtnNovel;
        private RadioButton rdbtnHistory;
        private RadioButton rdbtnAllBooks;
        private GroupBox groupBox2;
        private RadioButton rdbtnNotReturned;
        private RadioButton rdbtnAllLoans;
    }
}