﻿using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applicationn.TeacherService
{
    public interface ITeacherService
    {
        public void Create(Teacher teacher);
        public void Delete(Teacher teacher);
        public Teacher Get(Guid id);
        public List<Teacher> GetAll();
        public void Update(Teacher teacher);
    }
}
