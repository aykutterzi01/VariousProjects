﻿using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.FoodService
{
    public interface IFoodService
    {
        public void Create(Food food);
        public void Delete(Food food);
        public Food Get(Guid id);
        public List<Food> GetAll();

        public void Update(Food food);
    }
}
