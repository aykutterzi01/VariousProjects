﻿using Entities.Entities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Entities;

public class Payroll : BaseEntity
{
    public Month Month { get; set; }

    public Guid PersonnelId { get; set; }
    public Personnel? Personnel { get; set; }

    public int WorkingHour { get; set; }

	public decimal Bonus
	{
		get 
		{
            if (Personnel is Manager manager)
            {
                return manager.HourlyFee * WorkingHour / 9;
            }
            else
            {
				return 0;
            }
        }

		set { }
	}

	private decimal overtimePay;

	public decimal OvertimePay
	{
		get 
		{ 
			if (Personnel is Employee employee)
			{

                if (WorkingHour <= 180)
                {
                    return 0;
                }
                else
                {
					return (WorkingHour - 180) * employee.HourlyFee;
				}
            }
			else if (Personnel is Manager manager)
			{
				return 0;
			}

			return overtimePay;		
		}

		set { }
	}

	private decimal salary;

	public decimal Salary
	{
		get 
		{ 
			if (Personnel is Employee employee)
			{
				if (WorkingHour <= 180)
				{
					return WorkingHour * employee.HourlyFee;
                }
				else
				{
					return 180 * employee.HourlyFee;
				}
			}
			else if(Personnel is Manager manager)
			{
				return WorkingHour * manager.HourlyFee;
			}

			return salary;
		}

		set { }
	}

	private decimal totalPay;

	public decimal TotalPay
	{
		get 
		{ 
			if (Personnel is Employee employee)
			{
				return Salary + OvertimePay;
			}
			else if (Personnel is Manager manager)
			{
				return Salary + Bonus;
			}
			return totalPay;
		}

		set { }
	}
}
