﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Model.Models
{
    public enum Size : byte
    {
        Small = 1,
        Medium = 2,
        Large = 3
    }
}
