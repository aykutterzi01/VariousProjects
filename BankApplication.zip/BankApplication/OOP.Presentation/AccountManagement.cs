﻿using OOP.Applicationn.AccountService;
using OOP.Applicationn.CustomerService;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Presentation
{
    public partial class AccountManagement : Form
    {
        CustomerService _customerService;
        AccountService _accountService;

        public AccountManagement(CustomerService customerService, AccountService accountService)
        {
            InitializeComponent();
            _customerService = customerService;
            _accountService = accountService;
        }

        private void AccountManagement_Load(object sender, EventArgs e)
        {
            dgw_Customer_List.DataSource = _customerService.GetAll();
            dgw_Customer_List.Columns["CommissionRatio"].Visible = false;
            dgw_Customer_List.Columns["Id"].Visible = false;
        }

        private void dgw_Customer_List_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Customer selectedCustomer = (Customer)dgw_Customer_List.SelectedRows[0].DataBoundItem;

            dgw_Account_List.DataSource = _accountService.GetAll().Where(x => x.Customer.Id == selectedCustomer.Id).ToList();
            dgw_Account_List.Columns["Balance"].DefaultCellStyle.Format = "N2";
            dgw_Account_List.Columns["Id"].Visible = false;
        }

        private void btn_Delete_Account_Click(object sender, EventArgs e)
        {
            Customer selectedCustomer = (Customer)dgw_Customer_List.SelectedRows[0].DataBoundItem;

            Account selectedAccount = (Account)dgw_Account_List.SelectedRows[0].DataBoundItem;

            Account deletedAccount = _accountService.GetAll().FirstOrDefault(x=>x.Id == selectedAccount.Id);

            _accountService.Delete(deletedAccount);

            MessageBox.Show("Account has been deleted.");

            dgw_Account_List.DataSource = null;

            dgw_Account_List.DataSource = _accountService.GetAll().Where(x => x.Customer.Id == selectedCustomer.Id).ToList();
            dgw_Account_List.Columns["Balance"].DefaultCellStyle.Format = "N2";
            dgw_Account_List.Columns["Id"].Visible = false;
        }
    }
}
