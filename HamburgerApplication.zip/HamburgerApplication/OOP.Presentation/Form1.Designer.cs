﻿namespace OOP.Presentation
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            orderManagementToolStripMenuItem = new ToolStripMenuItem();
            createOrderToolStripMenuItem = new ToolStripMenuItem();
            orderDetailsToolStripMenuItem = new ToolStripMenuItem();
            productManagementToolStripMenuItem = new ToolStripMenuItem();
            addFoodToolStripMenuItem = new ToolStripMenuItem();
            addExtraToolStripMenuItem = new ToolStripMenuItem();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { orderManagementToolStripMenuItem, productManagementToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 28);
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // orderManagementToolStripMenuItem
            // 
            orderManagementToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { createOrderToolStripMenuItem, orderDetailsToolStripMenuItem });
            orderManagementToolStripMenuItem.Name = "orderManagementToolStripMenuItem";
            orderManagementToolStripMenuItem.Size = new Size(153, 24);
            orderManagementToolStripMenuItem.Text = "Order Management";
            // 
            // createOrderToolStripMenuItem
            // 
            createOrderToolStripMenuItem.Name = "createOrderToolStripMenuItem";
            createOrderToolStripMenuItem.Size = new Size(224, 26);
            createOrderToolStripMenuItem.Text = "Create Order";
            createOrderToolStripMenuItem.Click += createOrderToolStripMenuItem_Click;
            // 
            // orderDetailsToolStripMenuItem
            // 
            orderDetailsToolStripMenuItem.Name = "orderDetailsToolStripMenuItem";
            orderDetailsToolStripMenuItem.Size = new Size(224, 26);
            orderDetailsToolStripMenuItem.Text = "Order Details";
            orderDetailsToolStripMenuItem.Click += orderDetailsToolStripMenuItem_Click;
            // 
            // productManagementToolStripMenuItem
            // 
            productManagementToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { addFoodToolStripMenuItem, addExtraToolStripMenuItem });
            productManagementToolStripMenuItem.Name = "productManagementToolStripMenuItem";
            productManagementToolStripMenuItem.Size = new Size(166, 24);
            productManagementToolStripMenuItem.Text = "Product Management";
            // 
            // addFoodToolStripMenuItem
            // 
            addFoodToolStripMenuItem.Name = "addFoodToolStripMenuItem";
            addFoodToolStripMenuItem.Size = new Size(158, 26);
            addFoodToolStripMenuItem.Text = "Add Food";
            addFoodToolStripMenuItem.Click += addFoodToolStripMenuItem_Click;
            // 
            // addExtraToolStripMenuItem
            // 
            addExtraToolStripMenuItem.Name = "addExtraToolStripMenuItem";
            addExtraToolStripMenuItem.Size = new Size(158, 26);
            addExtraToolStripMenuItem.Text = "Add Extra";
            addExtraToolStripMenuItem.Click += addExtraToolStripMenuItem_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(menuStrip1);
            IsMdiContainer = true;
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Form1";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem orderManagementToolStripMenuItem;
        private ToolStripMenuItem createOrderToolStripMenuItem;
        private ToolStripMenuItem orderDetailsToolStripMenuItem;
        private ToolStripMenuItem productManagementToolStripMenuItem;
        private ToolStripMenuItem addFoodToolStripMenuItem;
        private ToolStripMenuItem addExtraToolStripMenuItem;
    }
}
