﻿using Business.Services;
using LibraryAutomationSystem.Context;
using LibraryAutomationSystem.Entities;
using Presentation.Methods;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class RegisterForm : Form
    {
        AppUserService _appUserService;
        public RegisterForm(AppUserService appUserService)
        {
            InitializeComponent();
            _appUserService = appUserService;
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            AppUser user = new AppUser()
            {
                FirstName = txtRegisterName.Text,
                LastName = txtRegisterSurname.Text,
                UserName = txtRegisterUserName.Text,
                Password = Hash.HashPass(txtRegisterPassword.Text)
            };

            _appUserService.Create(user);
            MessageBox.Show("Registration has been done.");

            CleanTexts();
        }

        private void CleanTexts()
        {
            txtRegisterName.Text = string.Empty;
            txtRegisterSurname.Text = string.Empty;
            txtRegisterUserName.Text = string.Empty;
            txtRegisterPassword.Text = string.Empty;
        }
    }
}
