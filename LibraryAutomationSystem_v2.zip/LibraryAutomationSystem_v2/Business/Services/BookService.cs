﻿using LibraryAutomationSystem.Context;
using LibraryAutomationSystem.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services;

public class BookService
{
    private readonly AppDbContext dbContext;
    public BookService()
    {
        this.dbContext = new AppDbContext();
    }

    public void Create(Book book)
    {
        dbContext.Books.Add(book);
        dbContext.SaveChanges();
    }

    public void Delete(Book book)
    {
        dbContext.Books.Remove(book);
        dbContext.SaveChanges();
    }

    public void Update(Book book)
    {
        dbContext.Books.Update(book);
        dbContext.SaveChanges();
    }

    public List<Book> GetAll()
    {
        return dbContext.Books.ToList();
    }
}
