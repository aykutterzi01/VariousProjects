﻿using Infrastructure.DataService;
using Infrastructure.Interfaces;
using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applicationn.StudentTeacherCourseService
{
    public class StudentTeacherCourseService : IStudentTeacherCourseService
    {
        private readonly IStudentTeacherCourseDataService _studentTeacherCourseDataService;

        public StudentTeacherCourseService()
        {
            _studentTeacherCourseDataService = new StudentTeacherCourseDataService();
        }

        public void Create(StudentTeacherCourse studentCourse)
        {
            var studentTeacherCourses = _studentTeacherCourseDataService.GetData();
            studentTeacherCourses.Add(studentCourse);
            _studentTeacherCourseDataService.Save(studentTeacherCourses);
        }

        public void Delete(StudentTeacherCourse studentTeacherCourse)
        {
            var studentTeacherCourses = _studentTeacherCourseDataService.GetData();
            studentTeacherCourses.Remove(studentTeacherCourses.FirstOrDefault(x => x.Id == studentTeacherCourse.Id));
            _studentTeacherCourseDataService.Save(studentTeacherCourses);
        }

        public StudentTeacherCourse Get(Guid id)
        {
            var studentTeacherCourses = _studentTeacherCourseDataService.GetData();
            return studentTeacherCourses.FirstOrDefault(x => x.Id == id);
        }

        public List<StudentTeacherCourse> GetAll()
        {
            return _studentTeacherCourseDataService.GetData();
        }

        public void Update(StudentTeacherCourse studentTeacherCourse)
        {
            var studentTeacherCourses = _studentTeacherCourseDataService.GetData();
            var updatedStudentTeacherCourse = studentTeacherCourses.FirstOrDefault(x => x.Id == studentTeacherCourse.Id);
            var indexStudentTeacherCourse = studentTeacherCourses.IndexOf(updatedStudentTeacherCourse);
            studentTeacherCourses[indexStudentTeacherCourse] = studentTeacherCourse;
            _studentTeacherCourseDataService.Save(studentTeacherCourses);
        }
    }
}
