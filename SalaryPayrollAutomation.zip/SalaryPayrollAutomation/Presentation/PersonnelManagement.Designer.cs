﻿namespace Presentation
{
    partial class PersonnelManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            txtName = new TextBox();
            txtSurname = new TextBox();
            groupBox1 = new GroupBox();
            nudHourlyFee = new NumericUpDown();
            lblSalary = new Label();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            cmbRank = new ComboBox();
            lblRank = new Label();
            rdbtnManager = new RadioButton();
            rdbtnEmployee = new RadioButton();
            label3 = new Label();
            dgwPersonnel = new DataGridView();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudHourlyFee).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgwPersonnel).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label1.Location = new Point(46, 121);
            label1.Name = "label1";
            label1.Size = new Size(68, 28);
            label1.TabIndex = 0;
            label1.Text = "Name:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            label2.Location = new Point(21, 157);
            label2.Name = "label2";
            label2.Size = new Size(93, 28);
            label2.TabIndex = 1;
            label2.Text = "Surname:";
            // 
            // txtName
            // 
            txtName.Location = new Point(128, 121);
            txtName.Name = "txtName";
            txtName.Size = new Size(260, 34);
            txtName.TabIndex = 2;
            // 
            // txtSurname
            // 
            txtSurname.Location = new Point(128, 161);
            txtSurname.Name = "txtSurname";
            txtSurname.Size = new Size(260, 34);
            txtSurname.TabIndex = 3;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.ActiveCaption;
            groupBox1.Controls.Add(nudHourlyFee);
            groupBox1.Controls.Add(lblSalary);
            groupBox1.Controls.Add(btnDelete);
            groupBox1.Controls.Add(btnUpdate);
            groupBox1.Controls.Add(btnAdd);
            groupBox1.Controls.Add(cmbRank);
            groupBox1.Controls.Add(lblRank);
            groupBox1.Controls.Add(rdbtnManager);
            groupBox1.Controls.Add(rdbtnEmployee);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(txtSurname);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtName);
            groupBox1.Controls.Add(label2);
            groupBox1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(761, 212);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "PERSONNEL DETAILS";
            // 
            // nudHourlyFee
            // 
            nudHourlyFee.Location = new Point(526, 74);
            nudHourlyFee.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            nudHourlyFee.Name = "nudHourlyFee";
            nudHourlyFee.Size = new Size(214, 34);
            nudHourlyFee.TabIndex = 13;
            // 
            // lblSalary
            // 
            lblSalary.AutoSize = true;
            lblSalary.Location = new Point(412, 77);
            lblSalary.Name = "lblSalary";
            lblSalary.Size = new Size(115, 28);
            lblSalary.TabIndex = 12;
            lblSalary.Text = "Hourly Fee :";
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(646, 121);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 74);
            btnDelete.TabIndex = 11;
            btnDelete.Text = "DELETE";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(526, 121);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 74);
            btnUpdate.TabIndex = 10;
            btnUpdate.Text = "UPDATE";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(412, 121);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 74);
            btnAdd.TabIndex = 9;
            btnAdd.Text = "ADD";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            // 
            // cmbRank
            // 
            cmbRank.FormattingEnabled = true;
            cmbRank.Location = new Point(128, 77);
            cmbRank.Name = "cmbRank";
            cmbRank.Size = new Size(260, 36);
            cmbRank.TabIndex = 8;
            // 
            // lblRank
            // 
            lblRank.AutoSize = true;
            lblRank.Location = new Point(55, 80);
            lblRank.Name = "lblRank";
            lblRank.Size = new Size(59, 28);
            lblRank.TabIndex = 7;
            lblRank.Text = "Rank:";
            // 
            // rdbtnManager
            // 
            rdbtnManager.AutoSize = true;
            rdbtnManager.Location = new Point(269, 39);
            rdbtnManager.Name = "rdbtnManager";
            rdbtnManager.Size = new Size(111, 32);
            rdbtnManager.TabIndex = 6;
            rdbtnManager.TabStop = true;
            rdbtnManager.Text = "Manager";
            rdbtnManager.UseVisualStyleBackColor = true;
            rdbtnManager.CheckedChanged += rdbtnManager_CheckedChanged;
            // 
            // rdbtnEmployee
            // 
            rdbtnEmployee.AutoSize = true;
            rdbtnEmployee.Location = new Point(128, 39);
            rdbtnEmployee.Name = "rdbtnEmployee";
            rdbtnEmployee.Size = new Size(119, 32);
            rdbtnEmployee.TabIndex = 5;
            rdbtnEmployee.TabStop = true;
            rdbtnEmployee.Text = "Employee";
            rdbtnEmployee.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(59, 39);
            label3.Name = "label3";
            label3.Size = new Size(57, 28);
            label3.TabIndex = 4;
            label3.Text = "Type:";
            // 
            // dgwPersonnel
            // 
            dgwPersonnel.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwPersonnel.Location = new Point(12, 230);
            dgwPersonnel.MultiSelect = false;
            dgwPersonnel.Name = "dgwPersonnel";
            dgwPersonnel.ReadOnly = true;
            dgwPersonnel.RowHeadersWidth = 51;
            dgwPersonnel.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwPersonnel.Size = new Size(761, 236);
            dgwPersonnel.TabIndex = 5;
            dgwPersonnel.RowHeaderMouseClick += dgwPersonnel_RowHeaderMouseClick;
            // 
            // PersonnelManagement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(785, 478);
            Controls.Add(dgwPersonnel);
            Controls.Add(groupBox1);
            Name = "PersonnelManagement";
            Text = "Personnel";
            Load += PersonnelManagement_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudHourlyFee).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgwPersonnel).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox txtName;
        private TextBox txtSurname;
        private GroupBox groupBox1;
        private RadioButton rdbtnManager;
        private RadioButton rdbtnEmployee;
        private Label label3;
        private Button btnAdd;
        private Button btnDelete;
        private Button btnUpdate;
        private DataGridView dgwPersonnel;
        private Label lblSalary;
        private NumericUpDown nudHourlyFee;
        private Label lblRank;
        private ComboBox cmbRank;
    }
}