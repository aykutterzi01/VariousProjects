﻿using OOP.Applicationn.AccountService;
using OOP.Applicationn.CustomerService;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Presentation
{
    public partial class CustomerManagement : Form
    {
        CustomerService _customerService;
        AccountService _accountService;
        public CustomerManagement(CustomerService customerService, AccountService accountService)
        {
            InitializeComponent();
            _customerService = customerService;
            _accountService = accountService;
        }

        private void CustomerManagement_Load(object sender, EventArgs e)
        {
            dgw_Customer_List.DataSource = _customerService.GetAll();
            dgw_Customer_List.Columns["CommissionRatio"].Visible = false;
            dgw_Customer_List.Columns["Id"].Visible = false;
        }

        private void dgw_Customer_List_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Customer selectedCustomer = (Customer)dgw_Customer_List.SelectedRows[0].DataBoundItem;

            if (selectedCustomer.CustomerType == Model.Models.Enums.CustomerType.Standard)
            {
                rdbtn_Standard.Checked = true;
                txt_Name.Text = selectedCustomer.Name;
                txt_Surname.Text = selectedCustomer.Surname;
                txt_Email.Text = selectedCustomer.Email;
                txt_City.Text = selectedCustomer.City;
            }
            else
            {
                rdbtn_Student.Checked = true;
                txt_Name.Text = selectedCustomer.Name;
                txt_Name.Text = selectedCustomer.Name;
                txt_Surname.Text = selectedCustomer.Surname;
                txt_Email.Text = selectedCustomer.Email;
                txt_City.Text = selectedCustomer.City;
                txt_University.Text = selectedCustomer.University;
            }
        }

        private void rdtbn_Standard_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Standard.Checked == true)
            {
                lbl_University.Visible = false;
                txt_University.Visible = false;
            }
            else
            {
                lbl_University.Visible = true;
                txt_University.Visible = true;
            }
        }

        private void btn_Update_Customer_Click(object sender, EventArgs e)
        {
            Customer selectedCustomer = (Customer)dgw_Customer_List.SelectedRows[0].DataBoundItem;

            if (rdbtn_Standard.Checked == true)
            {
                if(!CheckFieldsStandard()) return;
                selectedCustomer.CustomerType = Model.Models.Enums.CustomerType.Standard;
                selectedCustomer.Name = txt_Name.Text;
                selectedCustomer.Surname = txt_Surname.Text;
                selectedCustomer.Email = txt_Email.Text;
                selectedCustomer.City = txt_City.Text;
            }
            else
            {
                if (!CheckFieldsStudent()) return;
                selectedCustomer.CustomerType = Model.Models.Enums.CustomerType.Student;
                selectedCustomer.Name = txt_Name.Text;
                selectedCustomer.Surname = txt_Surname.Text;
                selectedCustomer.Email = txt_Email.Text;
                selectedCustomer.City = txt_City.Text;
                selectedCustomer.University = txt_University.Text;
            }

            _customerService.Update(selectedCustomer);
            var accountList = _accountService.GetAll().Where(x => x.Customer.Id == selectedCustomer.Id).ToList();

            foreach (var account in accountList)
            {
                account.Customer = selectedCustomer;
                _accountService.Update(account);
            }

            UpdateCustomers();
            CleanTexts();

            MessageBox.Show("Customer has been updated.");
        }

        private bool CheckFieldsStudent()
        {
            if (txt_Name.Text == "" || txt_Surname.Text == "" || txt_Email.Text == "" || txt_City.Text == "" || txt_University.Text == "")
            {
                MessageBox.Show("Please fill out all the fields.");
                return false;
            }
            return true;
        }

        private bool CheckFieldsStandard()
        {
            if (txt_Name.Text == "" || txt_Surname.Text == "" || txt_Email.Text == "" || txt_City.Text == "")
            {
                MessageBox.Show("Please fill out all the fields.");
                return false;
            }
            return true;
        }

        private void CleanTexts()
        {
            txt_Name.Text = "";
            txt_Surname.Text = "";
            txt_Email.Text = "";
            txt_City.Text = "";
            txt_University.Text = "";
        }

        private void UpdateCustomers()
        {
            dgw_Customer_List.DataSource = null;
            dgw_Customer_List.DataSource = _customerService.GetAll();
            dgw_Customer_List.Columns["CommissionRatio"].Visible = false;
            dgw_Customer_List.Columns["Id"].Visible = false;
        }

        private void btn_Delete_Customer_Click(object sender, EventArgs e)
        {
            Customer selectedCustomer = (Customer)dgw_Customer_List.SelectedRows[0].DataBoundItem;

            Customer deletedCustomer = _customerService.GetAll().FirstOrDefault(x=> x.Id == selectedCustomer.Id);

            _customerService.Delete(deletedCustomer);

            var customers = _customerService.GetAll().ToList();

            UpdateCustomers();
            CleanTexts();

            MessageBox.Show("Customer has been deleted!");
        }
    }
}
