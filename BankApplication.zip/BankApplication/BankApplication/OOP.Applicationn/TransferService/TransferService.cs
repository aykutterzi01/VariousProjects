﻿using OOP.Infrastructure.DataService;
using OOP.Infrastructure.Interfaces;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.TransferService
{
    public class TransferService : ITransferService
    {
        private readonly ITransferDataService _transferDataService;

        public TransferService()
        {
            _transferDataService = new TransferDataService();
        }
        public void Create(Transfer transfer)
        {
            var transfers = _transferDataService.GetData();
            transfers.Add(transfer);
            _transferDataService.Save(transfers);
        }

        public void Delete(Transfer transfer)
        {
            var transfers = _transferDataService.GetData();
            transfers.Remove(transfer);
            _transferDataService.Save(transfers);
        }

        public Transfer Get(Guid id)
        {
            var transfers = _transferDataService.GetData();
            return transfers.FirstOrDefault(x => x.Id == id);
        }

        public List<Transfer> GetAll()
        {
            return _transferDataService.GetData();
        }

        public void Update(Transfer transfer)
        {
            var transfers = _transferDataService.GetData();
            var updating = transfers.FirstOrDefault(x =>x.Id == transfer.Id);
            var indexTransfer = transfers.IndexOf(updating);
            transfers[indexTransfer] = transfer;
        }
    }
}
