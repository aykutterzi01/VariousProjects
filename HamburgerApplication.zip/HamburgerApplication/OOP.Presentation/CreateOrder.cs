﻿using OOP.Applicationn.EkstraService;
using OOP.Applicationn.FoodService;
using OOP.Applicationn.OrderService;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Presentation
{
    public partial class CreateOrder : Form
    {
        FoodService _foodService;
        EkstraService _ekstraService;
        OrderService _orderService;
        List<Order> _orders;

        public CreateOrder(FoodService foodService, EkstraService ekstraService, OrderService orderService, List<Order> orders)
        {
            InitializeComponent();
            _foodService = foodService;
            _ekstraService = ekstraService;
            _orderService = orderService;
            _orders = orders;
        }

        private void CreateOrder_Load(object sender, EventArgs e)
        {
            dgw_Food.DataSource = _foodService.GetAll();
            dgw_Food.Columns["Id"].Visible = false;

            dgw_Extra.DataSource = _ekstraService.GetAll();
            dgw_Extra.Columns["Id"].Visible = false;

            rdbtn_Small.Checked = true;
            rdbtn_Credit_Card.Checked = true;
        }

        private void btn_Add_Order_Click(object sender, EventArgs e)
        {
            if (nmrcud_Amount.Value == 0)
            {
                MessageBox.Show("Please make a choice different from zero!");
            }
            else
            {
                Order order = new Order();

                DataGridViewRow selectedRow = dgw_Food.SelectedRows[0];
                Food food = (Food)selectedRow.DataBoundItem;

                order.Food = food;

                foreach (DataGridViewRow item in dgw_Extra.SelectedRows)
                {
                    Ekstra ekstra = (Ekstra)item.DataBoundItem;
                    order.Ekstras.Add(ekstra);
                }

                order.Size = rdbtn_Small.Checked ? Model.Models.Size.Small : rdbtn_Medium.Checked ? Model.Models.Size.Medium : Model.Models.Size.Large;

                order.Amount = (int)nmrcud_Amount.Value;

                order.Extras = string.Join(", ", order.Ekstras.Select(x => x.Name));

                order.PaymentType = rdbtn_Cash.Checked ? PaymentType.Cash : PaymentType.CreditCard;

                _orders.Add(order);

                DisplayView();

                CalculateTotalAmount();

            }
        }

        private void CalculateTotalAmount()
        {
            decimal totalAmount = 0;

            foreach (Order order in _orders)
            {
                totalAmount += (order.Food.Price * (order.Size == Model.Models.Size.Small ? 1 : order.Size == Model.Models.Size.Medium ? 1.25m : 1.5m) + order.Ekstras.Sum(x => x.Price)) * order.Amount;
            }

            lbl_TotalPrice.Text = $"{totalAmount} TL";
        }

        private void DisplayView()
        {
            dgw_Orders.DataSource = null;
            dgw_Orders.DataSource = _orders;
            dgw_Orders.Columns["Id"].Visible = false;
            dgw_Orders.Columns["DateTime"].Visible = false;
        }

        private void btn_Finish_Order_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show($"Total Order Price: {lbl_TotalPrice.Text}. \nWould you like to finish the order?", "Order Information", MessageBoxButtons.YesNo);

            if (dialogResult == DialogResult.Yes)
            {
                foreach (Order order in _orders)
                {
                    order.DateTime = DateTime.Now;
                    _orderService.Create(order);
                }

                _orders.Clear();

                lbl_TotalPrice.Text = "0" + "TL";
                DisplayView();
            }
            else
            {
                MessageBox.Show("Cancelled!");
                _orders.Clear();
                lbl_TotalPrice.Text = "0" + "TL";
                DisplayView();
            }
        }
    }
}
