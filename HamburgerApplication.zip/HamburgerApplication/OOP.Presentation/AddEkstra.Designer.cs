﻿namespace OOP.Presentation
{
    partial class AddEkstra
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            btn_Save_Extra = new Button();
            nmrcud_Extra_Price = new NumericUpDown();
            label2 = new Label();
            txt_Extra_Name = new TextBox();
            label1 = new Label();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nmrcud_Extra_Price).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btn_Save_Extra);
            groupBox1.Controls.Add(nmrcud_Extra_Price);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(txt_Extra_Name);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(12, 28);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(372, 193);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "EXTRA INFORMATION";
            // 
            // btn_Save_Extra
            // 
            btn_Save_Extra.Location = new Point(12, 118);
            btn_Save_Extra.Name = "btn_Save_Extra";
            btn_Save_Extra.Size = new Size(341, 58);
            btn_Save_Extra.TabIndex = 4;
            btn_Save_Extra.Text = "SAVE EXTRA";
            btn_Save_Extra.UseVisualStyleBackColor = true;
            btn_Save_Extra.Click += btn_Save_Extra_Click;
            // 
            // nmrcud_Extra_Price
            // 
            nmrcud_Extra_Price.Location = new Point(119, 79);
            nmrcud_Extra_Price.Name = "nmrcud_Extra_Price";
            nmrcud_Extra_Price.Size = new Size(234, 27);
            nmrcud_Extra_Price.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(56, 80);
            label2.Name = "label2";
            label2.Size = new Size(47, 20);
            label2.TabIndex = 2;
            label2.Text = "Price:";
            // 
            // txt_Extra_Name
            // 
            txt_Extra_Name.Location = new Point(118, 37);
            txt_Extra_Name.Name = "txt_Extra_Name";
            txt_Extra_Name.Size = new Size(235, 27);
            txt_Extra_Name.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(9, 38);
            label1.Name = "label1";
            label1.Size = new Size(95, 20);
            label1.TabIndex = 0;
            label1.Text = "Extra Name:";
            // 
            // AddEkstra
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Name = "AddEkstra";
            Text = "AddEkstra";
            WindowState = FormWindowState.Maximized;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nmrcud_Extra_Price).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button btn_Save_Extra;
        private NumericUpDown nmrcud_Extra_Price;
        private Label label2;
        private TextBox txt_Extra_Name;
        private Label label1;
    }
}