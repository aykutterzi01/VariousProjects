﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Presentation.VMs
{
    public class TeacherCourseListVM
    {
        public Guid Id { get; set; }
        public string CourseWithTeacher {  get; set; }
    }
}
