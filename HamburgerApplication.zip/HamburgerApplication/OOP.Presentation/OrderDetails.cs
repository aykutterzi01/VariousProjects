﻿using OOP.Applicationn.OrderService;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Presentation
{
    public partial class OrderDetails : Form
    {
        OrderService _orderService;

        public OrderDetails(OrderService orderService)
        {
            InitializeComponent();
            _orderService = orderService;
        }

        private void OrderDetails_Load(object sender, EventArgs e)
        {
            dgw_All_Orders.DataSource = _orderService.GetAll();
            dgw_All_Orders.Columns["Id"].Visible = false;

            decimal turnover = 0;
            int totalAmount = 0;
            decimal totalRevenueOfExtras = 0;
            decimal revenueWithCash = 0;

            foreach (Order order in _orderService.GetAll())
            {
                turnover += CalculateOrderPrice(order);

                totalAmount += order.Amount;

                totalRevenueOfExtras += order.Ekstras.Sum(x => x.Price);

                if (order.PaymentType == PaymentType.Cash)
                {
                    revenueWithCash += CalculateOrderPrice(order);
                }
            }

            lbl_Turnover.Text = turnover.ToString() + " TL";
            lbl_Total_Amount_Of_Orders.Text = _orderService.GetAll().Count().ToString();
            lbl_Revenue_Of_Extras.Text = totalRevenueOfExtras.ToString();
            lbl_Amount_Of_Products_Sold.Text = totalAmount.ToString();
            lbl_Revenue_Cash.Text = revenueWithCash.ToString() + " TL";
            lbl_Revenue_Credit_Card.Text = (turnover - revenueWithCash).ToString() + " TL";

            lbl_Products_Sold.Text = "";
        }

        private decimal CalculateOrderPrice(Order order)
        {
            return (order.Food.Price * (order.Size == Model.Models.Size.Small ? 1 : order.Size == Model.Models.Size.Medium ? 1.25m : 1.5m) + order.Ekstras.Sum(x => x.Price)) * order.Amount;
        }

        private void dtp_End_ValueChanged(object sender, EventArgs e)
        {
            ShowWithDates();
        }

        private void ShowWithDates()
        {
            if (dtp_End.Value.Date < dtp_Start.Value.Date)
            {
                MessageBox.Show("The end date can not be earlier than start date.");
            }
            else
            {
                lbl_Products_Sold.Text = _orderService.GetAll().Where(x => x.DateTime.Date >= dtp_Start.Value.Date && x.DateTime.Date <= dtp_End.Value.Date).Sum(x => x.Amount).ToString();
            }
        }

        private void dtp_Start_ValueChanged(object sender, EventArgs e)
        {
            ShowWithDates();
        }
    }
}
