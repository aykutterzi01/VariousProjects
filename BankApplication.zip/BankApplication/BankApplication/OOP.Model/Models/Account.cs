﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Model.Models
{
    public class Account : BaseModel
    {
        public Account(Customer customer, AccountType accountType)
        {
            Customer = customer;
            AccountType = accountType;
        }

        public decimal Balance { get; set; }
        public Customer Customer { get; set; }
        public AccountType AccountType { get; set;}
    }
}
