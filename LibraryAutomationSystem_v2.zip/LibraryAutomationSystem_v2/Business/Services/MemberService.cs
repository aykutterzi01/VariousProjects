﻿using LibraryAutomationSystem.Context;
using LibraryAutomationSystem.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services;

public class MemberService
{
    private readonly AppDbContext dbContext;
    public MemberService()
    {
        this.dbContext = new AppDbContext();
    }

    public void Create(Member member)
    {
        dbContext.Members.Add(member);
        dbContext.SaveChanges();
    }

    public void Delete(Member member)
    {
        dbContext.Members.Remove(member);
        dbContext.SaveChanges();
    }

    public void Update(Member member)
    {
        dbContext.Members.Update(member);
        dbContext.SaveChanges();
    }

    public List<Member> GetAll()
    {
        return dbContext.Members.ToList();
    }
}
