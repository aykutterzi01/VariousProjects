﻿using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applicationn.StudentTeacherCourseService
{
    public interface IStudentTeacherCourseService
    {
        public void Create(StudentTeacherCourse studentTeacherCourse);
        public void Delete(StudentTeacherCourse studentTeacherCourse);
        public StudentTeacherCourse Get(Guid id);
        public List<StudentTeacherCourse> GetAll();
        public void Update(StudentTeacherCourse studentTeacherCourse);
    }
}
