﻿using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.StudentCustomerService
{
    public interface IStudentCustomerService
    {
        public void Create(StudentCustomer studentCustomer);
        public void Delete(StudentCustomer studentCustomer);
        public StudentCustomer Get(Guid id);
        public List<StudentCustomer> GetAll();
        public void Update(StudentCustomer studentCustomer);
    }
}
