﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Model.Models.Enums
{
    public enum TransferType
    {
        Deposit = 1,
        Withdrawal = 2,
        Remission = 3,
        Receival = 4
    }
}
