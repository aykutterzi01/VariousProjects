﻿using OOP.Infrastructure.DataService;
using OOP.Infrastructure.Interfaces;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.CustomerService
{
    public class CustomerService : ICustomerService
    {
        private readonly ICustomerDataService _customerDataService;
        public CustomerService()
        {
            _customerDataService = new CustomerDataService();
        }
        public void Create(Customer customer)
        {
            var customers = _customerDataService.GetData();
            customers.Add(customer);
            _customerDataService.Save(customers);
        }

        public void Delete(Customer customer)
        {
            var customers = _customerDataService.GetData();
            customers.Remove(customers.FirstOrDefault(x=>x.Id == customer.Id));
            _customerDataService.Save(customers);
        }

        public Customer Get(Guid id)
        {
            var customers = _customerDataService.GetData();
            return customers.FirstOrDefault(x => x.Id == id);
        }

        public List<Customer> GetAll()
        {
            return _customerDataService.GetData();
        }

        public void Update(Customer customer)
        {
            var customers = _customerDataService.GetData();
            var updating = customers.FirstOrDefault(x =>x.Id == customer.Id);
            var indexCustomer = customers.IndexOf(updating);
            customers[indexCustomer] = customer;
            _customerDataService.Save(customers);
        }
    }
}
