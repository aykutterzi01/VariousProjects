﻿using Entities.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Context;

public class AppDbContext : DbContext
{

    public DbSet<Personnel> Personnels { get; set; }
    public DbSet<Manager> Managers { get; set; }
    public DbSet<Employee> Employees { get; set; }
    public DbSet<Payroll> Payrolls { get; set; }

    
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseSqlServer("Server=LAPTOP-1RUKRP01\\SQLEXPRESS;Initial Catalog=HS14SalaryPayroll;Trusted_Connection=True;TrustServerCertificate=True");
        base.OnConfiguring(optionsBuilder);
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Employee>().HasBaseType<Personnel>();
        modelBuilder.Entity<Manager>().HasBaseType<Personnel>();

        modelBuilder.Entity<Personnel>().Property(p => p.HourlyFee).HasColumnType("decimal(18,2)");

        modelBuilder.Entity<Payroll>()
            .HasOne(p => p.Personnel)
            .WithMany(p => p.Payrolls)
            .HasForeignKey(p => p.PersonnelId);

        base.OnModelCreating(modelBuilder);
    }
}
