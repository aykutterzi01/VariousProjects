﻿using OOP.Applicationn.EkstraService;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Presentation
{
    public partial class AddEkstra : Form
    {
        EkstraService _ekstraService;
        public AddEkstra(EkstraService ekstraService)
        {
            InitializeComponent();
            _ekstraService = ekstraService;
        }

        private void btn_Save_Extra_Click(object sender, EventArgs e)
        {
            if (nmrcud_Extra_Price.Value != 0)
            {
                Ekstra ekstra = new Ekstra();
                ekstra.Name = txt_Extra_Name.Text;
                ekstra.Price = nmrcud_Extra_Price.Value;
                _ekstraService.Create(ekstra);

                MessageBox.Show("Extra has been added.");
            }
            else
            {
                MessageBox.Show("The price can not be zero!");
            }
        }
    }
}
