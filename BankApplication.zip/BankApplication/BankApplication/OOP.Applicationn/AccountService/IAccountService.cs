﻿using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.AccountService
{
    public interface IAccountService
    {
        public void Create(Account account);
        public void Delete(Account account);
        public Account Get(Guid id);
        public List<Account> GetAll();
        public void Update(Account account);  
    }
}
