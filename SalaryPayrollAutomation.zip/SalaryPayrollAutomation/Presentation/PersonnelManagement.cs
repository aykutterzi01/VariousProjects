﻿using Business.Services;
using Entities.Entities;
using Entities.Entities.Enums;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class PersonnelManagement : Form
    {
        PersonnelService _personnelService;

        public PersonnelManagement(PersonnelService personnelService)
        {
            InitializeComponent();
            _personnelService = personnelService;
        }

        private void PersonnelManagement_Load(object sender, EventArgs e)
        {
            rdbtnEmployee.Checked = true;
            lblSalary.Visible = false;
            nudHourlyFee.Visible = false;
            cmbRank.DataSource = Enum.GetValues(typeof(EmployeeRank));

            ResetTable();
        }

        private void ResetTable()
        {
            dgwPersonnel.DataSource = null;

            var personnels = _personnelService.GetAll().Select(x => new
            {
                x.Id,
                x.Name,
                x.Surname,
                x.Discriminator,
                Rank = (x.Discriminator == "Employee") ? ((Employee)x).Rank : Entities.Entities.Enums.EmployeeRank.NotApplicable,
                x.HourlyFee
            }).ToList();

            dgwPersonnel.DataSource = personnels;
            dgwPersonnel.Columns["Id"].Visible = false;
        }

        private void rdbtnManager_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtnManager.Checked == true)
            {
                lblRank.Visible = false;
                cmbRank.Visible = false;
                lblSalary.Visible = true;
                nudHourlyFee.Visible = true;
            }
            else
            {
                lblRank.Visible = true;
                cmbRank.Visible = true;
                lblSalary.Visible = false;
                nudHourlyFee.Visible = false;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (rdbtnEmployee.Checked == true)
            {
                Employee employee = new Employee()
                {
                    Name = txtName.Text,
                    Surname = txtSurname.Text
                };

                if ((EmployeeRank)cmbRank.SelectedItem == EmployeeRank.Junior)
                {
                    employee.Rank = EmployeeRank.Junior;
                }
                else if ((EmployeeRank)cmbRank.SelectedItem == EmployeeRank.Mid)
                {
                    employee.Rank = EmployeeRank.Mid;
                }
                else if ((EmployeeRank)cmbRank.SelectedItem == EmployeeRank.Senior)
                {
                    employee.Rank = EmployeeRank.Senior;
                }
                else
                {
                    MessageBox.Show("Employee can not have the 'Not Applicable' rank.");
                    return;
                }

                _personnelService.Create(employee);
            }
            else if (rdbtnManager.Checked == true)
            {
                Manager manager = new Manager()
                {
                    Name = txtName.Text,
                    Surname = txtSurname.Text,
                };

                if (nudHourlyFee.Value >= 500)
                {
                    manager.HourlyFee = nudHourlyFee.Value;
                }
                else
                {
                    MessageBox.Show("The manager hourly fee can not be less than 500");
                }

                _personnelService.Create(manager);
            }

            MessageBox.Show("The personnel has been added.");

            ResetTable();
            CleanTexts();
        }

        private void CleanTexts()
        {
            rdbtnEmployee.Checked = true;
            txtName.Text = string.Empty;
            txtSurname.Text = string.Empty;
            cmbRank.SelectedIndex = 0;
            nudHourlyFee.Value = 0;
        }

        private void dgwPersonnel_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            var personnelId = (Guid)(dgwPersonnel.SelectedRows[0].Cells["Id"]).Value;
            var personnel = _personnelService.GetAll().FirstOrDefault(x => x.Id == personnelId);

            txtName.Text = personnel.Name;
            txtSurname.Text = personnel.Surname;

            if (personnel is Employee employee)
            {
                rdbtnEmployee.Checked = true;
                cmbRank.SelectedItem = employee.Rank;
            }
            else if (personnel is Manager manager)
            {
                rdbtnManager.Checked = true;
                cmbRank.SelectedItem = EmployeeRank.NotApplicable;
                nudHourlyFee.Value = manager.HourlyFee;
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            var personnelId = (Guid)(dgwPersonnel.SelectedRows[0].Cells["Id"]).Value;
            var personnel = _personnelService.GetAll().FirstOrDefault(x => x.Id == personnelId);

            personnel.Name = txtName.Text;
            personnel.Surname = txtSurname.Text;

            if (personnel is Employee employee)
            {
                employee.Rank = (EmployeeRank)cmbRank.SelectedItem;
            }
            else if (personnel is Manager manager)
            {
                manager.HourlyFee = nudHourlyFee.Value;
            }

            _personnelService.Update(personnel);

            MessageBox.Show("The personnel has been updated.");

            ResetTable();
            CleanTexts();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            var personnelId = (Guid)(dgwPersonnel.SelectedRows[0].Cells["Id"]).Value;
            var personnel = _personnelService.GetAll().FirstOrDefault(x => x.Id == personnelId);

            _personnelService.Delete(personnel);

            MessageBox.Show("The personnel has been deleted.");

            ResetTable();
            CleanTexts();
        }
    }
}
