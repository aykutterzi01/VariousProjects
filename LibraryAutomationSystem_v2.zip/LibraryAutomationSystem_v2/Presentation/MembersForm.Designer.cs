﻿namespace Presentation
{
    partial class MembersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            btnUpdateMember = new Button();
            btnDeleteMember = new Button();
            btnAddMember = new Button();
            txtMemberNumber = new TextBox();
            txtMemberEmail = new TextBox();
            txtMemberSurname = new TextBox();
            txtMemberName = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            dgwMembers = new DataGridView();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgwMembers).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btnUpdateMember);
            groupBox1.Controls.Add(btnDeleteMember);
            groupBox1.Controls.Add(btnAddMember);
            groupBox1.Controls.Add(txtMemberNumber);
            groupBox1.Controls.Add(txtMemberEmail);
            groupBox1.Controls.Add(txtMemberSurname);
            groupBox1.Controls.Add(txtMemberName);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.ForeColor = Color.White;
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(776, 214);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Member Details";
            // 
            // btnUpdateMember
            // 
            btnUpdateMember.ForeColor = Color.FromArgb(192, 64, 0);
            btnUpdateMember.Location = new Point(561, 91);
            btnUpdateMember.Name = "btnUpdateMember";
            btnUpdateMember.Size = new Size(177, 47);
            btnUpdateMember.TabIndex = 10;
            btnUpdateMember.Text = "UPDATE";
            btnUpdateMember.UseVisualStyleBackColor = true;
            btnUpdateMember.Click += btnUpdateMember_Click;
            // 
            // btnDeleteMember
            // 
            btnDeleteMember.ForeColor = Color.FromArgb(192, 64, 0);
            btnDeleteMember.Location = new Point(561, 144);
            btnDeleteMember.Name = "btnDeleteMember";
            btnDeleteMember.Size = new Size(177, 47);
            btnDeleteMember.TabIndex = 9;
            btnDeleteMember.Text = "DELETE";
            btnDeleteMember.UseVisualStyleBackColor = true;
            btnDeleteMember.Click += btnDeleteMember_Click;
            // 
            // btnAddMember
            // 
            btnAddMember.ForeColor = Color.FromArgb(192, 64, 0);
            btnAddMember.Location = new Point(561, 38);
            btnAddMember.Name = "btnAddMember";
            btnAddMember.Size = new Size(177, 47);
            btnAddMember.TabIndex = 8;
            btnAddMember.Text = "ADD";
            btnAddMember.UseVisualStyleBackColor = true;
            btnAddMember.Click += btnAddMember_Click;
            // 
            // txtMemberNumber
            // 
            txtMemberNumber.Location = new Point(214, 162);
            txtMemberNumber.Name = "txtMemberNumber";
            txtMemberNumber.Size = new Size(302, 30);
            txtMemberNumber.TabIndex = 7;
            // 
            // txtMemberEmail
            // 
            txtMemberEmail.Location = new Point(214, 118);
            txtMemberEmail.Name = "txtMemberEmail";
            txtMemberEmail.Size = new Size(302, 30);
            txtMemberEmail.TabIndex = 6;
            // 
            // txtMemberSurname
            // 
            txtMemberSurname.Location = new Point(214, 78);
            txtMemberSurname.Name = "txtMemberSurname";
            txtMemberSurname.Size = new Size(302, 30);
            txtMemberSurname.TabIndex = 5;
            // 
            // txtMemberName
            // 
            txtMemberName.Location = new Point(214, 38);
            txtMemberName.Name = "txtMemberName";
            txtMemberName.Size = new Size(302, 30);
            txtMemberName.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(44, 165);
            label4.Name = "label4";
            label4.Size = new Size(155, 23);
            label4.TabIndex = 3;
            label4.Text = "Member Number:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(140, 125);
            label3.Name = "label3";
            label3.Size = new Size(59, 23);
            label3.TabIndex = 2;
            label3.Text = "Email:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(113, 78);
            label2.Name = "label2";
            label2.Size = new Size(86, 23);
            label2.TabIndex = 1;
            label2.Text = "Surname:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(137, 38);
            label1.Name = "label1";
            label1.Size = new Size(62, 23);
            label1.TabIndex = 0;
            label1.Text = "Name:";
            // 
            // dgwMembers
            // 
            dgwMembers.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwMembers.Location = new Point(12, 244);
            dgwMembers.MultiSelect = false;
            dgwMembers.Name = "dgwMembers";
            dgwMembers.ReadOnly = true;
            dgwMembers.RowHeadersWidth = 51;
            dgwMembers.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwMembers.Size = new Size(776, 188);
            dgwMembers.TabIndex = 2;
            dgwMembers.RowHeaderMouseClick += dgwMembers_RowHeaderMouseClick;
            // 
            // ManageMembersForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 64, 0);
            ClientSize = new Size(800, 450);
            Controls.Add(dgwMembers);
            Controls.Add(groupBox1);
            Name = "ManageMembersForm";
            Text = "ManageMembersForm";
            Load += ManageMembersForm_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgwMembers).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button btnAddMember;
        private TextBox txtMemberNumber;
        private TextBox txtMemberEmail;
        private TextBox txtMemberSurname;
        private TextBox txtMemberName;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private DataGridView dgwMembers;
        private Button btnUpdateMember;
        private Button btnDeleteMember;
    }
}