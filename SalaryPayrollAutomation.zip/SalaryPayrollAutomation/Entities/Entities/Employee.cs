﻿using Entities.Entities.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entities.Entities;

public class Employee : Personnel
{
    public EmployeeRank Rank { get; set; }

    public override decimal HourlyFee 
	{
        get
        {
            if (Rank == EmployeeRank.Junior)
            {
                return 500;
            }
            else if (Rank == EmployeeRank.Mid)
            {
                return 750;
            }
            else if (Rank == EmployeeRank.Senior)
            {
                return 1000;
            }
            else
            {
                throw new InvalidOperationException("Invalid employee rank.");
            }
        }

        set { }
    }
}
