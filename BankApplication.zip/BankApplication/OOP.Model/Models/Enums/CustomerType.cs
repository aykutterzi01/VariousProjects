﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Model.Models.Enums
{
    public enum CustomerType
    {
        Standard = 1,
        Student = 2
    }
}
