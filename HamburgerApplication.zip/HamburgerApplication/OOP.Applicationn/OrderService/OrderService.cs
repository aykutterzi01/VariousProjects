﻿using OOP.Infrastructure.DataService;
using OOP.Infrastructure.Interfaces;
using OOP.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Applicationn.OrderService
{
    public class OrderService : IOrderService
    {
        private readonly IOrderDataService _orderDataService;

        public OrderService()
        {
            _orderDataService = new OrderDataService();
        }

        public void Create(Order order)
        {
            var orders = _orderDataService.GetData();
            orders.Add(order);
            _orderDataService.Save(orders);
        }

        public void Delete(Order order)
        {
            var orders = _orderDataService.GetData();
            orders.Remove(order);
            _orderDataService.Save(orders);
        }

        public Order Get(Guid id)
        {
            var orders = _orderDataService.GetData();
            return orders.FirstOrDefault(x => x.Id == id);
        }

        public List<Order> GetAll()
        {
            return _orderDataService.GetData();
        }

        public void Update(Order order)
        {
            var orders = _orderDataService.GetData();
            var updating = orders.FirstOrDefault(x => x.Id ==  order.Id);
            var indexOrder = orders.IndexOf(updating);
            orders[indexOrder] = order;
        }
    }
}
