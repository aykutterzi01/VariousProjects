﻿namespace Presentation
{
    partial class TeacherManagement
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            groupBox1 = new GroupBox();
            lblAssigmentId = new Label();
            lbCourses = new ListBox();
            btnTeacherUpdate = new Button();
            btnTeacherAdd = new Button();
            txtTeacherEmail = new TextBox();
            txtTeacherSurnam = new TextBox();
            txtTeacherName = new TextBox();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            dgwAssignments = new DataGridView();
            contextMenuStrip1 = new ContextMenuStrip(components);
            updateToolStripMenuItem = new ToolStripMenuItem();
            updateToolStripMenuItem1 = new ToolStripMenuItem();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgwAssignments).BeginInit();
            contextMenuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblAssigmentId);
            groupBox1.Controls.Add(lbCourses);
            groupBox1.Controls.Add(btnTeacherUpdate);
            groupBox1.Controls.Add(btnTeacherAdd);
            groupBox1.Controls.Add(txtTeacherEmail);
            groupBox1.Controls.Add(txtTeacherSurnam);
            groupBox1.Controls.Add(txtTeacherName);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(17, 19);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(771, 214);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "TEACHER DETAILS";
            // 
            // lblAssigmentId
            // 
            lblAssigmentId.AutoSize = true;
            lblAssigmentId.Location = new Point(19, 157);
            lblAssigmentId.Name = "lblAssigmentId";
            lblAssigmentId.Size = new Size(51, 20);
            lblAssigmentId.TabIndex = 9;
            lblAssigmentId.Text = "label4";
            lblAssigmentId.Visible = false;
            // 
            // lbCourses
            // 
            lbCourses.FormattingEnabled = true;
            lbCourses.Location = new Point(430, 26);
            lbCourses.Name = "lbCourses";
            lbCourses.SelectionMode = SelectionMode.MultiSimple;
            lbCourses.Size = new Size(322, 164);
            lbCourses.TabIndex = 8;
            // 
            // btnTeacherUpdate
            // 
            btnTeacherUpdate.Location = new Point(264, 138);
            btnTeacherUpdate.Name = "btnTeacherUpdate";
            btnTeacherUpdate.Size = new Size(149, 58);
            btnTeacherUpdate.TabIndex = 7;
            btnTeacherUpdate.Text = "UPDATE";
            btnTeacherUpdate.UseVisualStyleBackColor = true;
            btnTeacherUpdate.Click += btnTeacherUpdate_Click;
            // 
            // btnTeacherAdd
            // 
            btnTeacherAdd.Location = new Point(106, 138);
            btnTeacherAdd.Name = "btnTeacherAdd";
            btnTeacherAdd.Size = new Size(149, 58);
            btnTeacherAdd.TabIndex = 6;
            btnTeacherAdd.Text = "ADD";
            btnTeacherAdd.UseVisualStyleBackColor = true;
            btnTeacherAdd.Click += btnTeacherAdd_Click;
            // 
            // txtTeacherEmail
            // 
            txtTeacherEmail.Location = new Point(106, 98);
            txtTeacherEmail.Name = "txtTeacherEmail";
            txtTeacherEmail.Size = new Size(307, 27);
            txtTeacherEmail.TabIndex = 5;
            // 
            // txtTeacherSurnam
            // 
            txtTeacherSurnam.Location = new Point(106, 65);
            txtTeacherSurnam.Name = "txtTeacherSurnam";
            txtTeacherSurnam.Size = new Size(307, 27);
            txtTeacherSurnam.TabIndex = 4;
            // 
            // txtTeacherName
            // 
            txtTeacherName.Location = new Point(106, 32);
            txtTeacherName.Name = "txtTeacherName";
            txtTeacherName.Size = new Size(307, 27);
            txtTeacherName.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(45, 101);
            label3.Name = "label3";
            label3.Size = new Size(55, 20);
            label3.TabIndex = 2;
            label3.Text = "Email :";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(21, 68);
            label2.Name = "label2";
            label2.Size = new Size(79, 20);
            label2.TabIndex = 1;
            label2.Text = "Surname :";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(41, 35);
            label1.Name = "label1";
            label1.Size = new Size(59, 20);
            label1.TabIndex = 0;
            label1.Text = "Name :";
            // 
            // dgwAssignments
            // 
            dgwAssignments.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwAssignments.ContextMenuStrip = contextMenuStrip1;
            dgwAssignments.Location = new Point(17, 244);
            dgwAssignments.MultiSelect = false;
            dgwAssignments.Name = "dgwAssignments";
            dgwAssignments.ReadOnly = true;
            dgwAssignments.RowHeadersWidth = 51;
            dgwAssignments.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwAssignments.Size = new Size(771, 188);
            dgwAssignments.TabIndex = 1;
            // 
            // contextMenuStrip1
            // 
            contextMenuStrip1.ImageScalingSize = new Size(20, 20);
            contextMenuStrip1.Items.AddRange(new ToolStripItem[] { updateToolStripMenuItem, updateToolStripMenuItem1 });
            contextMenuStrip1.Name = "contextMenuStrip1";
            contextMenuStrip1.Size = new Size(128, 52);
            // 
            // updateToolStripMenuItem
            // 
            updateToolStripMenuItem.Name = "updateToolStripMenuItem";
            updateToolStripMenuItem.Size = new Size(127, 24);
            updateToolStripMenuItem.Text = "Delete";
            updateToolStripMenuItem.Click += updateToolStripMenuItem_Click;
            // 
            // updateToolStripMenuItem1
            // 
            updateToolStripMenuItem1.Name = "updateToolStripMenuItem1";
            updateToolStripMenuItem1.Size = new Size(127, 24);
            updateToolStripMenuItem1.Text = "Update";
            updateToolStripMenuItem1.Click += updateToolStripMenuItem1_Click;
            // 
            // TeacherManagement
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgwAssignments);
            Controls.Add(groupBox1);
            Name = "TeacherManagement";
            Text = "TeacherManagement";
            Load += TeacherManagement_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dgwAssignments).EndInit();
            contextMenuStrip1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label lblAssigmentId;
        private ListBox lbCourses;
        private Button btnTeacherUpdate;
        private Button btnTeacherAdd;
        private TextBox txtTeacherEmail;
        private TextBox txtTeacherSurnam;
        private TextBox txtTeacherName;
        private Label label3;
        private Label label2;
        private Label label1;
        private DataGridView dgwAssignments;
        private ContextMenuStrip contextMenuStrip1;
        private ToolStripMenuItem updateToolStripMenuItem;
        private ToolStripMenuItem updateToolStripMenuItem1;
    }
}