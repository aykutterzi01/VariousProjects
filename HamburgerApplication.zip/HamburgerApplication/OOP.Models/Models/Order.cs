﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Model.Models
{
    public class Order : BaseModel
    {
        public Order()
        {
            Ekstras = new List<Ekstra>();
        }
        public Food Food { get; set; }
        public List<Ekstra> Ekstras { get; set; }
        public Size Size { get; set; }
        public int Amount { get; set; }
        public string Extras { get; set; }
        public PaymentType PaymentType { get; set; }
        public DateTime DateTime { get; set; }

    }
}
