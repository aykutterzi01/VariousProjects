﻿namespace Presentation
{
    partial class BooksForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgwBooks = new DataGridView();
            groupBox1 = new GroupBox();
            txtDomain = new TextBox();
            txtThema = new TextBox();
            txtPeriod = new TextBox();
            lblDomain = new Label();
            lblThema = new Label();
            lblPeriod = new Label();
            groupBox3 = new GroupBox();
            rdbtnScience = new RadioButton();
            rdbtnNovel = new RadioButton();
            rdbtnHistory = new RadioButton();
            nudAmount = new NumericUpDown();
            label5 = new Label();
            mtbPublishYear = new MaskedTextBox();
            btnUpdateBook = new Button();
            btnDeleteBook = new Button();
            btnAddBook = new Button();
            txtAuthor = new TextBox();
            txtTitle = new TextBox();
            txtISBN = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgwBooks).BeginInit();
            groupBox1.SuspendLayout();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudAmount).BeginInit();
            SuspendLayout();
            // 
            // dgwBooks
            // 
            dgwBooks.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwBooks.Location = new Point(12, 335);
            dgwBooks.MultiSelect = false;
            dgwBooks.Name = "dgwBooks";
            dgwBooks.ReadOnly = true;
            dgwBooks.RowHeadersWidth = 51;
            dgwBooks.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwBooks.Size = new Size(776, 239);
            dgwBooks.TabIndex = 4;
            dgwBooks.RowHeaderMouseClick += dgwBooks_RowHeaderMouseClick;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtDomain);
            groupBox1.Controls.Add(txtThema);
            groupBox1.Controls.Add(txtPeriod);
            groupBox1.Controls.Add(lblDomain);
            groupBox1.Controls.Add(lblThema);
            groupBox1.Controls.Add(lblPeriod);
            groupBox1.Controls.Add(groupBox3);
            groupBox1.Controls.Add(nudAmount);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(mtbPublishYear);
            groupBox1.Controls.Add(btnUpdateBook);
            groupBox1.Controls.Add(btnDeleteBook);
            groupBox1.Controls.Add(btnAddBook);
            groupBox1.Controls.Add(txtAuthor);
            groupBox1.Controls.Add(txtTitle);
            groupBox1.Controls.Add(txtISBN);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Segoe UI", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.ForeColor = Color.White;
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(776, 317);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "Book Details";
            // 
            // txtDomain
            // 
            txtDomain.Location = new Point(540, 185);
            txtDomain.Name = "txtDomain";
            txtDomain.Size = new Size(220, 30);
            txtDomain.TabIndex = 21;
            // 
            // txtThema
            // 
            txtThema.Location = new Point(540, 147);
            txtThema.Name = "txtThema";
            txtThema.Size = new Size(220, 30);
            txtThema.TabIndex = 20;
            // 
            // txtPeriod
            // 
            txtPeriod.Location = new Point(540, 106);
            txtPeriod.Name = "txtPeriod";
            txtPeriod.Size = new Size(220, 30);
            txtPeriod.TabIndex = 19;
            // 
            // lblDomain
            // 
            lblDomain.AutoSize = true;
            lblDomain.Location = new Point(453, 185);
            lblDomain.Name = "lblDomain";
            lblDomain.Size = new Size(78, 23);
            lblDomain.TabIndex = 18;
            lblDomain.Text = "Domain:";
            // 
            // lblThema
            // 
            lblThema.AutoSize = true;
            lblThema.Location = new Point(462, 147);
            lblThema.Name = "lblThema";
            lblThema.Size = new Size(69, 23);
            lblThema.TabIndex = 17;
            lblThema.Text = "Thema:";
            // 
            // lblPeriod
            // 
            lblPeriod.AutoSize = true;
            lblPeriod.Location = new Point(465, 109);
            lblPeriod.Name = "lblPeriod";
            lblPeriod.Size = new Size(66, 23);
            lblPeriod.TabIndex = 16;
            lblPeriod.Text = "Period:";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(rdbtnScience);
            groupBox3.Controls.Add(rdbtnNovel);
            groupBox3.Controls.Add(rdbtnHistory);
            groupBox3.ForeColor = Color.White;
            groupBox3.Location = new Point(453, 20);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(307, 72);
            groupBox3.TabIndex = 15;
            groupBox3.TabStop = false;
            groupBox3.Text = "Book Category";
            // 
            // rdbtnScience
            // 
            rdbtnScience.AutoSize = true;
            rdbtnScience.Location = new Point(186, 29);
            rdbtnScience.Name = "rdbtnScience";
            rdbtnScience.Size = new Size(90, 27);
            rdbtnScience.TabIndex = 14;
            rdbtnScience.TabStop = true;
            rdbtnScience.Text = "Science";
            rdbtnScience.UseVisualStyleBackColor = true;
            rdbtnScience.CheckedChanged += rdbtnScience_CheckedChanged;
            // 
            // rdbtnNovel
            // 
            rdbtnNovel.AutoSize = true;
            rdbtnNovel.Location = new Point(108, 29);
            rdbtnNovel.Name = "rdbtnNovel";
            rdbtnNovel.Size = new Size(77, 27);
            rdbtnNovel.TabIndex = 13;
            rdbtnNovel.TabStop = true;
            rdbtnNovel.Text = "Novel";
            rdbtnNovel.UseVisualStyleBackColor = true;
            rdbtnNovel.CheckedChanged += rdbtnNovel_CheckedChanged;
            // 
            // rdbtnHistory
            // 
            rdbtnHistory.AutoSize = true;
            rdbtnHistory.Location = new Point(12, 29);
            rdbtnHistory.Name = "rdbtnHistory";
            rdbtnHistory.Size = new Size(90, 27);
            rdbtnHistory.TabIndex = 0;
            rdbtnHistory.TabStop = true;
            rdbtnHistory.Text = "History";
            rdbtnHistory.UseVisualStyleBackColor = true;
            rdbtnHistory.CheckedChanged += rdbtnHistory_CheckedChanged;
            // 
            // nudAmount
            // 
            nudAmount.Location = new Point(163, 264);
            nudAmount.Name = "nudAmount";
            nudAmount.Size = new Size(268, 30);
            nudAmount.TabIndex = 14;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(9, 266);
            label5.Name = "label5";
            label5.Size = new Size(148, 23);
            label5.TabIndex = 13;
            label5.Text = "Lonable Amount:";
            // 
            // mtbPublishYear
            // 
            mtbPublishYear.Location = new Point(163, 204);
            mtbPublishYear.Mask = "0000";
            mtbPublishYear.Name = "mtbPublishYear";
            mtbPublishYear.Size = new Size(268, 30);
            mtbPublishYear.TabIndex = 11;
            mtbPublishYear.ValidatingType = typeof(int);
            // 
            // btnUpdateBook
            // 
            btnUpdateBook.ForeColor = Color.FromArgb(192, 64, 0);
            btnUpdateBook.Location = new Point(561, 247);
            btnUpdateBook.Name = "btnUpdateBook";
            btnUpdateBook.Size = new Size(91, 47);
            btnUpdateBook.TabIndex = 10;
            btnUpdateBook.Text = "UPDATE";
            btnUpdateBook.UseVisualStyleBackColor = true;
            btnUpdateBook.Click += btnUpdateMember_Click;
            // 
            // btnDeleteBook
            // 
            btnDeleteBook.ForeColor = Color.FromArgb(192, 64, 0);
            btnDeleteBook.Location = new Point(677, 247);
            btnDeleteBook.Name = "btnDeleteBook";
            btnDeleteBook.Size = new Size(83, 47);
            btnDeleteBook.TabIndex = 9;
            btnDeleteBook.Text = "DELETE";
            btnDeleteBook.UseVisualStyleBackColor = true;
            btnDeleteBook.Click += btnDeleteMember_Click;
            // 
            // btnAddBook
            // 
            btnAddBook.ForeColor = Color.FromArgb(192, 64, 0);
            btnAddBook.Location = new Point(453, 247);
            btnAddBook.Name = "btnAddBook";
            btnAddBook.Size = new Size(84, 47);
            btnAddBook.TabIndex = 8;
            btnAddBook.Text = "ADD";
            btnAddBook.UseVisualStyleBackColor = true;
            btnAddBook.Click += btnAddMember_Click;
            // 
            // txtAuthor
            // 
            txtAuthor.Location = new Point(163, 140);
            txtAuthor.Name = "txtAuthor";
            txtAuthor.Size = new Size(266, 30);
            txtAuthor.TabIndex = 6;
            // 
            // txtTitle
            // 
            txtTitle.Location = new Point(163, 81);
            txtTitle.Name = "txtTitle";
            txtTitle.Size = new Size(268, 30);
            txtTitle.TabIndex = 5;
            // 
            // txtISBN
            // 
            txtISBN.Location = new Point(163, 29);
            txtISBN.Name = "txtISBN";
            txtISBN.Size = new Size(268, 30);
            txtISBN.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(45, 204);
            label4.Name = "label4";
            label4.Size = new Size(112, 23);
            label4.TabIndex = 3;
            label4.Text = "Publish Year:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(85, 143);
            label3.Name = "label3";
            label3.Size = new Size(72, 23);
            label3.TabIndex = 2;
            label3.Text = "Author:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(106, 84);
            label2.Name = "label2";
            label2.Size = new Size(51, 23);
            label2.TabIndex = 1;
            label2.Text = "Title:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(103, 29);
            label1.Name = "label1";
            label1.Size = new Size(54, 23);
            label1.TabIndex = 0;
            label1.Text = "ISBN:";
            // 
            // BooksForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 64, 0);
            ClientSize = new Size(814, 586);
            Controls.Add(dgwBooks);
            Controls.Add(groupBox1);
            Name = "BooksForm";
            Text = "ManageBooksForm";
            Load += ManageBooksForm_Load;
            ((System.ComponentModel.ISupportInitialize)dgwBooks).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudAmount).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dgwBooks;
        private GroupBox groupBox1;
        private Button btnUpdateBook;
        private Button btnDeleteBook;
        private Button btnAddBook;
        private TextBox txtAuthor;
        private TextBox txtTitle;
        private TextBox txtISBN;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private MaskedTextBox mtbPublishYear;
        private NumericUpDown nudAmount;
        private Label label5;
        private GroupBox groupBox3;
        private RadioButton rdbtnScience;
        private RadioButton rdbtnNovel;
        private RadioButton rdbtnHistory;
        private Label lblPeriod;
        private TextBox txtDomain;
        private TextBox txtThema;
        private TextBox txtPeriod;
        private Label lblDomain;
        private Label lblThema;
    }
}