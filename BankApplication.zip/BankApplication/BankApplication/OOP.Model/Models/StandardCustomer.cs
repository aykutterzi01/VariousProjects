﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Model.Models
{
    public class StandardCustomer : Customer
    {
        public decimal CommissionRatio { get; set; } = 0.02m;
    }
}
