﻿using Business.Services;
using Entities.Entities.Enums;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class PayrollOverview : Form
    {
        PayrollService _payrollService;
        public PayrollOverview(PayrollService payrollService)
        {
            InitializeComponent();
            _payrollService = payrollService;
        }

        private void PayrollOverview_Load(object sender, EventArgs e)
        {
            cmbMonth.DataSource = Enum.GetValues(typeof(Month));
            ResetTables();
        }

        private void ResetTables()
        {
            dgwAllPayrolls.DataSource = null;
            dgwPayrollsLessThan150.DataSource = null;
            dgwPayrollsLessThan10.DataSource = null;

            var selectedMonth = (Month)cmbMonth.SelectedItem;

            dgwAllPayrolls.DataSource = _payrollService.GetAll().Include(x => x.Personnel).Where(x => x.Month == selectedMonth).ToList();
            dgwAllPayrolls.Columns["Id"].Visible = false;
            dgwAllPayrolls.Columns["PersonnelId"].Visible = false;

            dgwPayrollsLessThan150.DataSource = _payrollService.GetAll().Include(x => x.Personnel).Where(x => x.Month == selectedMonth && x.WorkingHour < 150).ToList();
            dgwPayrollsLessThan150.Columns["Id"].Visible = false;
            dgwPayrollsLessThan150.Columns["PersonnelId"].Visible = false;

            dgwPayrollsLessThan10.DataSource = _payrollService.GetAll().Include(x => x.Personnel).Where(x => x.Month == selectedMonth && x.WorkingHour < 10).ToList();
            dgwPayrollsLessThan10.Columns["Id"].Visible = false;
            dgwPayrollsLessThan10.Columns["PersonnelId"].Visible = false;
        }

        private void cmbMonth_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetTables();
        }
    }
}
