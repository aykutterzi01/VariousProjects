﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using OOP.Model.Models.Enums;

namespace OOP.Model.Models
{
    public class Account : BaseModel
    {
        public Account(Customer customer, AccountType accountType)
        {
            Customer = customer;
            AccountType = accountType;

        }
        public Customer Customer { get; set; }
        public decimal Balance { get; set; }
        public AccountType AccountType { get; set;}

        private decimal _flexibleAmount;

        public decimal FlexibleAmount
        {
            get 
            { 
                if (Customer.CustomerType == CustomerType.Standard)
                {
                    switch (AccountType)
                    {
                        case AccountType.TL:
                            _flexibleAmount = 30000;
                            break;
                        case AccountType.Dollar:
                            _flexibleAmount = 120;
                            break;
                        case AccountType.Euro:
                            _flexibleAmount = 100;
                            break;
                        default:
                            _flexibleAmount = 0;
                            break;
                    }
                }
                else
                {
                    switch (AccountType)
                    {
                        case AccountType.TL:
                            _flexibleAmount = 15000;
                            break;
                        case AccountType.Dollar:
                            _flexibleAmount = 60;
                            break;
                        case AccountType.Euro:
                            _flexibleAmount = 50;
                            break;
                        default:
                            _flexibleAmount = 0;
                            break;
                    }
                }

                return _flexibleAmount;
            }
        }


        public override string ToString()
        {
            if (Customer.CustomerType == CustomerType.Standard)
            {
                return $"{Customer.Name} {Customer.Surname} | {Customer.Email} | {Customer.City} | {AccountType} | {Id}";
            }
            else
            {
                return $"{Customer.Name} {Customer.Surname} | {Customer.Email} | {Customer.City} | {Customer.University} | {AccountType} | {Id}";
            }
        }

    }
}
