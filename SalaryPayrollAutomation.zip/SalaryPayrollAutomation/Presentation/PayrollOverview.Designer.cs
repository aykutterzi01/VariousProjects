﻿namespace Presentation
{
    partial class PayrollOverview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgwAllPayrolls = new DataGridView();
            cmbMonth = new ComboBox();
            lblRank = new Label();
            label1 = new Label();
            label2 = new Label();
            dgwPayrollsLessThan150 = new DataGridView();
            label3 = new Label();
            dgwPayrollsLessThan10 = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)dgwAllPayrolls).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgwPayrollsLessThan150).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgwPayrollsLessThan10).BeginInit();
            SuspendLayout();
            // 
            // dgwAllPayrolls
            // 
            dgwAllPayrolls.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwAllPayrolls.Location = new Point(25, 48);
            dgwAllPayrolls.MultiSelect = false;
            dgwAllPayrolls.Name = "dgwAllPayrolls";
            dgwAllPayrolls.ReadOnly = true;
            dgwAllPayrolls.RowHeadersWidth = 51;
            dgwAllPayrolls.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwAllPayrolls.Size = new Size(817, 188);
            dgwAllPayrolls.TabIndex = 0;
            // 
            // cmbMonth
            // 
            cmbMonth.FormattingEnabled = true;
            cmbMonth.Location = new Point(657, 14);
            cmbMonth.Name = "cmbMonth";
            cmbMonth.Size = new Size(185, 28);
            cmbMonth.TabIndex = 10;
            cmbMonth.SelectedIndexChanged += cmbMonth_SelectedIndexChanged;
            // 
            // lblRank
            // 
            lblRank.AutoSize = true;
            lblRank.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 162);
            lblRank.Location = new Point(576, 14);
            lblRank.Name = "lblRank";
            lblRank.Size = new Size(75, 28);
            lblRank.TabIndex = 9;
            lblRank.Text = "Month:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label1.Location = new Point(25, 9);
            label1.Name = "label1";
            label1.Size = new Size(146, 28);
            label1.TabIndex = 11;
            label1.Text = "ALL PAYROLLS";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label2.Location = new Point(25, 250);
            label2.Name = "label2";
            label2.Size = new Size(491, 28);
            label2.TabIndex = 13;
            label2.Text = "PAYROLLS WITH LESS THAN 150 HOURS OF WORK";
            // 
            // dgwPayrollsLessThan150
            // 
            dgwPayrollsLessThan150.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwPayrollsLessThan150.Location = new Point(25, 281);
            dgwPayrollsLessThan150.MultiSelect = false;
            dgwPayrollsLessThan150.Name = "dgwPayrollsLessThan150";
            dgwPayrollsLessThan150.ReadOnly = true;
            dgwPayrollsLessThan150.RowHeadersWidth = 51;
            dgwPayrollsLessThan150.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwPayrollsLessThan150.Size = new Size(817, 138);
            dgwPayrollsLessThan150.TabIndex = 14;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 162);
            label3.Location = new Point(25, 431);
            label3.Name = "label3";
            label3.Size = new Size(479, 28);
            label3.TabIndex = 15;
            label3.Text = "PAYROLLS WITH LESS THAN 10 HOURS OF WORK";
            // 
            // dgwPayrollsLessThan10
            // 
            dgwPayrollsLessThan10.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgwPayrollsLessThan10.Location = new Point(25, 462);
            dgwPayrollsLessThan10.MultiSelect = false;
            dgwPayrollsLessThan10.Name = "dgwPayrollsLessThan10";
            dgwPayrollsLessThan10.ReadOnly = true;
            dgwPayrollsLessThan10.RowHeadersWidth = 51;
            dgwPayrollsLessThan10.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgwPayrollsLessThan10.Size = new Size(817, 138);
            dgwPayrollsLessThan10.TabIndex = 16;
            // 
            // PayrollOverview
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(854, 612);
            Controls.Add(dgwPayrollsLessThan10);
            Controls.Add(label3);
            Controls.Add(dgwPayrollsLessThan150);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(cmbMonth);
            Controls.Add(lblRank);
            Controls.Add(dgwAllPayrolls);
            Name = "PayrollOverview";
            Text = "PayrollOverview";
            Load += PayrollOverview_Load;
            ((System.ComponentModel.ISupportInitialize)dgwAllPayrolls).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgwPayrollsLessThan150).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgwPayrollsLessThan10).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgwAllPayrolls;
        private ComboBox cmbMonth;
        private Label lblRank;
        private Label label1;
        private Label label2;
        private DataGridView dgwPayrollsLessThan150;
        private Label label3;
        private DataGridView dgwPayrollsLessThan10;
    }
}