﻿using Infrastructure.DataService;
using Infrastructure.Interfaces;
using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Applicationn.CourseService
{
    public class CourseService : ICourseService
    {
        private readonly ICourseDataService _courseDataService;

        public CourseService()
        {
            _courseDataService = new CourseDataService();
        }

        public void Create(Course course)
        {
            var courses = _courseDataService.GetData();
            courses.Add(course);
            _courseDataService.Save(courses);
        }

        public void Delete(Course course)
        {
            var courses = _courseDataService.GetData();
            courses.Remove(courses.FirstOrDefault(x => x.Id == course.Id));
            _courseDataService.Save(courses);
        }

        public Course Get(Guid id)
        {
            var courses = _courseDataService.GetData();
            return courses.FirstOrDefault(x => x.Id == id);
        }

        public List<Course> GetAll()
        {
            return _courseDataService.GetData();
        }

        public void Update(Course course)
        {
            var courses = _courseDataService.GetData();
            var updatedCourse = courses.FirstOrDefault(x => x.Id == course.Id);
            var indexCourse = courses.IndexOf(updatedCourse);
            courses[indexCourse] = course;
            _courseDataService.Save(courses);
        }
    }
}
