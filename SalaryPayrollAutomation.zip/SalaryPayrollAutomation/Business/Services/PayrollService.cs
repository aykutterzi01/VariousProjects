﻿using DataAccess.Context;
using Entities.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business.Services;

public class PayrollService
{
    private readonly AppDbContext dbContext;

    public PayrollService()
    {
        this.dbContext = new AppDbContext();
    }

    public void Create(Payroll payroll)
    {
        dbContext.Payrolls.Add(payroll);
        dbContext.SaveChanges();
    }

    public void Delete(Payroll payroll)
    {
        dbContext.Payrolls.Remove(payroll);
        dbContext.SaveChanges();
    }

    public void Update(Payroll payroll)
    {
        dbContext.Payrolls.Update(payroll);
        dbContext.SaveChanges();
    }

    public IQueryable<Payroll> GetAll()
    {
        return dbContext.Payrolls;
    }
}
