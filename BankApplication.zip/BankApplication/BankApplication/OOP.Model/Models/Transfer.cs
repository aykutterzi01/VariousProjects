﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OOP.Model.Models
{
    public class Transfer : BaseModel
    {
        public Transfer(Account account, decimal amount, TransferType transactionType)
        {
            DateTime = DateTime.Now;
            Account = account;
            Amount = amount;
            TransactionType = transactionType;

            if (TransactionType == TransferType.Deposit)
            {
                if (Account.Customer is StandardCustomer customer)
                {
                    Account.Balance += (Amount - Amount * customer.CommissionRatio);
                }
                else
                {
                    Account.Balance += Amount;
                }
            }
            else
            {
                if (Account.Customer is StandardCustomer customer)
                {
                    Account.Balance -= (Amount + Amount * customer.CommissionRatio);
                }
                else
                {
                    Account.Balance -= Amount;
                }
            }
        }
        public DateTime DateTime { get; set; }
        public Account Account { get; set; }
        public decimal Amount { get; set; }
        public TransferType TransactionType { get; set; }
    }
}
