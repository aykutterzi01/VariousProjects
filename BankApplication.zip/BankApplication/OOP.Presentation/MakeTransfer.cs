﻿using OOP.Applicationn.AccountService;
using OOP.Applicationn.CustomerService;
using OOP.Applicationn.TransferService;
using OOP.Model.Models;
using OOP.Model.Models.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP.Presentation
{
    public partial class MakeTransfer : Form
    {
        CustomerService _customerService;
        AccountService _accountService;
        TransferService _transferService;

        public MakeTransfer(CustomerService customerService, AccountService accountService, TransferService transferService)
        {
            InitializeComponent();
            _customerService = customerService;
            _accountService = accountService;
            _transferService = transferService;
        }

        private void MakeTransfer_Load(object sender, EventArgs e)
        {
            dgw_Customer_List.DataSource = _customerService.GetAll();
            dgw_Customer_List.Columns["CommissionRatio"].Visible = false;
            dgw_Customer_List.Columns["Id"].Visible = false;

            dgw_Receiving_Customer.DataSource = _customerService.GetAll();
            dgw_Receiving_Customer.Columns["CommissionRatio"].Visible = false;
            dgw_Receiving_Customer.Columns["Id"].Visible = false;

            rdbtn_Deposit.Checked = true;
            rdbtn_Branch.Checked = true;

            dgw_Receiving_Customer.Enabled = false;
            dgw_Receiving_Account.Enabled = false;
            dgw_Receiving_Transfer.Enabled = false;
        }

        private void dgw_Customer_List_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ShowTotalAsset();
        }

        private void ShowTotalAsset()
        {
            Customer selectedCustomer = (Customer)dgw_Customer_List.SelectedRows[0].DataBoundItem;

            List<Account> selectedAccounts = _accountService.GetAll().Where(x => x.Customer.Id == selectedCustomer.Id).ToList();

            decimal totalAsset = 0;

            foreach (Account selectedAccount in selectedAccounts)
            {
                switch (selectedAccount.AccountType)
                {
                    case Model.Models.Enums.AccountType.TL:
                        totalAsset += selectedAccount.Balance;
                        break;
                    case Model.Models.Enums.AccountType.Dollar:
                        totalAsset += selectedAccount.Balance * Convert.ToDecimal(lbl_USD.Text);
                        break;
                    case Model.Models.Enums.AccountType.Euro:
                        totalAsset += selectedAccount.Balance * Convert.ToDecimal(lbl_EURO.Text);
                        break;
                    default:
                        break;
                }
            }

            lbl_Total_Asset.Text = totalAsset.ToString("N2") + " TL";

            UpdateAccounts(selectedCustomer);
        }

        private void UpdateAccounts(Customer selectedCustomer)
        {
            dgw_Account_List.DataSource = null;

            dgw_Account_List.DataSource = _accountService.GetAll().Where(x => x.Customer.Id == selectedCustomer.Id).ToList();

            dgw_Account_List.Columns["Id"].Visible = false;

            dgw_Account_List.Columns["Balance"].DefaultCellStyle.Format = "N2";
        }

        private void dgw_Account_List_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Account selectedAccount = (Account)dgw_Account_List.SelectedRows[0].DataBoundItem;

            UpdateTransfers(selectedAccount);
        }

        private void UpdateTransfers(Account selectedAccount)
        {
            dgw_Transfer_List.DataSource = null;

            dgw_Transfer_List.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id).ToList();

            dgw_Transfer_List.Columns["Id"].Visible = false;
            dgw_Transfer_List.Columns["Account"].Visible = false;
            dgw_Transfer_List.DefaultCellStyle.NullValue = "(Not Applicable)";
        }

        private void btn_Transfer_Click(object sender, EventArgs e)
        {
            Account selectedAccount = (Account)dgw_Account_List.SelectedRows[0].DataBoundItem;

            Customer selectedCustomer = (Customer)dgw_Customer_List.SelectedRows[0].DataBoundItem;


            if (nmrcud_Amount.Value != 0)
            {
                if (rdbtn_Deposit.Checked == true)
                {
                    selectedAccount.Balance += (nmrcud_Amount.Value - nmrcud_Amount.Value * selectedAccount.Customer.CommissionRatio);

                    _accountService.Update(selectedAccount);

                    TransferChannel transferChannel = rdbtn_Branch.Checked ? TransferChannel.Branch : rdbtn_Internet.Checked ? TransferChannel.Internet : TransferChannel.ATM;

                    Transfer transfer = new Transfer(selectedAccount, nmrcud_Amount.Value, TransferType.Deposit, transferChannel);

                    _transferService.Create(transfer);
                }
                else if (rdbtn_Withdrawal.Checked == true)
                {
                    selectedAccount.Balance -= (nmrcud_Amount.Value + nmrcud_Amount.Value * selectedAccount.Customer.CommissionRatio);

                    if (selectedAccount.Balance < -selectedAccount.FlexibleAmount)
                    {
                        MessageBox.Show("The balance can not be less than the flexible amount!");
                        return;
                    }

                    _accountService.Update(selectedAccount);


                    TransferChannel transferChannel = rdbtn_Branch.Checked ? TransferChannel.Branch : rdbtn_Internet.Checked ? TransferChannel.Internet : TransferChannel.ATM;

                    Transfer transfer = new Transfer(selectedAccount, nmrcud_Amount.Value, TransferType.Withdrawal, transferChannel);

                    _transferService.Create(transfer);

                }
                else if(rdbtn_Remission.Checked == true)
                {
                    Customer receivingCustomer = (Customer)dgw_Receiving_Customer.SelectedRows[0].DataBoundItem;
                    Account receivingAccount = (Account)dgw_Receiving_Account.SelectedRows[0].DataBoundItem;

                    if (receivingCustomer.Id == selectedCustomer.Id)
                    {
                        MessageBox.Show("The sending and receiving customers can not be the same!");
                        return;
                    }
                    else
                    {
                        if (selectedAccount.AccountType != receivingAccount.AccountType)
                        {
                            MessageBox.Show("The transfer can not be achieved between different account types!");
                            return;
                        }
                        else
                        {
                            selectedAccount.Balance -= (nmrcud_Amount.Value + nmrcud_Amount.Value * selectedAccount.Customer.CommissionRatio);


                            if (selectedAccount.Balance < -selectedAccount.FlexibleAmount)
                            {
                                MessageBox.Show("The balance can not be less than the flexible amount!");
                                return;
                            }

                            receivingAccount.Balance += (nmrcud_Amount.Value - nmrcud_Amount.Value * selectedAccount.Customer.CommissionRatio);

                            _accountService.Update(selectedAccount);
                            _accountService.Update(receivingAccount);


                            TransferChannel transferChannel = rdbtn_Branch.Checked ? TransferChannel.Branch : rdbtn_Internet.Checked ? TransferChannel.Internet : TransferChannel.ATM;

                            Transfer transfer1 = new Transfer(selectedAccount, nmrcud_Amount.Value, TransferType.Remission, transferChannel, receivingAccount);
                            _transferService.Create(transfer1);

                            Transfer transfer2 = new Transfer(receivingAccount, (nmrcud_Amount.Value - nmrcud_Amount.Value * selectedAccount.Customer.CommissionRatio), TransferType.Receival, transferChannel, selectedAccount);
                            _transferService.Create(transfer2);

                            UpdateReceivingAccounts(receivingCustomer);
                            UpdateReceivingTransfers(receivingAccount);
                        }

                    }

                }
                else
                {
                    Customer receivingCustomer = (Customer)dgw_Receiving_Customer.SelectedRows[0].DataBoundItem;
                    Account receivingAccount = (Account)dgw_Receiving_Account.SelectedRows[0].DataBoundItem;

                    if (receivingCustomer.Id != selectedCustomer.Id)
                    {
                        MessageBox.Show("The accounts have to belong to the same customer!");
                        return;
                    }
                    else
                    {
                        if (selectedAccount.AccountType == receivingAccount.AccountType)
                        {
                            MessageBox.Show("The exchange can only be achieved between different account types.");
                            return;
                        }
                        else
                        {
                            CalculateExchange(selectedAccount, receivingAccount, receivingCustomer);
                        }
                    }
                }

                UpdateAccounts(selectedCustomer);
                UpdateTransfers(selectedAccount);

                nmrcud_Amount.Value = 0;

                MessageBox.Show("Transaction has been made!");

                ShowTotalAsset();
            }
            else
            {
                MessageBox.Show("Please choose an amount different from zero!");
            }
        }

        private void CalculateExchange(Account selectedAccount, Account receivingAccount, Customer receivingCustomer)
        {
            decimal exchange = 0;
            switch (selectedAccount.AccountType)
            {
                case Model.Models.Enums.AccountType.TL:
                    if (receivingAccount.AccountType == Model.Models.Enums.AccountType.Dollar)
                    {
                        selectedAccount.Balance -= nmrcud_Amount.Value;
                        exchange = nmrcud_Amount.Value / Convert.ToDecimal(lbl_USD.Text);
                        receivingAccount.Balance += exchange;
                    }
                    else
                    {
                        selectedAccount.Balance -= nmrcud_Amount.Value;
                        exchange = nmrcud_Amount.Value / Convert.ToDecimal(lbl_EURO.Text);
                        receivingAccount.Balance += exchange;
                    }
                    break;
                case Model.Models.Enums.AccountType.Dollar:
                    if (receivingAccount.AccountType == Model.Models.Enums.AccountType.TL)
                    {
                        selectedAccount.Balance -= nmrcud_Amount.Value;
                        exchange = nmrcud_Amount.Value * Convert.ToDecimal(lbl_USD.Text);
                        receivingAccount.Balance += exchange;
                    }
                    else
                    {
                        selectedAccount.Balance -= nmrcud_Amount.Value;
                        exchange = nmrcud_Amount.Value * Convert.ToDecimal(lbl_USD.Text) / Convert.ToDecimal(lbl_EURO.Text);
                        receivingAccount.Balance += exchange;
                    }
                    break;
                case Model.Models.Enums.AccountType.Euro:
                    if (receivingAccount.AccountType == Model.Models.Enums.AccountType.TL)
                    {
                        selectedAccount.Balance -= nmrcud_Amount.Value;
                        exchange = nmrcud_Amount.Value * Convert.ToDecimal(lbl_USD.Text);
                        receivingAccount.Balance += exchange;
                    }
                    else
                    {
                        selectedAccount.Balance -= nmrcud_Amount.Value;
                        exchange = nmrcud_Amount.Value * Convert.ToDecimal(lbl_EURO.Text) / Convert.ToDecimal(lbl_USD.Text);
                        receivingAccount.Balance += exchange;
                    }
                    break;
                default:
                    break;
            }


            if (selectedAccount.Balance < -selectedAccount.FlexibleAmount)
            {
                MessageBox.Show("The balance can not be less than the flexible amount!");
                return;
            }

            _accountService.Update(selectedAccount);
            _accountService.Update(receivingAccount);


            TransferChannel transferChannel = rdbtn_Branch.Checked ? TransferChannel.Branch : rdbtn_Internet.Checked ? TransferChannel.Internet : TransferChannel.ATM;

            Transfer transfer1 = new Transfer(selectedAccount, nmrcud_Amount.Value, TransferType.Remission, transferChannel, receivingAccount);
            _transferService.Create(transfer1);

            Transfer transfer2 = new Transfer(receivingAccount, exchange, TransferType.Receival, transferChannel, selectedAccount);
            _transferService.Create(transfer2);

            UpdateReceivingAccounts(receivingCustomer);
            UpdateReceivingTransfers(receivingAccount);
        }

        private void rdbtn_Remission_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Remission.Checked == true || rdbtn_Exchange.Checked == true)
            {
                dgw_Receiving_Customer.Enabled = true;
                dgw_Receiving_Account.Enabled = true;
                dgw_Receiving_Transfer.Enabled = true;
            }
            else
            {
                dgw_Receiving_Customer.Enabled = false;
                dgw_Receiving_Account.Enabled = false;
                dgw_Receiving_Transfer.Enabled = false;
            }

        }

        private void dgw_Receving_Customer_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Customer selectedCustomer = (Customer)dgw_Receiving_Customer.SelectedRows[0].DataBoundItem;

            UpdateReceivingAccounts(selectedCustomer);

            dgw_Receiving_Transfer.DataSource = null;
        }

        private void UpdateReceivingAccounts(Customer selectedCustomer)
        {
            dgw_Receiving_Account.DataSource = null;

            dgw_Receiving_Account.DataSource = _accountService.GetAll().Where(x => x.Customer.Id == selectedCustomer.Id).ToList();

            dgw_Receiving_Account.Columns["Id"].Visible = false;

            dgw_Receiving_Account.Columns["Balance"].DefaultCellStyle.Format = "N2";
        }

        private void dgw_Receiving_Account_RowHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            Account selectedAccount = (Account)dgw_Receiving_Account.SelectedRows[0].DataBoundItem;

            UpdateReceivingTransfers(selectedAccount);
        }

        private void UpdateReceivingTransfers(Account selectedAccount)
        {
            dgw_Receiving_Transfer.DataSource = null;

            dgw_Receiving_Transfer.DataSource = _transferService.GetAll().Where(x => x.Account.Id == selectedAccount.Id).ToList();

            dgw_Receiving_Transfer.Columns["Id"].Visible = false;
            dgw_Receiving_Transfer.Columns["Account"].Visible = false;
            dgw_Receiving_Transfer.DefaultCellStyle.NullValue = "(Not Applicable)";
        }

        private void rdbtn_Exchange_CheckedChanged(object sender, EventArgs e)
        {
            if (rdbtn_Remission.Checked == true || rdbtn_Exchange.Checked == true)
            {
                dgw_Receiving_Customer.Enabled = true;
                dgw_Receiving_Account.Enabled = true;
                dgw_Receiving_Transfer.Enabled = true;
            }
            else
            {
                dgw_Receiving_Customer.Enabled = false;
                dgw_Receiving_Account.Enabled = false;
                dgw_Receiving_Transfer.Enabled = false;
            }
        }
    }
}
