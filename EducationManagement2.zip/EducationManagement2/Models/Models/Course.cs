﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.Models;

public class Course : BaseModel
{
    public string Name { get; set; }
    public string Code { get; set; }

    public string FullName => $"{Name} | {Code}";
}
