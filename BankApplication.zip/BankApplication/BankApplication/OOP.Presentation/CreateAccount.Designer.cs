﻿namespace OOP.Presentation
{
    partial class CreateAccount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            rdbtn_Standard = new RadioButton();
            rdbtn_Student = new RadioButton();
            groupBox3 = new GroupBox();
            rdbtn_Dollar = new RadioButton();
            rdbtn_TL = new RadioButton();
            rdbtn_Euro = new RadioButton();
            groupBox4 = new GroupBox();
            rdbtn_Existing_Customer = new RadioButton();
            rdbtn_New_Customer = new RadioButton();
            grpbx_New_Customer_Details = new GroupBox();
            txt_University = new TextBox();
            label5 = new Label();
            txt_City = new TextBox();
            txt_Email = new TextBox();
            txt_Surname = new TextBox();
            txt_Name = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            grpbx_Existing_Accounts = new GroupBox();
            dgw_Existing_Accounts = new DataGridView();
            grpbx_Existing_Customers = new GroupBox();
            cmb_Existing_Customers = new ComboBox();
            btn_Create_Account = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            grpbx_New_Customer_Details.SuspendLayout();
            grpbx_Existing_Accounts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgw_Existing_Accounts).BeginInit();
            grpbx_Existing_Customers.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(btn_Create_Account);
            groupBox1.Controls.Add(grpbx_New_Customer_Details);
            groupBox1.Controls.Add(grpbx_Existing_Accounts);
            groupBox1.Controls.Add(grpbx_Existing_Customers);
            groupBox1.Controls.Add(groupBox4);
            groupBox1.Controls.Add(groupBox3);
            groupBox1.Controls.Add(groupBox2);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            groupBox1.Location = new Point(18, 15);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(787, 507);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "ENTER THE ACCOUNT DETAILS";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(rdbtn_Student);
            groupBox2.Controls.Add(rdbtn_Standard);
            groupBox2.Location = new Point(6, 31);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(215, 59);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            groupBox2.Text = "Account Type";
            // 
            // rdbtn_Standard
            // 
            rdbtn_Standard.AutoSize = true;
            rdbtn_Standard.Location = new Point(12, 23);
            rdbtn_Standard.Name = "rdbtn_Standard";
            rdbtn_Standard.Size = new Size(93, 24);
            rdbtn_Standard.TabIndex = 0;
            rdbtn_Standard.TabStop = true;
            rdbtn_Standard.Text = "Standard";
            rdbtn_Standard.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Student
            // 
            rdbtn_Student.AutoSize = true;
            rdbtn_Student.Location = new Point(122, 23);
            rdbtn_Student.Name = "rdbtn_Student";
            rdbtn_Student.Size = new Size(85, 24);
            rdbtn_Student.TabIndex = 1;
            rdbtn_Student.TabStop = true;
            rdbtn_Student.Text = "Student";
            rdbtn_Student.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(rdbtn_Euro);
            groupBox3.Controls.Add(rdbtn_Dollar);
            groupBox3.Controls.Add(rdbtn_TL);
            groupBox3.Location = new Point(227, 31);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(215, 59);
            groupBox3.TabIndex = 1;
            groupBox3.TabStop = false;
            groupBox3.Text = "Money Type";
            // 
            // rdbtn_Dollar
            // 
            rdbtn_Dollar.AutoSize = true;
            rdbtn_Dollar.Location = new Point(65, 23);
            rdbtn_Dollar.Name = "rdbtn_Dollar";
            rdbtn_Dollar.Size = new Size(72, 24);
            rdbtn_Dollar.TabIndex = 1;
            rdbtn_Dollar.TabStop = true;
            rdbtn_Dollar.Text = "Dollar";
            rdbtn_Dollar.UseVisualStyleBackColor = true;
            // 
            // rdbtn_TL
            // 
            rdbtn_TL.AutoSize = true;
            rdbtn_TL.Location = new Point(12, 23);
            rdbtn_TL.Name = "rdbtn_TL";
            rdbtn_TL.Size = new Size(47, 24);
            rdbtn_TL.TabIndex = 0;
            rdbtn_TL.TabStop = true;
            rdbtn_TL.Text = "TL";
            rdbtn_TL.UseVisualStyleBackColor = true;
            // 
            // rdbtn_Euro
            // 
            rdbtn_Euro.AutoSize = true;
            rdbtn_Euro.Location = new Point(138, 23);
            rdbtn_Euro.Name = "rdbtn_Euro";
            rdbtn_Euro.Size = new Size(62, 24);
            rdbtn_Euro.TabIndex = 2;
            rdbtn_Euro.TabStop = true;
            rdbtn_Euro.Text = "Euro";
            rdbtn_Euro.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(rdbtn_Existing_Customer);
            groupBox4.Controls.Add(rdbtn_New_Customer);
            groupBox4.Location = new Point(448, 31);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(324, 59);
            groupBox4.TabIndex = 2;
            groupBox4.TabStop = false;
            groupBox4.Text = "Customer Selection";
            // 
            // rdbtn_Existing_Customer
            // 
            rdbtn_Existing_Customer.AutoSize = true;
            rdbtn_Existing_Customer.Location = new Point(152, 23);
            rdbtn_Existing_Customer.Name = "rdbtn_Existing_Customer";
            rdbtn_Existing_Customer.Size = new Size(157, 24);
            rdbtn_Existing_Customer.TabIndex = 1;
            rdbtn_Existing_Customer.TabStop = true;
            rdbtn_Existing_Customer.Text = "Existing Customer";
            rdbtn_Existing_Customer.UseVisualStyleBackColor = true;
            // 
            // rdbtn_New_Customer
            // 
            rdbtn_New_Customer.AutoSize = true;
            rdbtn_New_Customer.Location = new Point(12, 23);
            rdbtn_New_Customer.Name = "rdbtn_New_Customer";
            rdbtn_New_Customer.Size = new Size(134, 24);
            rdbtn_New_Customer.TabIndex = 0;
            rdbtn_New_Customer.TabStop = true;
            rdbtn_New_Customer.Text = "New Customer";
            rdbtn_New_Customer.UseVisualStyleBackColor = true;
            // 
            // grpbx_New_Customer_Details
            // 
            grpbx_New_Customer_Details.Controls.Add(txt_University);
            grpbx_New_Customer_Details.Controls.Add(label5);
            grpbx_New_Customer_Details.Controls.Add(txt_City);
            grpbx_New_Customer_Details.Controls.Add(txt_Email);
            grpbx_New_Customer_Details.Controls.Add(txt_Surname);
            grpbx_New_Customer_Details.Controls.Add(txt_Name);
            grpbx_New_Customer_Details.Controls.Add(label4);
            grpbx_New_Customer_Details.Controls.Add(label3);
            grpbx_New_Customer_Details.Controls.Add(label2);
            grpbx_New_Customer_Details.Controls.Add(label1);
            grpbx_New_Customer_Details.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            grpbx_New_Customer_Details.Location = new Point(6, 335);
            grpbx_New_Customer_Details.Name = "grpbx_New_Customer_Details";
            grpbx_New_Customer_Details.Size = new Size(591, 155);
            grpbx_New_Customer_Details.TabIndex = 6;
            grpbx_New_Customer_Details.TabStop = false;
            grpbx_New_Customer_Details.Text = "New Customer Details";
            // 
            // txt_University
            // 
            txt_University.Location = new Point(98, 111);
            txt_University.Name = "txt_University";
            txt_University.Size = new Size(487, 27);
            txt_University.TabIndex = 9;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 114);
            label5.Name = "label5";
            label5.Size = new Size(84, 20);
            label5.TabIndex = 8;
            label5.Text = "University:";
            // 
            // txt_City
            // 
            txt_City.Location = new Point(362, 65);
            txt_City.Name = "txt_City";
            txt_City.Size = new Size(223, 27);
            txt_City.TabIndex = 7;
            // 
            // txt_Email
            // 
            txt_Email.Location = new Point(362, 30);
            txt_Email.Name = "txt_Email";
            txt_Email.Size = new Size(223, 27);
            txt_Email.TabIndex = 6;
            // 
            // txt_Surname
            // 
            txt_Surname.Location = new Point(98, 65);
            txt_Surname.Name = "txt_Surname";
            txt_Surname.Size = new Size(201, 27);
            txt_Surname.TabIndex = 5;
            // 
            // txt_Name
            // 
            txt_Name.Location = new Point(98, 32);
            txt_Name.Name = "txt_Name";
            txt_Name.Size = new Size(201, 27);
            txt_Name.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(316, 67);
            label4.Name = "label4";
            label4.Size = new Size(40, 20);
            label4.TabIndex = 3;
            label4.Text = "City:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(305, 35);
            label3.Name = "label3";
            label3.Size = new Size(51, 20);
            label3.TabIndex = 2;
            label3.Text = "Email:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(15, 67);
            label2.Name = "label2";
            label2.Size = new Size(75, 20);
            label2.TabIndex = 1;
            label2.Text = "Surname:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(35, 33);
            label1.Name = "label1";
            label1.Size = new Size(55, 20);
            label1.TabIndex = 0;
            label1.Text = "Name:";
            // 
            // grpbx_Existing_Accounts
            // 
            grpbx_Existing_Accounts.Controls.Add(dgw_Existing_Accounts);
            grpbx_Existing_Accounts.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            grpbx_Existing_Accounts.Location = new Point(6, 168);
            grpbx_Existing_Accounts.Name = "grpbx_Existing_Accounts";
            grpbx_Existing_Accounts.Size = new Size(774, 161);
            grpbx_Existing_Accounts.TabIndex = 5;
            grpbx_Existing_Accounts.TabStop = false;
            grpbx_Existing_Accounts.Text = "Existing  Accounts";
            // 
            // dgw_Existing_Accounts
            // 
            dgw_Existing_Accounts.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgw_Existing_Accounts.Location = new Point(10, 28);
            dgw_Existing_Accounts.Name = "dgw_Existing_Accounts";
            dgw_Existing_Accounts.RowHeadersWidth = 51;
            dgw_Existing_Accounts.Size = new Size(755, 119);
            dgw_Existing_Accounts.TabIndex = 0;
            // 
            // grpbx_Existing_Customers
            // 
            grpbx_Existing_Customers.Controls.Add(cmb_Existing_Customers);
            grpbx_Existing_Customers.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 162);
            grpbx_Existing_Customers.Location = new Point(6, 96);
            grpbx_Existing_Customers.Name = "grpbx_Existing_Customers";
            grpbx_Existing_Customers.Size = new Size(774, 66);
            grpbx_Existing_Customers.TabIndex = 4;
            grpbx_Existing_Customers.TabStop = false;
            grpbx_Existing_Customers.Text = "Existing  Customers";
            // 
            // cmb_Existing_Customers
            // 
            cmb_Existing_Customers.FormattingEnabled = true;
            cmb_Existing_Customers.Location = new Point(10, 26);
            cmb_Existing_Customers.Name = "cmb_Existing_Customers";
            cmb_Existing_Customers.Size = new Size(758, 28);
            cmb_Existing_Customers.TabIndex = 0;
            // 
            // btn_Create_Account
            // 
            btn_Create_Account.Location = new Point(608, 345);
            btn_Create_Account.Name = "btn_Create_Account";
            btn_Create_Account.Size = new Size(163, 145);
            btn_Create_Account.TabIndex = 7;
            btn_Create_Account.Text = "CREATE ACCOUNT";
            btn_Create_Account.UseVisualStyleBackColor = true;
            // 
            // CreateAccount
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(817, 534);
            Controls.Add(groupBox1);
            Name = "CreateAccount";
            Text = "CreateAccount";
            WindowState = FormWindowState.Maximized;
            Load += CreateAccount_Load;
            groupBox1.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            grpbx_New_Customer_Details.ResumeLayout(false);
            grpbx_New_Customer_Details.PerformLayout();
            grpbx_Existing_Accounts.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgw_Existing_Accounts).EndInit();
            grpbx_Existing_Customers.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox3;
        private RadioButton rdbtn_Euro;
        private RadioButton rdbtn_Dollar;
        private RadioButton rdbtn_TL;
        private GroupBox groupBox2;
        private RadioButton rdbtn_Student;
        private RadioButton rdbtn_Standard;
        private GroupBox groupBox4;
        private RadioButton rdbtn_Existing_Customer;
        private RadioButton rdbtn_New_Customer;
        private Button btn_Create_Account;
        private GroupBox grpbx_New_Customer_Details;
        private TextBox txt_University;
        private Label label5;
        private TextBox txt_City;
        private TextBox txt_Email;
        private TextBox txt_Surname;
        private TextBox txt_Name;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private GroupBox grpbx_Existing_Accounts;
        private DataGridView dgw_Existing_Accounts;
        private GroupBox grpbx_Existing_Customers;
        private ComboBox cmb_Existing_Customers;
    }
}